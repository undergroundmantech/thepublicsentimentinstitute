// Right track / wrong track raw polls — extracted so homeStats + the
// situation room can aggregate without pulling the page bundle.
import { Poll } from "@/app/_polling/lib/buildDailyModel";

export const GOLD_STANDARD_NAMES = [
  // Oct 22 2026, set by the publisher: the gold standard pollsters, weighted up in every average.
  "On Point Polling", "Big Data Poll", "Honest Poll", "Emerson", "Quantus",
  "New York Times", "NY Times", "NYT", "Wall Street Journal", "WSJ",
];

export const RAW_POLLS: Poll[] = [
  // ── Added Nov 21, 2026: Nov 16 releases, and the June through November polls the RealClearPolling list carries that were missing here ──
  { pollster: "Reuters/Ipsos", endDate: "2026-11-16", sampleSize: 1199, sampleType: "RV", results: { RightTrack: 14, WrongTrack: 70 } },   // Nov 13 to 16, registered voters; 13 to 68 among all 1,521 adults
  { pollster: "Echelon Insights (R)", endDate: "2026-11-16", sampleSize: 1027, sampleType: "LV", results: { RightTrack: 27, WrongTrack: 62 } },   // Nov 12 to 16, verified voters in the likely electorate
  { pollster: "Economist/YouGov", endDate: "2026-11-16", sampleSize: 1386, sampleType: "RV", results: { RightTrack: 22, WrongTrack: 68 } },   // 11/13 to 11/16
  { pollster: "Economist/YouGov", endDate: "2026-11-11", sampleSize: 1463, sampleType: "RV", results: { RightTrack: 23, WrongTrack: 67 } },   // 11/9 to 11/11
  { pollster: "Economist/YouGov", endDate: "2026-11-06", sampleSize: 3166, sampleType: "RV", results: { RightTrack: 22, WrongTrack: 66 } },   // 11/4 to 11/6
  { pollster: "Cygnal (R)", endDate: "2026-11-05", sampleSize: 3000, sampleType: "LV", results: { RightTrack: 29, WrongTrack: 63 } },   // 11/4 to 11/5
  { pollster: "Rasmussen Reports (R)", endDate: "2026-11-05", sampleSize: 1753, sampleType: "LV", results: { RightTrack: 36, WrongTrack: 59 } },   // 11/1 to 11/5
  { pollster: "NBC News", endDate: "2026-10-30", sampleSize: 1000, sampleType: "RV", results: { RightTrack: 25, WrongTrack: 70 } },   // 10/28 to 10/30
  { pollster: "Big Data Poll", endDate: "2026-10-30", sampleSize: 3214, sampleType: "LV", results: { RightTrack: 31, WrongTrack: 61 } },   // 10/27 to 10/30
  { pollster: "Rasmussen Reports (R)", endDate: "2026-10-29", sampleSize: 1777, sampleType: "LV", results: { RightTrack: 35, WrongTrack: 60 } },   // 10/25 to 10/29
  { pollster: "Harvard-Harris", endDate: "2026-10-26", sampleSize: 2700, sampleType: "RV", results: { RightTrack: 31, WrongTrack: 59 } },   // 10/24 to 10/26
  { pollster: "Economist/YouGov", endDate: "2026-10-26", sampleSize: 1272, sampleType: "LV", results: { RightTrack: 30, WrongTrack: 63 } },   // 10/23 to 10/26
  { pollster: "Cygnal (R)", endDate: "2026-10-24", sampleSize: 1500, sampleType: "LV", results: { RightTrack: 34, WrongTrack: 63 } },   // 10/23 to 10/24
  { pollster: "Rasmussen Reports (R)", endDate: "2026-10-22", sampleSize: 1755, sampleType: "LV", results: { RightTrack: 34, WrongTrack: 61 } },   // 10/18 to 10/22
  { pollster: "Economist/YouGov", endDate: "2026-10-20", sampleSize: 1315, sampleType: "LV", results: { RightTrack: 29, WrongTrack: 66 } },   // 10/19 to 10/20
  { pollster: "Rasmussen Reports (R)", endDate: "2026-10-15", sampleSize: 1788, sampleType: "LV", results: { RightTrack: 36, WrongTrack: 61 } },   // 10/11 to 10/15
  { pollster: "ABC/Wash Post/Ipsos", endDate: "2026-10-13", sampleSize: 2032, sampleType: "RV", results: { RightTrack: 29, WrongTrack: 70 } },   // 10/9 to 10/13
  { pollster: "Economist/YouGov", endDate: "2026-10-12", sampleSize: 1184, sampleType: "LV", results: { RightTrack: 29, WrongTrack: 65 } },   // 10/10 to 10/12
  { pollster: "Cygnal (R)", endDate: "2026-10-10", sampleSize: 1500, sampleType: "LV", results: { RightTrack: 32, WrongTrack: 63 } },   // 10/7 to 10/10
  { pollster: "NBC News Decision Desk", endDate: "2026-10-12", sampleSize: 19135, sampleType: "A", results: { RightTrack: 29, WrongTrack: 71 } },   // 9/28 to 10/12
  { pollster: "Rasmussen Reports (R)", endDate: "2026-10-08", sampleSize: 1788, sampleType: "LV", results: { RightTrack: 33, WrongTrack: 61 } },   // 10/4 to 10/8
  { pollster: "Economist/YouGov", endDate: "2026-10-05", sampleSize: 1181, sampleType: "LV", results: { RightTrack: 31, WrongTrack: 63 } },   // 10/2 to 10/5
  { pollster: "Rasmussen Reports (R)", endDate: "2026-10-01", sampleSize: 1782, sampleType: "LV", results: { RightTrack: 35, WrongTrack: 60 } },   // 9/27 to 10/1
  { pollster: "Rasmussen Reports (R)", endDate: "2026-09-25", sampleSize: 1847, sampleType: "LV", results: { RightTrack: 37, WrongTrack: 58 } },   // 9/21 to 9/25
  { pollster: "Quantus Insights", endDate: "2026-09-18", sampleSize: 1389, sampleType: "LV", results: { RightTrack: 35, WrongTrack: 60 } },   // 9/15 to 9/18
  { pollster: "Rasmussen Reports (R)", endDate: "2026-09-17", sampleSize: 1737, sampleType: "LV", results: { RightTrack: 35, WrongTrack: 60 } },   // 9/13 to 9/17
  { pollster: "Big Data Poll", endDate: "2026-09-15", sampleSize: 2633, sampleType: "LV", results: { RightTrack: 31, WrongTrack: 62 } },   // 9/13 to 9/15
  { pollster: "The Honest Poll", endDate: "2026-09-13", sampleSize: 1392, sampleType: "LV", results: { RightTrack: 38, WrongTrack: 57 } },   // 9/7 to 9/13
  { pollster: "NY Times/Siena", endDate: "2026-09-13", sampleSize: 1503, sampleType: "LV", results: { RightTrack: 32, WrongTrack: 59 } },   // 9/8 to 9/13
  { pollster: "Rasmussen Reports (R)", endDate: "2026-09-10", sampleSize: 1871, sampleType: "LV", results: { RightTrack: 34, WrongTrack: 59 } },   // 9/6 to 9/10
  { pollster: "Rasmussen Reports (R)", endDate: "2026-09-03", sampleSize: 1865, sampleType: "LV", results: { RightTrack: 39, WrongTrack: 56 } },   // 8/30 to 9/3
  { pollster: "Rasmussen Reports (R)", endDate: "2026-08-27", sampleSize: 1834, sampleType: "LV", results: { RightTrack: 37, WrongTrack: 58 } },   // 8/23 to 8/27
  { pollster: "Economist/YouGov", endDate: "2026-08-24", sampleSize: 1379, sampleType: "RV", results: { RightTrack: 30, WrongTrack: 65 } },   // 8/21 to 8/24
  { pollster: "Rasmussen Reports (R)", endDate: "2026-08-20", sampleSize: 1816, sampleType: "LV", results: { RightTrack: 33, WrongTrack: 58 } },   // 8/16 to 8/20
  { pollster: "Rasmussen Reports (R)", endDate: "2026-08-13", sampleSize: 1831, sampleType: "LV", results: { RightTrack: 33, WrongTrack: 60 } },   // 8/9 to 8/13
  { pollster: "Economist/YouGov", endDate: "2026-08-10", sampleSize: 1420, sampleType: "RV", results: { RightTrack: 28, WrongTrack: 64 } },   // 8/7 to 8/10
  { pollster: "Cygnal (R)", endDate: "2026-08-07", sampleSize: 1500, sampleType: "LV", results: { RightTrack: 37, WrongTrack: 59 } },   // 8/6 to 8/7
  { pollster: "Rasmussen Reports (R)", endDate: "2026-08-06", sampleSize: 1953, sampleType: "LV", results: { RightTrack: 34, WrongTrack: 60 } },   // 8/2 to 8/6
  { pollster: "Rasmussen Reports (R)", endDate: "2026-07-30", sampleSize: 1900, sampleType: "LV", results: { RightTrack: 36, WrongTrack: 59 } },   // 7/26 to 7/30
  { pollster: "Big Data Poll", endDate: "2026-07-29", sampleSize: 2617, sampleType: "LV", results: { RightTrack: 30, WrongTrack: 61 } },   // 7/27 to 7/29
  { pollster: "Economist/YouGov", endDate: "2026-07-27", sampleSize: 1407, sampleType: "RV", results: { RightTrack: 31, WrongTrack: 62 } },   // 7/25 to 7/27
  { pollster: "Rasmussen Reports (R)", endDate: "2026-07-23", sampleSize: 1833, sampleType: "LV", results: { RightTrack: 38, WrongTrack: 57 } },   // 7/19 to 7/23
  { pollster: "Economist/YouGov", endDate: "2026-07-20", sampleSize: 1432, sampleType: "RV", results: { RightTrack: 30, WrongTrack: 63 } },   // 7/17 to 7/20
  { pollster: "Rasmussen Reports (R)", endDate: "2026-07-16", sampleSize: 1824, sampleType: "LV", results: { RightTrack: 36, WrongTrack: 58 } },   // 7/12 to 7/16
  { pollster: "Economist/YouGov", endDate: "2026-07-13", sampleSize: 1450, sampleType: "RV", results: { RightTrack: 32, WrongTrack: 62 } },   // 7/10 to 7/13
  { pollster: "HarrisX", endDate: "2026-07-10", sampleSize: 787, sampleType: "LV", results: { RightTrack: 35, WrongTrack: 57 } },   // 7/9 to 7/10
  { pollster: "Rasmussen Reports (R)", endDate: "2026-07-09", sampleSize: 1852, sampleType: "LV", results: { RightTrack: 39, WrongTrack: 55 } },   // 7/5 to 7/9
  { pollster: "Quantus Insights", endDate: "2026-07-07", sampleSize: 1140, sampleType: "LV", results: { RightTrack: 38, WrongTrack: 62 } },   // 7/3 to 7/7
  { pollster: "Economist/YouGov", endDate: "2026-07-06", sampleSize: 1443, sampleType: "RV", results: { RightTrack: 32, WrongTrack: 61 } },   // 7/3 to 7/6
  { pollster: "Cygnal (R)", endDate: "2026-07-01", sampleSize: 1500, sampleType: "LV", results: { RightTrack: 36, WrongTrack: 60 } },   // 6/30 to 7/1
  { pollster: "Rasmussen Reports (R)", endDate: "2026-07-02", sampleSize: 1852, sampleType: "LV", results: { RightTrack: 33, WrongTrack: 60 } },   // 6/28 to 7/2
  { pollster: "Economist/YouGov", endDate: "2026-06-29", sampleSize: 1428, sampleType: "RV", results: { RightTrack: 32, WrongTrack: 61 } },   // 6/26 to 6/29
  { pollster: "Big Data Poll", endDate: "2026-06-28", sampleSize: 2604, sampleType: "LV", results: { RightTrack: 35, WrongTrack: 57 } },   // 6/26 to 6/28
  { pollster: "Rasmussen Reports (R)", endDate: "2026-06-25", sampleSize: 1852, sampleType: "LV", results: { RightTrack: 38, WrongTrack: 56 } },   // 6/21 to 6/25
  { pollster: "Economist/YouGov", endDate: "2026-06-22", sampleSize: 1517, sampleType: "RV", results: { RightTrack: 34, WrongTrack: 60 } },   // 6/19 to 6/22
  { pollster: "Rasmussen Reports (R)", endDate: "2026-06-18", sampleSize: 1733, sampleType: "LV", results: { RightTrack: 39, WrongTrack: 56 } },   // 6/14 to 6/18
  { pollster: "Economist/YouGov", endDate: "2026-06-15", sampleSize: 1403, sampleType: "RV", results: { RightTrack: 32, WrongTrack: 61 } },   // 6/13 to 6/15
  { pollster: "Rasmussen Reports (R)", endDate: "2026-06-11", sampleSize: 1806, sampleType: "LV", results: { RightTrack: 34, WrongTrack: 59 } },   // 6/7 to 6/11
  { pollster: "Economist/YouGov", endDate: "2026-06-08", sampleSize: 1438, sampleType: "RV", results: { RightTrack: 31, WrongTrack: 62 } },   // 6/5 to 6/8
  { pollster: "Cygnal (R)", endDate: "2026-06-03", sampleSize: 1500, sampleType: "LV", results: { RightTrack: 39, WrongTrack: 57 } },   // 6/2 to 6/3
  { pollster: "Rasmussen Reports (R)", endDate: "2026-06-04", sampleSize: 1799, sampleType: "LV", results: { RightTrack: 35, WrongTrack: 59 } },   // 5/31 to 6/4
  { pollster: "Quantus Insights", endDate: "2026-06-02", sampleSize: 1050, sampleType: "LV", results: { RightTrack: 36, WrongTrack: 61 } },   // 6/1 to 6/2
  { pollster: "Focaldata", endDate: "2026-06-01", sampleSize: 1537, sampleType: "RV", results: { RightTrack: 24, WrongTrack: 64 } },   // 5/29 to 6/1
  { pollster: "Economist/YouGov", endDate: "2026-06-01", sampleSize: 1453, sampleType: "RV", results: { RightTrack: 31, WrongTrack: 64 } },   // 5/29 to 6/1
  { pollster: "Harvard-Harris", endDate: "2026-05-31", sampleSize: 1725, sampleType: "RV", results: { RightTrack: 36, WrongTrack: 56 } },   // 5/29 to 5/31
  { pollster: "Forbes/HarrisX", endDate: "2026-06-07", sampleSize: 1137, sampleType: "LV", results: { RightTrack: 37, WrongTrack: 55 } },   // 5/20 to 6/7
  // ── Added Nov 17, 2026: post midterm national polls ──
  { pollster: "On Point Polling", endDate: "2026-11-16", sampleSize: 920, sampleType: "RV", results: { RightTrack: 28.3, WrongTrack: 60.2 } },   // On Point national poll, Nov 16, registered voters
  { pollster: "On Point Polling", endDate: "2026-11-06", sampleSize: 1088, sampleType: "RV", results: { RightTrack: 25.4, WrongTrack: 62.0 } },   // On Point post election national poll, Nov 6, registered voters
  // ── Added Oct 28, 2026 ──
  { pollster: "On Point Polling", endDate: "2026-10-28", sampleSize: 672, sampleType: "LV", results: { RightTrack: 31.6, WrongTrack: 61.9 } },   // On Point national poll, Oct 28, likely voters; registered voters 29.9 to 60.3
  // ── Added Oct 5, 2026: June through September releases ──
  { pollster: "Economist/YouGov", endDate: "2026-09-28", sampleSize: 1429, sampleType: "RV", results: { RightTrack: 27, WrongTrack: 66 } },
  { pollster: "Harvard-Harris", endDate: "2026-09-28", sampleSize: 2200, sampleType: "RV", results: { RightTrack: 35, WrongTrack: 52 } },
  { pollster: "Economist/YouGov", endDate: "2026-09-21", sampleSize: 1401, sampleType: "RV", results: { RightTrack: 27, WrongTrack: 65 } },
  { pollster: "Wall Street Journal", endDate: "2026-09-21", sampleSize: 1500, sampleType: "RV", results: { RightTrack: 27, WrongTrack: 68 } },
  { pollster: "Economist/YouGov", endDate: "2026-09-14", sampleSize: 1461, sampleType: "RV", results: { RightTrack: 29, WrongTrack: 64 } },
  { pollster: "Economist/YouGov", endDate: "2026-09-08", sampleSize: 1469, sampleType: "RV", results: { RightTrack: 29, WrongTrack: 65 } },
  { pollster: "Economist/YouGov", endDate: "2026-08-31", sampleSize: 0, sampleType: "RV", results: { RightTrack: 27, WrongTrack: 62 } },   // registered voter count not published
  { pollster: "Harvard-Harris", endDate: "2026-08-30", sampleSize: 2100, sampleType: "RV", results: { RightTrack: 37, WrongTrack: 52 } },
  { pollster: "Economist/YouGov", endDate: "2026-08-17", sampleSize: 1450, sampleType: "RV", results: { RightTrack: 31, WrongTrack: 63 } },
  { pollster: "Economist/YouGov", endDate: "2026-08-03", sampleSize: 1473, sampleType: "RV", results: { RightTrack: 32, WrongTrack: 63 } },
  { pollster: "Harvard-Harris", endDate: "2026-07-12", sampleSize: 1776, sampleType: "RV", results: { RightTrack: 35, WrongTrack: 52 } },
  // ── RCP polls added through May 2026 ──
  { pollster: "Big Data Poll", endDate: "2026-05-27", sampleSize: 2784, sampleType: "LV", results: { RightTrack: 31, WrongTrack: 60 } },
  { pollster: "Economist/YouGov", endDate: "2026-05-26", sampleSize: 1397, sampleType: "RV", results: { RightTrack: 31, WrongTrack: 63 } },
  { pollster: "Rasmussen Reports (R)", endDate: "2026-05-21", sampleSize: 1777, sampleType: "LV", results: { RightTrack: 36, WrongTrack: 57 } },
  { pollster: "Economist/YouGov", endDate: "2026-05-18", sampleSize: 1380, sampleType: "RV", results: { RightTrack: 31, WrongTrack: 62 } },
  { pollster: "New York Times", endDate: "2026-05-15", sampleSize: 1507, sampleType: "RV", results: { RightTrack: 32, WrongTrack: 57 } },
  { pollster: "Rasmussen Reports (R)", endDate: "2026-05-14", sampleSize: 1800, sampleType: "LV", results: { RightTrack: 35, WrongTrack: 59 } },
  { pollster: "Economist/YouGov", endDate: "2026-05-11", sampleSize: 1410, sampleType: "RV", results: { RightTrack: 33, WrongTrack: 59 } },
  { pollster: "Cygnal (R)", endDate: "2026-05-06", sampleSize: 1500, sampleType: "LV", results: { RightTrack: 37, WrongTrack: 60 } },
  { pollster: "Rasmussen Reports (R)", endDate: "2026-05-07", sampleSize: 1724, sampleType: "LV", results: { RightTrack: 36, WrongTrack: 59 } },
  { pollster: "Economist/YouGov", endDate: "2026-05-04", sampleSize: 1409, sampleType: "RV", results: { RightTrack: 30, WrongTrack: 63 } },
  { pollster: "Forbes/HarrisX", endDate: "2026-05-05", sampleSize: 1416, sampleType: "RV", results: { RightTrack: 32, WrongTrack: 60 } },
  { pollster: "Rasmussen Reports (R)", endDate: "2026-04-30", sampleSize: 1827, sampleType: "LV", results: { RightTrack: 36, WrongTrack: 57 } },
  { pollster: "Big Data Poll", endDate: "2026-04-28", sampleSize: 3176, sampleType: "RV", results: { RightTrack: 32, WrongTrack: 60 } },
  { pollster: "ABC/Wash Post/Ipsos", endDate: "2026-04-28", sampleSize: 2059, sampleType: "RV", results: { RightTrack: 34, WrongTrack: 65 } },
  { pollster: "Economist/YouGov", endDate: "2026-04-27", sampleSize: 1647, sampleType: "RV", results: { RightTrack: 32, WrongTrack: 62 } },
  { pollster: "Reuters/Ipsos", endDate: "2026-04-27", sampleSize: 1269, sampleType: "A", results: { RightTrack: 19, WrongTrack: 64 } },
  { pollster: "Harvard-Harris", endDate: "2026-04-26", sampleSize: 2745, sampleType: "RV", results: { RightTrack: 37, WrongTrack: 53 } },
  { pollster: "Rasmussen Reports (R)", endDate: "2026-04-23", sampleSize: 1841, sampleType: "LV", results: { RightTrack: 38, WrongTrack: 56 } },
  { pollster: "Economist/YouGov", endDate: "2026-04-20", sampleSize: 1553, sampleType: "RV", results: { RightTrack: 35, WrongTrack: 57 } },
  { pollster: "Rasmussen Reports (R)", endDate: "2026-04-16", sampleSize: 1765, sampleType: "LV", results: { RightTrack: 40, WrongTrack: 56 } },
  { pollster: "Marquette", endDate: "2026-04-16", sampleSize: 870, sampleType: "RV", results: { RightTrack: 34, WrongTrack: 66 } },
  { pollster: "Economist/YouGov", endDate: "2026-04-13", sampleSize: 1573, sampleType: "RV", results: { RightTrack: 34, WrongTrack: 59 } },
  { pollster: "Rasmussen Reports (R)", endDate: "2026-04-09", sampleSize: 1776, sampleType: "LV", results: { RightTrack: 39, WrongTrack: 55 } },
  { pollster: "NBC News Decision Desk", endDate: "2026-04-13", sampleSize: 32433, sampleType: "A", results: { RightTrack: 33, WrongTrack: 67 } },
  { pollster: "Economist/YouGov", endDate: "2026-04-06", sampleSize: 1560, sampleType: "RV", results: { RightTrack: 33, WrongTrack: 60 } },
  { pollster: "Cygnal (R)", endDate: "2026-04-03", sampleSize: 1500, sampleType: "LV", results: { RightTrack: 38, WrongTrack: 59 } },
  { pollster: "Rasmussen Reports (R)", endDate: "2026-04-02", sampleSize: 1817, sampleType: "LV", results: { RightTrack: 40, WrongTrack: 55 } },
  { pollster: "Economist/YouGov", endDate: "2026-03-30", sampleSize: 1505, sampleType: "RV", results: { RightTrack: 30, WrongTrack: 62 } },
  { pollster: "Harvard-Harris", endDate: "2026-03-26", sampleSize: 2009, sampleType: "RV", results: { RightTrack: 35, WrongTrack: 55 } },
  { pollster: "Quantus Insights", endDate: "2026-03-26", sampleSize: 1472, sampleType: "LV", results: { RightTrack: 36, WrongTrack: 60 } },
  { pollster: "Rasmussen Reports (R)", endDate: "2026-03-26", sampleSize: 1873, sampleType: "LV", results: { RightTrack: 38, WrongTrack: 56 } },
  { pollster: "Big Data Poll", endDate: "2026-03-24", sampleSize: 3003, sampleType: "RV", results: { RightTrack: 33, WrongTrack: 58 } },
  { pollster: "Economist/YouGov", endDate: "2026-03-23", sampleSize: 1502, sampleType: "RV", results: { RightTrack: 34, WrongTrack: 60 } },
  { pollster: "Reuters/Ipsos", endDate: "2026-03-22", sampleSize: 1272, sampleType: "A", results: { RightTrack: 20, WrongTrack: 63 } },
  { pollster: "Quantus Insights", endDate: "2026-03-18", sampleSize: 1064, sampleType: "LV", results: { RightTrack: 40, WrongTrack: 56 } },
  { pollster: "Economist/YouGov", endDate: "2026-03-16", sampleSize: 1429, sampleType: "RV", results: { RightTrack: 34, WrongTrack: 59 } },
  { pollster: "Rasmussen Reports (R)", endDate: "2026-03-12", sampleSize: 1845, sampleType: "LV", results: { RightTrack: 41, WrongTrack: 54 } },
  { pollster: "Economist/YouGov", endDate: "2026-03-09", sampleSize: 1405, sampleType: "RV", results: { RightTrack: 35, WrongTrack: 59 } },
  { pollster: "Cygnal (R)", endDate: "2026-03-04", sampleSize: 1500, sampleType: "LV", results: { RightTrack: 43, WrongTrack: 55 } },
  { pollster: "NPR/PBS/Marist", endDate: "2026-03-04", sampleSize: 1392, sampleType: "RV", results: { RightTrack: 40, WrongTrack: 60 } },
  { pollster: "Rasmussen Reports (R)", endDate: "2026-03-05", sampleSize: 1851, sampleType: "LV", results: { RightTrack: 41, WrongTrack: 54 } },
  { pollster: "Quantus Insights",       endDate: "2026-03-03", sampleSize: 1624,  sampleType: "LV", results: { RightTrack: 41, WrongTrack: 54 } },
  { pollster: "Economist/YouGov",       endDate: "2026-03-02", sampleSize: 1366,  sampleType: "RV", results: { RightTrack: 34, WrongTrack: 58 } },
  { pollster: "Harvard-Harris",         endDate: "2026-02-26", sampleSize: 1999,  sampleType: "RV", results: { RightTrack: 38, WrongTrack: 52 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2026-02-26", sampleSize: 1887,  sampleType: "LV", results: { RightTrack: 40, WrongTrack: 54 } },
  { pollster: "Economist/YouGov",       endDate: "2026-02-23", sampleSize: 1402,  sampleType: "RV", results: { RightTrack: 34, WrongTrack: 58 } },
  { pollster: "Big Data Poll",          endDate: "2026-02-18", sampleSize: 2012,  sampleType: "RV", results: { RightTrack: 36, WrongTrack: 57 } },
  { pollster: "Economist/YouGov",       endDate: "2026-02-16", sampleSize: 1512,  sampleType: "RV", results: { RightTrack: 32, WrongTrack: 60 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2026-02-19", sampleSize: 1899,  sampleType: "LV", results: { RightTrack: 44, WrongTrack: 51 } },
  { pollster: "Reuters/Ipsos",          endDate: "2026-02-16", sampleSize: 1117,  sampleType: "A",  results: { RightTrack: 21, WrongTrack: 64 } },
  { pollster: "Quantus Insights",       endDate: "2026-02-13", sampleSize: 1515,  sampleType: "LV", results: { RightTrack: 38, WrongTrack: 60 } },
  { pollster: "Yahoo News",             endDate: "2026-02-12", sampleSize: 1149,  sampleType: "RV", results: { RightTrack: 34, WrongTrack: 59 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2026-02-12", sampleSize: 1846,  sampleType: "LV", results: { RightTrack: 42, WrongTrack: 52 } },
  { pollster: "Economist/YouGov",       endDate: "2026-02-09", sampleSize: 1551,  sampleType: "RV", results: { RightTrack: 33, WrongTrack: 61 } },
  { pollster: "Cygnal (R)",                 endDate: "2026-02-04", sampleSize: 1500,  sampleType: "LV", results: { RightTrack: 43, WrongTrack: 54 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2026-02-05", sampleSize: 1822,  sampleType: "LV", results: { RightTrack: 36, WrongTrack: 59 } },
  { pollster: "NBC News Decision Desk", endDate: "2026-02-06", sampleSize: 21995, sampleType: "A",  results: { RightTrack: 35, WrongTrack: 65 } },
  { pollster: "Economist/YouGov",       endDate: "2026-02-02", sampleSize: 1504,  sampleType: "RV", results: { RightTrack: 35, WrongTrack: 59 } },
  { pollster: "Harvard-Harris",         endDate: "2026-01-29", sampleSize: 2000,  sampleType: "RV", results: { RightTrack: 38, WrongTrack: 52 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2026-01-29", sampleSize: 1890,  sampleType: "LV", results: { RightTrack: 41, WrongTrack: 54 } },
  { pollster: "Economist/YouGov",       endDate: "2026-01-26", sampleSize: 1520,  sampleType: "RV", results: { RightTrack: 33, WrongTrack: 60 } },
  { pollster: "Big Data Poll",          endDate: "2026-01-24", sampleSize: 3280,  sampleType: "RV", results: { RightTrack: 36, WrongTrack: 53 } },
  { pollster: "Quantus Insights",       endDate: "2026-01-22", sampleSize: 1000,  sampleType: "RV", results: { RightTrack: 35, WrongTrack: 58 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2026-01-22", sampleSize: 1929,  sampleType: "LV", results: { RightTrack: 41, WrongTrack: 53 } },
  { pollster: "Emerson",                endDate: "2026-01-19", sampleSize: 1000,  sampleType: "LV", results: { RightTrack: 44, WrongTrack: 56 } },
  { pollster: "Economist/YouGov",       endDate: "2026-01-19", sampleSize: 1549,  sampleType: "RV", results: { RightTrack: 34, WrongTrack: 59 } },
  { pollster: "NY Times/Siena",         endDate: "2026-01-17", sampleSize: 1625,  sampleType: "RV", results: { RightTrack: 37, WrongTrack: 56 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2026-01-15", sampleSize: 1908,  sampleType: "LV", results: { RightTrack: 37, WrongTrack: 57 } },
  { pollster: "Wall Street Journal",    endDate: "2026-01-13", sampleSize: 1500,  sampleType: "RV", results: { RightTrack: 39, WrongTrack: 57 } },
  { pollster: "Economist/YouGov",       endDate: "2026-01-12", sampleSize: 1437,  sampleType: "RV", results: { RightTrack: 34, WrongTrack: 59 } },
  { pollster: "Quinnipiac",             endDate: "2026-01-12", sampleSize: 1133,  sampleType: "RV", results: { RightTrack: 38, WrongTrack: 56 } },
  { pollster: "Yahoo News",             endDate: "2026-01-12", sampleSize: 1149,  sampleType: "RV", results: { RightTrack: 35, WrongTrack: 58 } },
  { pollster: "Cygnal (R)",                 endDate: "2026-01-08", sampleSize: 1500,  sampleType: "LV", results: { RightTrack: 42, WrongTrack: 55 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2026-01-08", sampleSize: 1880,  sampleType: "LV", results: { RightTrack: 41, WrongTrack: 53 } },
  { pollster: "Economist/YouGov",       endDate: "2026-01-05", sampleSize: 1389,  sampleType: "RV", results: { RightTrack: 38, WrongTrack: 56 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-12-30", sampleSize: 1111,  sampleType: "LV", results: { RightTrack: 40, WrongTrack: 53 } },
  { pollster: "Economist/YouGov",       endDate: "2025-12-29", sampleSize: 1420,  sampleType: "RV", results: { RightTrack: 36, WrongTrack: 57 } },
  { pollster: "Big Data Poll",          endDate: "2025-12-28", sampleSize: 3412,  sampleType: "LV", results: { RightTrack: 36, WrongTrack: 54 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-12-23", sampleSize: 1099,  sampleType: "LV", results: { RightTrack: 40, WrongTrack: 54 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-12-18", sampleSize: 1871,  sampleType: "LV", results: { RightTrack: 40, WrongTrack: 54 } },
  { pollster: "Economist/YouGov",       endDate: "2025-12-22", sampleSize: 1425,  sampleType: "RV", results: { RightTrack: 37, WrongTrack: 55 } },
  { pollster: "Quantus Insights",       endDate: "2025-12-16", sampleSize: 1000,  sampleType: "RV", results: { RightTrack: 34, WrongTrack: 56 } },
  { pollster: "Economist/YouGov",       endDate: "2025-12-15", sampleSize: 1453,  sampleType: "RV", results: { RightTrack: 37, WrongTrack: 56 } },
  { pollster: "Big Data Poll",          endDate: "2025-12-12", sampleSize: 3004,  sampleType: "RV", results: { RightTrack: 38, WrongTrack: 52 } },
  { pollster: "NPR/PBS/Marist",         endDate: "2025-12-11", sampleSize: 1261,  sampleType: "RV", results: { RightTrack: 38, WrongTrack: 61 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-12-11", sampleSize: 1933,  sampleType: "LV", results: { RightTrack: 41, WrongTrack: 53 } },
  { pollster: "Economist/YouGov",       endDate: "2025-12-08", sampleSize: 1380,  sampleType: "RV", results: { RightTrack: 36, WrongTrack: 57 } },
  { pollster: "Cygnal (R)",                 endDate: "2025-12-07", sampleSize: 1500,  sampleType: "LV", results: { RightTrack: 40, WrongTrack: 57 } },
  { pollster: "Quantus Insights",       endDate: "2025-12-05", sampleSize: 1000,  sampleType: "RV", results: { RightTrack: 36, WrongTrack: 55 } },
  { pollster: "Harvard-Harris",         endDate: "2025-12-04", sampleSize: 2204,  sampleType: "RV", results: { RightTrack: 39, WrongTrack: 52 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-12-04", sampleSize: 1890,  sampleType: "LV", results: { RightTrack: 36, WrongTrack: 58 } },
  { pollster: "Economist/YouGov",       endDate: "2025-12-01", sampleSize: 1456,  sampleType: "RV", results: { RightTrack: 36, WrongTrack: 57 } },
  { pollster: "Big Data Poll",          endDate: "2025-12-01", sampleSize: 2008,  sampleType: "RV", results: { RightTrack: 36, WrongTrack: 52 } },
  { pollster: "NBC News Decision Desk", endDate: "2025-12-08", sampleSize: 20252, sampleType: "A",  results: { RightTrack: 36, WrongTrack: 64 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-11-25", sampleSize: 1176,  sampleType: "LV", results: { RightTrack: 40, WrongTrack: 54 } },
  { pollster: "Economist/YouGov",       endDate: "2025-11-24", sampleSize: 1511,  sampleType: "RV", results: { RightTrack: 37, WrongTrack: 55 } },
  { pollster: "Big Data Poll",          endDate: "2025-11-21", sampleSize: 2006,  sampleType: "RV", results: { RightTrack: 36, WrongTrack: 53 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-11-20", sampleSize: 2020,  sampleType: "LV", results: { RightTrack: 39, WrongTrack: 54 } },
  { pollster: "Economist/YouGov",       endDate: "2025-11-17", sampleSize: 1382,  sampleType: "RV", results: { RightTrack: 34, WrongTrack: 59 } },
  { pollster: "Quantus Insights",       endDate: "2025-11-12", sampleSize: 1000,  sampleType: "RV", results: { RightTrack: 35, WrongTrack: 55 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-11-13", sampleSize: 1925,  sampleType: "LV", results: { RightTrack: 36, WrongTrack: 59 } },
  { pollster: "Marquette",              endDate: "2025-11-12", sampleSize: 1052,  sampleType: "A",  results: { RightTrack: 34, WrongTrack: 66 } },
  { pollster: "Economist/YouGov",       endDate: "2025-11-10", sampleSize: 1500,  sampleType: "RV", results: { RightTrack: 35, WrongTrack: 58 } },
  { pollster: "Cygnal (R)",                 endDate: "2025-11-06", sampleSize: 1500,  sampleType: "RV", results: { RightTrack: 37, WrongTrack: 59 } },
  { pollster: "Harvard-Harris",         endDate: "2025-11-06", sampleSize: 2000,  sampleType: "RV", results: { RightTrack: 35, WrongTrack: 54 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-11-06", sampleSize: 2022,  sampleType: "LV", results: { RightTrack: 38, WrongTrack: 57 } },
  { pollster: "Economist/YouGov",       endDate: "2025-11-03", sampleSize: 1475,  sampleType: "RV", results: { RightTrack: 35, WrongTrack: 57 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-10-30", sampleSize: 1929,  sampleType: "LV", results: { RightTrack: 40, WrongTrack: 55 } },
  { pollster: "NewsNation",             endDate: "2025-10-29", sampleSize: 1159,  sampleType: "LV", results: { RightTrack: 40, WrongTrack: 60 } },
  { pollster: "Big Data Poll",          endDate: "2025-10-28", sampleSize: 2984,  sampleType: "RV", results: { RightTrack: 39, WrongTrack: 51 } },
  { pollster: "NBC News",               endDate: "2025-10-28", sampleSize: 1000,  sampleType: "RV", results: { RightTrack: 37, WrongTrack: 61 } },
  { pollster: "ABC/Wash Post/Ipsos",    endDate: "2025-10-28", sampleSize: 2203,  sampleType: "RV", results: { RightTrack: 34, WrongTrack: 65 } },
  { pollster: "Economist/YouGov",       endDate: "2025-10-27", sampleSize: 1476,  sampleType: "RV", results: { RightTrack: 35, WrongTrack: 59 } },
  { pollster: "Yahoo News",             endDate: "2025-10-27", sampleSize: 1197,  sampleType: "RV", results: { RightTrack: 35, WrongTrack: 58 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-10-23", sampleSize: 1925,  sampleType: "LV", results: { RightTrack: 39, WrongTrack: 54 } },
  { pollster: "Economist/YouGov",       endDate: "2025-10-20", sampleSize: 1448,  sampleType: "RV", results: { RightTrack: 34, WrongTrack: 58 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-10-16", sampleSize: 1995,  sampleType: "LV", results: { RightTrack: 43, WrongTrack: 51 } },
  { pollster: "Economist/YouGov",       endDate: "2025-10-13", sampleSize: 1467,  sampleType: "RV", results: { RightTrack: 35, WrongTrack: 57 } },
  { pollster: "Cygnal (R)",                 endDate: "2025-10-08", sampleSize: 1500,  sampleType: "LV", results: { RightTrack: 42, WrongTrack: 55 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-10-09", sampleSize: 1964,  sampleType: "LV", results: { RightTrack: 44, WrongTrack: 52 } },
  { pollster: "Economist/YouGov",       endDate: "2025-10-06", sampleSize: 1490,  sampleType: "RV", results: { RightTrack: 34, WrongTrack: 58 } },
  { pollster: "Harvard-Harris",         endDate: "2025-10-02", sampleSize: 2413,  sampleType: "RV", results: { RightTrack: 40, WrongTrack: 50 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-10-02", sampleSize: 1943,  sampleType: "LV", results: { RightTrack: 41, WrongTrack: 53 } },
  { pollster: "Economist/YouGov",       endDate: "2025-09-29", sampleSize: 1518,  sampleType: "RV", results: { RightTrack: 37, WrongTrack: 57 } },
  { pollster: "Yahoo News",             endDate: "2025-09-29", sampleSize: 1129,  sampleType: "RV", results: { RightTrack: 34, WrongTrack: 59 } },
  { pollster: "NY Times/Siena",         endDate: "2025-09-27", sampleSize: 1313,  sampleType: "RV", results: { RightTrack: 36, WrongTrack: 58 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-09-25", sampleSize: 1951,  sampleType: "LV", results: { RightTrack: 42, WrongTrack: 52 } },
  { pollster: "Economist/YouGov",       endDate: "2025-09-22", sampleSize: 1392,  sampleType: "RV", results: { RightTrack: 35, WrongTrack: 59 } },
  { pollster: "Quantus Insights",       endDate: "2025-09-21", sampleSize: 1000,  sampleType: "LV", results: { RightTrack: 42, WrongTrack: 54 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-09-18", sampleSize: 1932,  sampleType: "LV", results: { RightTrack: 42, WrongTrack: 52 } },
  { pollster: "Economist/YouGov",       endDate: "2025-09-15", sampleSize: 1420,  sampleType: "RV", results: { RightTrack: 32, WrongTrack: 62 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-09-11", sampleSize: 2509,  sampleType: "RV", results: { RightTrack: 42, WrongTrack: 53 } },
  { pollster: "Economist/YouGov",       endDate: "2025-09-08", sampleSize: 1487,  sampleType: "RV", results: { RightTrack: 37, WrongTrack: 57 } },
  { pollster: "Cygnal (R)",                 endDate: "2025-09-03", sampleSize: 1500,  sampleType: "RV", results: { RightTrack: 43, WrongTrack: 54 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-09-04", sampleSize: 1578,  sampleType: "LV", results: { RightTrack: 44, WrongTrack: 52 } },
  { pollster: "Economist/YouGov",       endDate: "2025-09-02", sampleSize: 1549,  sampleType: "RV", results: { RightTrack: 39, WrongTrack: 55 } },
  { pollster: "Yahoo News",             endDate: "2025-09-02", sampleSize: 1138,  sampleType: "RV", results: { RightTrack: 36, WrongTrack: 57 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-08-28", sampleSize: 1932,  sampleType: "LV", results: { RightTrack: 45, WrongTrack: 50 } },
  { pollster: "Economist/YouGov",       endDate: "2025-08-25", sampleSize: 1377,  sampleType: "RV", results: { RightTrack: 38, WrongTrack: 56 } },
  { pollster: "Reuters/Ipsos",          endDate: "2025-08-24", sampleSize: 1022,  sampleType: "A",  results: { RightTrack: 30, WrongTrack: 57 } },
  { pollster: "Harvard-Harris",         endDate: "2025-08-21", sampleSize: 2025,  sampleType: "RV", results: { RightTrack: 40, WrongTrack: 50 } },
  { pollster: "NBC News Decision Desk", endDate: "2025-09-01", sampleSize: 30196, sampleType: "A",  results: { RightTrack: 39, WrongTrack: 61 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-08-21", sampleSize: 1906,  sampleType: "LV", results: { RightTrack: 46, WrongTrack: 49 } },
  { pollster: "Economist/YouGov",       endDate: "2025-08-18", sampleSize: 1408,  sampleType: "RV", results: { RightTrack: 38, WrongTrack: 55 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-08-14", sampleSize: 1967,  sampleType: "LV", results: { RightTrack: 44, WrongTrack: 49 } },
  { pollster: "Economist/YouGov",       endDate: "2025-08-11", sampleSize: 1474,  sampleType: "RV", results: { RightTrack: 39, WrongTrack: 53 } },
  { pollster: "Cygnal (R)",                 endDate: "2025-08-09", sampleSize: 1500,  sampleType: "RV", results: { RightTrack: 44, WrongTrack: 53 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-08-07", sampleSize: 1953,  sampleType: "LV", results: { RightTrack: 43, WrongTrack: 51 } },
  { pollster: "Economist/YouGov",       endDate: "2025-08-04", sampleSize: 1528,  sampleType: "RV", results: { RightTrack: 38, WrongTrack: 55 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-07-31", sampleSize: 2027,  sampleType: "LV", results: { RightTrack: 45, WrongTrack: 50 } },
  { pollster: "Economist/YouGov",       endDate: "2025-07-28", sampleSize: 1610,  sampleType: "RV", results: { RightTrack: 39, WrongTrack: 54 } },
  { pollster: "Yahoo News",             endDate: "2025-07-28", sampleSize: 1168,  sampleType: "RV", results: { RightTrack: 40, WrongTrack: 54 } },
  { pollster: "Reuters/Ipsos",          endDate: "2025-07-27", sampleSize: 1023,  sampleType: "A",  results: { RightTrack: 29, WrongTrack: 56 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-07-27", sampleSize: 1709,  sampleType: "LV", results: { RightTrack: 44, WrongTrack: 52 } },
  { pollster: "Economist/YouGov",       endDate: "2025-07-21", sampleSize: 1551,  sampleType: "RV", results: { RightTrack: 37, WrongTrack: 56 } },
  { pollster: "Wall Street Journal",    endDate: "2025-07-20", sampleSize: 1500,  sampleType: "RV", results: { RightTrack: 39, WrongTrack: 55 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-07-17", sampleSize: 1932,  sampleType: "LV", results: { RightTrack: 45, WrongTrack: 50 } },
  { pollster: "Big Data Poll",          endDate: "2025-07-14", sampleSize: 3022,  sampleType: "RV", results: { RightTrack: 39, WrongTrack: 51 } },
  { pollster: "Marquette",              endDate: "2025-07-16", sampleSize: 1005,  sampleType: "A",  results: { RightTrack: 40, WrongTrack: 60 } },
  { pollster: "Economist/YouGov",       endDate: "2025-07-14", sampleSize: 1506,  sampleType: "RV", results: { RightTrack: 38, WrongTrack: 55 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-07-10", sampleSize: 2178,  sampleType: "LV", results: { RightTrack: 45, WrongTrack: 49 } },
  { pollster: "Harvard-Harris",         endDate: "2025-07-08", sampleSize: 2044,  sampleType: "RV", results: { RightTrack: 40, WrongTrack: 51 } },
  { pollster: "Economist/YouGov",       endDate: "2025-07-07", sampleSize: 1389,  sampleType: "RV", results: { RightTrack: 39, WrongTrack: 55 } },
  { pollster: "Cygnal (R)",                 endDate: "2025-07-02", sampleSize: 1500,  sampleType: "LV", results: { RightTrack: 44, WrongTrack: 52 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-07-02", sampleSize: 1484,  sampleType: "LV", results: { RightTrack: 44, WrongTrack: 50 } },
  { pollster: "Economist/YouGov",       endDate: "2025-06-30", sampleSize: 1491,  sampleType: "RV", results: { RightTrack: 38, WrongTrack: 56 } },
  { pollster: "Emerson",                endDate: "2025-06-25", sampleSize: 1000,  sampleType: "RV", results: { RightTrack: 48, WrongTrack: 53 } },
  { pollster: "Yahoo News",             endDate: "2025-06-30", sampleSize: 1074,  sampleType: "RV", results: { RightTrack: 39, WrongTrack: 55 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-06-26", sampleSize: 1961,  sampleType: "LV", results: { RightTrack: 45, WrongTrack: 49 } },
  { pollster: "Economist/YouGov",       endDate: "2025-06-23", sampleSize: 1455,  sampleType: "RV", results: { RightTrack: 36, WrongTrack: 55 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-06-19", sampleSize: 1855,  sampleType: "LV", results: { RightTrack: 47, WrongTrack: 47 } },
  { pollster: "Economist/YouGov",       endDate: "2025-06-16", sampleSize: 1351,  sampleType: "RV", results: { RightTrack: 38, WrongTrack: 54 } },
  { pollster: "Harvard-Harris",         endDate: "2025-06-12", sampleSize: 2097,  sampleType: "RV", results: { RightTrack: 41, WrongTrack: 51 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-06-12", sampleSize: 1772,  sampleType: "LV", results: { RightTrack: 48, WrongTrack: 47 } },
  { pollster: "Economist/YouGov",       endDate: "2025-06-09", sampleSize: 1397,  sampleType: "RV", results: { RightTrack: 38, WrongTrack: 54 } },
  { pollster: "Cygnal (R)",                 endDate: "2025-06-04", sampleSize: 1500,  sampleType: "LV", results: { RightTrack: 47, WrongTrack: 50 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-06-05", sampleSize: 1752,  sampleType: "LV", results: { RightTrack: 44, WrongTrack: 51 } },
  { pollster: "Quantus Insights",       endDate: "2025-06-04", sampleSize: 1000,  sampleType: "RV", results: { RightTrack: 45, WrongTrack: 51 } },
  { pollster: "NBC News Decision Desk", endDate: "2025-06-10", sampleSize: 19410, sampleType: "A",  results: { RightTrack: 39, WrongTrack: 61 } },
  { pollster: "Economist/YouGov",       endDate: "2025-06-02", sampleSize: 1436,  sampleType: "RV", results: { RightTrack: 42, WrongTrack: 51 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-05-29", sampleSize: 1832,  sampleType: "LV", results: { RightTrack: 48, WrongTrack: 46 } },
  { pollster: "Economist/YouGov",       endDate: "2025-05-26", sampleSize: 1486,  sampleType: "RV", results: { RightTrack: 41, WrongTrack: 51 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-05-22", sampleSize: 1810,  sampleType: "LV", results: { RightTrack: 48, WrongTrack: 47 } },
  { pollster: "Economist/YouGov",       endDate: "2025-05-19", sampleSize: 1558,  sampleType: "RV", results: { RightTrack: 41, WrongTrack: 52 } },
  { pollster: "Harvard-Harris",         endDate: "2025-05-15", sampleSize: 1903,  sampleType: "RV", results: { RightTrack: 42, WrongTrack: 49 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-05-15", sampleSize: 1716,  sampleType: "LV", results: { RightTrack: 47, WrongTrack: 47 } },
  { pollster: "Economist/YouGov",       endDate: "2025-05-12", sampleSize: 1610,  sampleType: "RV", results: { RightTrack: 42, WrongTrack: 49 } },
  { pollster: "Marquette",              endDate: "2025-05-15", sampleSize: 1004,  sampleType: "A",  results: { RightTrack: 42, WrongTrack: 58 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-05-08", sampleSize: 1762,  sampleType: "LV", results: { RightTrack: 47, WrongTrack: 47 } },
  { pollster: "Quantus Insights",       endDate: "2025-05-07", sampleSize: 1000,  sampleType: "RV", results: { RightTrack: 44, WrongTrack: 50 } },
  { pollster: "Big Data Poll",          endDate: "2025-05-05", sampleSize: 3128,  sampleType: "RV", results: { RightTrack: 41, WrongTrack: 48 } },
  { pollster: "Economist/YouGov",       endDate: "2025-05-05", sampleSize: 1693,  sampleType: "RV", results: { RightTrack: 40, WrongTrack: 53 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-05-01", sampleSize: 1823,  sampleType: "LV", results: { RightTrack: 45, WrongTrack: 51 } },
  { pollster: "Emerson",                endDate: "2025-04-28", sampleSize: 1000,  sampleType: "RV", results: { RightTrack: 48, WrongTrack: 52 } },
  { pollster: "Economist/YouGov",       endDate: "2025-04-28", sampleSize: 1626,  sampleType: "RV", results: { RightTrack: 36, WrongTrack: 54 } },
  { pollster: "Yahoo News",             endDate: "2025-04-28", sampleSize: 1071,  sampleType: "RV", results: { RightTrack: 38, WrongTrack: 52 } },
  { pollster: "NewsNation",             endDate: "2025-04-27", sampleSize: 1448,  sampleType: "RV", results: { RightTrack: 41, WrongTrack: 59 } },
  { pollster: "NY Times/Siena",         endDate: "2025-04-24", sampleSize: 913,   sampleType: "RV", results: { RightTrack: 36, WrongTrack: 53 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-04-24", sampleSize: 1767,  sampleType: "LV", results: { RightTrack: 42, WrongTrack: 51 } },
  { pollster: "Economist/YouGov",       endDate: "2025-04-22", sampleSize: 1446,  sampleType: "RV", results: { RightTrack: 39, WrongTrack: 53 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-04-17", sampleSize: 1755,  sampleType: "LV", results: { RightTrack: 46, WrongTrack: 48 } },
  { pollster: "Economist/YouGov",       endDate: "2025-04-15", sampleSize: 1329,  sampleType: "RV", results: { RightTrack: 38, WrongTrack: 52 } },
  { pollster: "Harvard-Harris",         endDate: "2025-04-10", sampleSize: 2286,  sampleType: "RV", results: { RightTrack: 39, WrongTrack: 49 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-04-10", sampleSize: 1811,  sampleType: "LV", results: { RightTrack: 43, WrongTrack: 51 } },
  { pollster: "Economist/YouGov",       endDate: "2025-04-08", sampleSize: 1563,  sampleType: "RV", results: { RightTrack: 39, WrongTrack: 53 } },
  { pollster: "HarrisX",                endDate: "2025-04-07", sampleSize: 1883,  sampleType: "RV", results: { RightTrack: 39, WrongTrack: 51 } },
  { pollster: "Cygnal (R)",                 endDate: "2025-04-03", sampleSize: 1500,  sampleType: "LV", results: { RightTrack: 44, WrongTrack: 53 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-04-03", sampleSize: 1746,  sampleType: "LV", results: { RightTrack: 45, WrongTrack: 50 } },
  { pollster: "Reuters/Ipsos",          endDate: "2025-04-02", sampleSize: 1486,  sampleType: "A",  results: { RightTrack: 32, WrongTrack: 53 } },
  { pollster: "Economist/YouGov",       endDate: "2025-04-01", sampleSize: 1465,  sampleType: "RV", results: { RightTrack: 40, WrongTrack: 51 } },
  { pollster: "Wall Street Journal",    endDate: "2025-04-01", sampleSize: 1500,  sampleType: "RV", results: { RightTrack: 41, WrongTrack: 51 } },
  { pollster: "Harvard-Harris",         endDate: "2025-03-27", sampleSize: 2746,  sampleType: "RV", results: { RightTrack: 41, WrongTrack: 49 } },
  { pollster: "Quantus Insights",       endDate: "2025-03-27", sampleSize: 1000,  sampleType: "RV", results: { RightTrack: 44, WrongTrack: 49 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-03-27", sampleSize: 1777,  sampleType: "LV", results: { RightTrack: 45, WrongTrack: 50 } },
  { pollster: "Economist/YouGov",       endDate: "2025-03-25", sampleSize: 1440,  sampleType: "RV", results: { RightTrack: 42, WrongTrack: 51 } },
  { pollster: "Reuters/Ipsos",          endDate: "2025-03-23", sampleSize: 1030,  sampleType: "A",  results: { RightTrack: 30, WrongTrack: 53 } },
  { pollster: "Marquette",              endDate: "2025-03-27", sampleSize: 1021,  sampleType: "A",  results: { RightTrack: 42, WrongTrack: 58 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-03-20", sampleSize: 1965,  sampleType: "LV", results: { RightTrack: 45, WrongTrack: 50 } },
  { pollster: "Economist/YouGov",       endDate: "2025-03-18", sampleSize: 1458,  sampleType: "RV", results: { RightTrack: 43, WrongTrack: 48 } },
  { pollster: "Reuters/Ipsos",          endDate: "2025-03-12", sampleSize: 1422,  sampleType: "A",  results: { RightTrack: 33, WrongTrack: 52 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-03-13", sampleSize: 1860,  sampleType: "LV", results: { RightTrack: 45, WrongTrack: 48 } },
  { pollster: "Quantus Insights",       endDate: "2025-03-12", sampleSize: 1000,  sampleType: "RV", results: { RightTrack: 44, WrongTrack: 49 } },
  { pollster: "Economist/YouGov",       endDate: "2025-03-11", sampleSize: 1532,  sampleType: "RV", results: { RightTrack: 39, WrongTrack: 52 } },
  { pollster: "NBC News",               endDate: "2025-03-11", sampleSize: 1000,  sampleType: "RV", results: { RightTrack: 44, WrongTrack: 54 } },
  { pollster: "Emerson",                endDate: "2025-03-10", sampleSize: 1000,  sampleType: "RV", results: { RightTrack: 50, WrongTrack: 50 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-03-06", sampleSize: 1883,  sampleType: "LV", results: { RightTrack: 43, WrongTrack: 52 } },
  { pollster: "Reuters/Ipsos",          endDate: "2025-03-04", sampleSize: 1174,  sampleType: "A",  results: { RightTrack: 34, WrongTrack: 49 } },
  { pollster: "Economist/YouGov",       endDate: "2025-03-04", sampleSize: 1491,  sampleType: "RV", results: { RightTrack: 40, WrongTrack: 51 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-02-27", sampleSize: 2033,  sampleType: "LV", results: { RightTrack: 45, WrongTrack: 50 } },
  { pollster: "NPR/PBS/Marist",         endDate: "2025-02-26", sampleSize: 1533,  sampleType: "RV", results: { RightTrack: 45, WrongTrack: 54 } },
  { pollster: "Economist/YouGov",       endDate: "2025-02-25", sampleSize: 1444,  sampleType: "RV", results: { RightTrack: 41, WrongTrack: 49 } },
  { pollster: "Reuters/Ipsos",          endDate: "2025-02-23", sampleSize: 1029,  sampleType: "A",  results: { RightTrack: 31, WrongTrack: 50 } },
  { pollster: "Harvard-Harris",         endDate: "2025-02-20", sampleSize: 2443,  sampleType: "RV", results: { RightTrack: 42, WrongTrack: 48 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-02-20", sampleSize: 1991,  sampleType: "LV", results: { RightTrack: 48, WrongTrack: 47 } },
  { pollster: "Economist/YouGov",       endDate: "2025-02-18", sampleSize: 1451,  sampleType: "RV", results: { RightTrack: 41, WrongTrack: 49 } },
  { pollster: "Reuters/Ipsos",          endDate: "2025-02-18", sampleSize: 4125,  sampleType: "A",  results: { RightTrack: 34, WrongTrack: 49 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-02-13", sampleSize: 2004,  sampleType: "LV", results: { RightTrack: 46, WrongTrack: 47 } },
  { pollster: "Economist/YouGov",       endDate: "2025-02-11", sampleSize: 1430,  sampleType: "RV", results: { RightTrack: 38, WrongTrack: 53 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-02-06", sampleSize: 2078,  sampleType: "LV", results: { RightTrack: 45, WrongTrack: 48 } },
  { pollster: "Economist/YouGov",       endDate: "2025-02-04", sampleSize: 1423,  sampleType: "RV", results: { RightTrack: 40, WrongTrack: 50 } },
  { pollster: "Marquette",              endDate: "2025-02-05", sampleSize: 1063,  sampleType: "A",  results: { RightTrack: 38, WrongTrack: 62 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-01-30", sampleSize: 2096,  sampleType: "LV", results: { RightTrack: 46, WrongTrack: 49 } },
  { pollster: "Emerson",                endDate: "2025-01-28", sampleSize: 1000,  sampleType: "RV", results: { RightTrack: 52, WrongTrack: 48 } },
  { pollster: "Economist/YouGov",       endDate: "2025-01-28", sampleSize: 1376,  sampleType: "RV", results: { RightTrack: 40, WrongTrack: 50 } },
  { pollster: "Reuters/Ipsos",          endDate: "2025-01-26", sampleSize: 1034,  sampleType: "A",  results: { RightTrack: 25, WrongTrack: 54 } },
  { pollster: "Rasmussen Reports (R)",      endDate: "2025-01-23", sampleSize: 2070,  sampleType: "LV", results: { RightTrack: 39, WrongTrack: 52 } },
  { pollster: "Reuters/Ipsos",          endDate: "2025-01-21", sampleSize: 1077,  sampleType: "A",  results: { RightTrack: 29, WrongTrack: 45 } },
  { pollster: "Economist/YouGov",       endDate: "2025-01-21", sampleSize: 1426,  sampleType: "RV", results: { RightTrack: 28, WrongTrack: 61 } },
];
