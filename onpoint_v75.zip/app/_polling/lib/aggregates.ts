import {
  Poll,
  getDateRange,
  getCandidateList,
  buildDailyWeightedSeries, pollSharesOn,
  getPollsterEntry,
  isExcludedPollster, rLeanFirms, leanFirms2028, R_LEAN_FIRMS, type ModelOptions,
} from "./buildDailyModel";

import { RAW_POLLS as GENERIC, GOLD_STANDARD_NAMES as GENERIC_GOLD } from "../genericballot/data";
import { RAW_POLLS as TRUMP, GOLD_STANDARD_NAMES as TRUMP_GOLD } from "../donaldtrumpapproval/data";
import { RAW_POLLS as VANCE, GOLD_STANDARD_NAMES as VANCE_GOLD } from "../jdvanceapproval/data";
import { RAW_POLLS as TRACK, GOLD_STANDARD_NAMES as TRACK_GOLD } from "../rightorwrongtrack/data";
import { GENERAL_2028_AGGS, PRIMARY_2028_MULTI } from "../2028/matchups";
import { GOLD_2026, LEAN_CAL_2026 } from "./ratings2026";

// 2025 governor races
import { VA_GOV_POLLS, NJ_GOV_POLLS } from "../2025pollingview/data";

// 2024 president (national + states)
import { RAW_POLLS as PR_NAT } from "../2024president/data";
import { RAW_POLLS as PR_PA } from "../pa2024president/data";
import { RAW_POLLS as PR_GA } from "../ga2024president/data";
import { RAW_POLLS as PR_AZ } from "../az2024president/data";
import { RAW_POLLS as PR_MI } from "../mi2024president/data";
import { RAW_POLLS as PR_NV } from "../nv2024president/data";
import { RAW_POLLS as PR_WI } from "../wi2024president/data";
import { RAW_POLLS as PR_NC } from "../nc2024president/data";
import { RAW_POLLS as PR_MN } from "../mn2024president/data";
import { RAW_POLLS as PR_NM } from "../nm2024president/data";
import { RAW_POLLS as PR_NJ } from "../nj2024president/data";
import { RAW_POLLS as PR_NH } from "../newhampshire/data";
import { RAW_POLLS as PR_TX } from "../tx2024president/data";
import { RAW_POLLS as PR_VA } from "../va2024president/data";

// multi-candidate primaries
import { RAW_POLLS as FL_GOP } from "../floridarepublicanprimary/data";
import { RAW_POLLS as TX_GOP } from "../texasrepublicanprimary/data";
import { RAW_POLLS as TX_DEM } from "../texasdemocratprimary/data";
import { RAW_POLLS as ME_DEM } from "../mainedemocratprimary/data";
import { KY04_POLLS } from "./ky04Polls";

// 2026 Senate matchups (state modules with RACES + STATE_POLLS keyed by raceId)
// Every 2026 Senate and governor race the forecast carries polls for. These
// files are generated from the forecast's own poll feed, so the averages on
// this page and the margins on the forecast desk read the same polls.
import * as SEN_ALABAMA from "../senatepolling/alabama";
import * as SEN_ALASKA from "../senatepolling/alaska";
import * as SEN_ARKANSAS from "../senatepolling/arkansas";
import * as SEN_COLORADO from "../senatepolling/colorado";
import * as SEN_DELAWARE from "../senatepolling/delaware";
import * as SEN_FLORIDA from "../senatepolling/florida";
import * as SEN_GEORGIA from "../senatepolling/georgia";
import * as SEN_IDAHO from "../senatepolling/idaho";
import * as SEN_ILLINOIS from "../senatepolling/illinois";
import * as SEN_IOWA from "../senatepolling/iowa";
import * as SEN_KANSAS from "../senatepolling/kansas";
import * as SEN_KENTUCKY from "../senatepolling/kentucky";
import * as SEN_LOUISIANA from "../senatepolling/louisiana";
import * as SEN_MAINE from "../senatepolling/maine";
import * as SEN_MASSACHUSETTS from "../senatepolling/massachusetts";
import * as SEN_MICHIGAN from "../senatepolling/michigan";
import * as SEN_MINNESOTA from "../senatepolling/minnesota";
import * as SEN_MISSISSIPPI from "../senatepolling/mississippi";
import * as SEN_MONTANA from "../senatepolling/montana";
import * as SEN_NEBRASKA from "../senatepolling/nebraska";
import * as SEN_NEWHAMPSHIRE from "../senatepolling/newhampshire";
import * as SEN_NEWJERSEY from "../senatepolling/newjersey";
import * as SEN_NEWMEXICO from "../senatepolling/newmexico";
import * as SEN_NORTHCAROLINA from "../senatepolling/northcarolina";
import * as SEN_OHIO from "../senatepolling/ohio";
import * as SEN_OKLAHOMA from "../senatepolling/oklahoma";
import * as SEN_OREGON from "../senatepolling/oregon";
import * as SEN_RHODEISLAND from "../senatepolling/rhodeisland";
import * as SEN_SOUTHCAROLINA from "../senatepolling/southcarolina";
import * as SEN_SOUTHDAKOTA from "../senatepolling/southdakota";
import * as SEN_TENNESSEE from "../senatepolling/tennessee";
import * as SEN_TEXAS from "../senatepolling/texas";
import * as SEN_VIRGINIA from "../senatepolling/virginia";
import * as SEN_WESTVIRGINIA from "../senatepolling/westvirginia";
import * as SEN_WYOMING from "../senatepolling/wyoming";
import * as GOV_ALABAMA from "../governorpolling/alabama";
import * as GOV_ALASKA from "../governorpolling/alaska";
import * as GOV_ARIZONA from "../governorpolling/arizona";
import * as GOV_ARKANSAS from "../governorpolling/arkansas";
import * as GOV_CALIFORNIA from "../governorpolling/california";
import * as GOV_COLORADO from "../governorpolling/colorado";
import * as GOV_CONNECTICUT from "../governorpolling/connecticut";
import * as GOV_FLORIDA from "../governorpolling/florida";
import * as GOV_GEORGIA from "../governorpolling/georgia";
import * as GOV_HAWAII from "../governorpolling/hawaii";
import * as GOV_IDAHO from "../governorpolling/idaho";
import * as GOV_ILLINOIS from "../governorpolling/illinois";
import * as GOV_IOWA from "../governorpolling/iowa";
import * as GOV_KANSAS from "../governorpolling/kansas";
import * as GOV_MAINE from "../governorpolling/maine";
import * as GOV_MARYLAND from "../governorpolling/maryland";
import * as GOV_MASSACHUSETTS from "../governorpolling/massachusetts";
import * as GOV_MICHIGAN from "../governorpolling/michigan";
import * as GOV_MINNESOTA from "../governorpolling/minnesota";
import * as GOV_NEBRASKA from "../governorpolling/nebraska";
import * as GOV_NEVADA from "../governorpolling/nevada";
import * as GOV_NEWHAMPSHIRE from "../governorpolling/newhampshire";
import * as GOV_NEWMEXICO from "../governorpolling/newmexico";
import * as GOV_NEWYORK from "../governorpolling/newyork";
import * as GOV_OHIO from "../governorpolling/ohio";
import * as GOV_OKLAHOMA from "../governorpolling/oklahoma";
import * as GOV_OREGON from "../governorpolling/oregon";
import * as GOV_PENNSYLVANIA from "../governorpolling/pennsylvania";
import * as GOV_RHODEISLAND from "../governorpolling/rhodeisland";
import * as GOV_SOUTHCAROLINA from "../governorpolling/southcarolina";
import * as GOV_SOUTHDAKOTA from "../governorpolling/southdakota";
import * as GOV_TENNESSEE from "../governorpolling/tennessee";
import * as GOV_TEXAS from "../governorpolling/texas";
import * as GOV_VERMONT from "../governorpolling/vermont";
import * as GOV_WISCONSIN from "../governorpolling/wisconsin";
import * as GOV_WYOMING from "../governorpolling/wyoming";

// authoritative featured matchups (generic Republican/Democrat keys) from the polling index
import { TX_CORNYN_POLLS, TX_PAXTON_POLLS } from "./txSenatePolls";

/* =============================================================================
   Aggregate registry — every On Point Polling two-series polling average in one place,
   normalised to a shared shape so the unified Polling Averages page can switch
   between them with one chart + table.
============================================================================= */

export type Series = { label: string; color: string; party?: string };

export type AggregateDef = {
  id: string;
  label: string;       // switcher label
  category: string;    // grouping tag
  title: string;       // headline
  subtitle: string;
  unit: "%" | "pt";    // axis unit
  keyA: string;
  keyB: string;
  seriesA: Series;
  seriesB: Series;
  marginLabel: string;
  fmtMargin: (net: number) => string;
  polls: Poll[];
  gold: string[];
  goldMult: number;
  /** Two-letter postal code, set only on the 2026 Senate and governor races so the
   *  Polling Averages page can place each one on a map. */
  stateAbbr?: string;
};

export type AggDaily = { date: string; t: number; a: number; b: number; net: number };
export type AggPollPoint = {
  share?: number;
  /** where the average counts the poll, after a measured partisan lean is taken off; equal to a, b otherwise */
  adjA?: number; adjB?: number; adjMargin?: number;
  lean?: { dir: "R" | "D"; pts: number; firms: string };
  pollster: string;
  date: string;
  t: number;
  a: number;
  b: number;
  margin: number;
  sampleSize: number;
  sampleType: string;
  grade: string;
  /** Points taken off a Republican leaning firm's margin, toward the Democrat, before it entered the average. */
  rLean?: number;
};

const BLUE = "var(--dem)";
const RED = "var(--gop)";
const GREEN = "var(--approve)";
const AMBER = "#e0a23b";
// Independents take the desk's purple, not an amber that reads as a shade of red.
// Osborn, Bengs, Achilles, Bodnar and Block are all running as independents, and on a
// two-colour page an amber sat close enough to the Republican tone to be misread.
const IND_PURPLE = "#7a4bb0";
const MAGENTA = "var(--disapprove)";

function round1(n: number) { return Math.round(n * 10) / 10; }
const netPM = (n: number) => (Math.abs(n) < 0.05 ? "Even" : n > 0 ? `+${n.toFixed(1)}` : `−${Math.abs(n).toFixed(1)}`);
const dvrMargin = (n: number) => (Math.abs(n) < 0.05 ? "Even" : n > 0 ? `D+${n.toFixed(1)}` : `R+${Math.abs(n).toFixed(1)}`);

// Dem-vs-Rep race factory (president + governor): A = Dem (blue), B = Rep (red).
function dvr(id: string, label: string, category: string, title: string, polls: Poll[], aLabel: string, bLabel: string, aKey: string, bKey: string): AggregateDef {
  return {
    id, label, category, title,
    subtitle: "Daily On Point Polling weighted average of every public poll of this race — recency decay, sample-size sigmoid, voter screen, and pollster grade.",
    unit: "%", keyA: aKey, keyB: bKey,
    seriesA: { label: aLabel, color: BLUE }, seriesB: { label: bLabel, color: RED },
    marginLabel: "Margin", fmtMargin: dvrMargin, polls, gold: [], goldMult: 1,
  };
}

const STATES_2024: [string, string, Poll[]][] = [
  ["pa", "Pennsylvania", PR_PA], ["ga", "Georgia", PR_GA], ["az", "Arizona", PR_AZ], ["mi", "Michigan", PR_MI],
  ["nv", "Nevada", PR_NV], ["wi", "Wisconsin", PR_WI], ["nc", "North Carolina", PR_NC], ["mn", "Minnesota", PR_MN],
  ["nm", "New Mexico", PR_NM], ["nj", "New Jersey", PR_NJ], ["nh", "New Hampshire", PR_NH], ["tx", "Texas", PR_TX], ["va", "Virginia", PR_VA],
];

const EXTRA: AggregateDef[] = [
  dvr("2025-va-gov", "Virginia Governor", "2025 Governor", "Virginia · governor (2025)", VA_GOV_POLLS, "Spanberger", "Earle-Sears", "Abigail Spanberger (D)", "Winsome Earle-Sears (R)"),
  dvr("2025-nj-gov", "New Jersey Governor", "2025 Governor", "New Jersey · governor (2025)", NJ_GOV_POLLS, "Sherrill", "Ciattarelli", "Mikie Sherrill (D)", "Jack Ciattarelli (R)"),
  dvr("2024-national", "National", "2024 President", "2024 national · president", PR_NAT, "Harris", "Trump", "Harris", "Trump"),
  ...STATES_2024.map(([sid, name, polls]) => dvr(`2024-${sid}`, name, "2024 President", `2024 ${name} · president`, polls, "Harris", "Trump", "Harris", "Trump")),
];

/* ---------- 2026 Senate matchups (generic adapter) ---------- */

type SenateModule = {
  STATE: { abbr: string; name: string };
  RACES: ReadonlyArray<{ raceId: string; candidates: ReadonlyArray<string> }>;
  STATE_POLLS: Record<string, ReadonlyArray<{ raceId?: string; pollster: string; endDate: string; sampleSize: number; sampleType: string; results: Record<string, number> }>>;
};

function lastName(label: string) {
  return label.replace(/\s*\([A-Za-z/]+\)\s*$/, "").trim().split(/\s+/).slice(-1)[0] || label;
}
function partyColor(label: string) {
  if (/\(R\)/.test(label)) return RED;
  if (/\(D\)/.test(label)) return BLUE;
  if (/\(I(?:\/[A-Z]+)?\)/.test(label)) return IND_PURPLE;
  return "#9b8cff";
}

function partyWord(label: string) {
  if (/\(R\)/.test(label)) return "Republican";
  if (/\(D\)/.test(label)) return "Democrat";
  if (/\(I(?:\/[A-Z]+)?\)/.test(label)) return "Independent";
  if (/\(L\)/.test(label)) return "Libertarian";
  if (/\(G\)/.test(label)) return "Green";
  return "";
}

// featured matchups stored with generic Republican/Democrat keys
function rdSenate(id: string, abbr: string, stateName: string, aShort: string, bShort: string, polls: Poll[]): AggregateDef {
  return {
    id, label: `${abbr} · ${aShort}–${bShort}`, category: "2026 Senate",
    title: `${stateName} · U.S. Senate — ${aShort} vs. ${bShort}`,
    subtitle: "Daily On Point Polling weighted average of every public poll of this 2026 U.S. Senate matchup.",
    unit: "%", keyA: "Republican", keyB: "Democrat",
    seriesA: { label: aShort, color: RED }, seriesB: { label: bShort, color: BLUE },
    marginLabel: "Margin",
    fmtMargin: (n) => (Math.abs(n) < 0.05 ? "Even" : n > 0 ? `${aShort}+${n.toFixed(1)}` : `${bShort}+${Math.abs(n).toFixed(1)}`),
    polls, gold: [], goldMult: 1, stateAbbr: abbr,
  };
}

function senateAggs(mod: SenateModule): AggregateDef[] {
  const abbr = mod.STATE.abbr, name = mod.STATE.name;
  const allPolls = (mod.STATE_POLLS[abbr] ?? Object.values(mod.STATE_POLLS).flat()) as unknown as Poll[];
  const out: AggregateDef[] = [];
  for (const race of mod.RACES) {
    const aLabel = race.candidates[0], bLabel = race.candidates[1];
    if (!aLabel || !bLabel) continue;
    const polls = allPolls.filter((p) => (p as Poll & { raceId?: string }).raceId === race.raceId);
    if (polls.length === 0) continue;
    const aShort = lastName(aLabel), bShort = lastName(bLabel);
    out.push({
      id: race.raceId.toLowerCase(),
      label: `${abbr} · ${aShort}–${bShort}`,
      category: "2026 Senate",
      title: `${name} · U.S. Senate — ${aShort} vs. ${bShort}`,
      subtitle: "Daily On Point Polling weighted average of every public poll of this 2026 U.S. Senate matchup.",
      unit: "%",
      keyA: aLabel, keyB: bLabel,
      seriesA: { label: aShort, color: partyColor(aLabel), party: partyWord(aLabel) },
      seriesB: { label: bShort, color: partyColor(bLabel), party: partyWord(bLabel) },
      marginLabel: "Margin",
      fmtMargin: (n) => (Math.abs(n) < 0.05 ? "Even" : n > 0 ? `${aShort}+${n.toFixed(1)}` : `${bShort}+${Math.abs(n).toFixed(1)}`),
      polls, gold: [], goldMult: 1, stateAbbr: abbr,
    });
  }
  return out;
}

function governorAggs(mod: SenateModule): AggregateDef[] {
  const abbr = mod.STATE.abbr, name = mod.STATE.name;
  const allPolls = (mod.STATE_POLLS[abbr] ?? Object.values(mod.STATE_POLLS).flat()) as unknown as Poll[];
  const out: AggregateDef[] = [];
  for (const race of mod.RACES) {
    const aLabel = race.candidates[0], bLabel = race.candidates[1];
    if (!aLabel || !bLabel) continue;
    const polls = allPolls.filter((p) => (p as Poll & { raceId?: string }).raceId === race.raceId);
    if (polls.length === 0) continue;
    const aShort = lastName(aLabel), bShort = lastName(bLabel);
    out.push({
      id: race.raceId.toLowerCase(),
      label: `${abbr} · ${aShort}–${bShort}`,
      category: "2026 Governor",
      title: `${name} · governor — ${aShort} vs. ${bShort}`,
      subtitle: "Daily On Point Polling weighted average of every public poll of this 2026 governor's race.",
      unit: "%",
      keyA: aLabel, keyB: bLabel,
      seriesA: { label: aShort, color: partyColor(aLabel), party: partyWord(aLabel) },
      seriesB: { label: bShort, color: partyColor(bLabel), party: partyWord(bLabel) },
      marginLabel: "Margin",
      fmtMargin: (n) => (Math.abs(n) < 0.05 ? "Even" : n > 0 ? `${aShort}+${n.toFixed(1)}` : `${bShort}+${Math.abs(n).toFixed(1)}`),
      polls, gold: [], goldMult: 1, stateAbbr: abbr,
    });
  }
  return out;
}

const SENATE_MODULES = [
  SEN_ALABAMA, SEN_ALASKA, SEN_ARKANSAS, SEN_COLORADO, SEN_DELAWARE, SEN_FLORIDA, SEN_GEORGIA, SEN_IDAHO, SEN_ILLINOIS, SEN_IOWA, SEN_KANSAS, SEN_KENTUCKY, SEN_LOUISIANA, SEN_MAINE, SEN_MASSACHUSETTS, SEN_MICHIGAN, SEN_MINNESOTA, SEN_MISSISSIPPI, SEN_MONTANA, SEN_NEBRASKA, SEN_NEWHAMPSHIRE, SEN_NEWJERSEY, SEN_NEWMEXICO, SEN_NORTHCAROLINA, SEN_OHIO, SEN_OKLAHOMA, SEN_OREGON, SEN_RHODEISLAND, SEN_SOUTHCAROLINA, SEN_SOUTHDAKOTA, SEN_TENNESSEE, SEN_TEXAS, SEN_VIRGINIA, SEN_WESTVIRGINIA, SEN_WYOMING,
] as unknown as SenateModule[];
const GOVERNOR_MODULES = [
  GOV_ALABAMA, GOV_ALASKA, GOV_ARIZONA, GOV_ARKANSAS, GOV_CALIFORNIA, GOV_COLORADO, GOV_CONNECTICUT, GOV_FLORIDA, GOV_GEORGIA, GOV_HAWAII, GOV_IDAHO, GOV_ILLINOIS, GOV_IOWA, GOV_KANSAS, GOV_MAINE, GOV_MARYLAND, GOV_MASSACHUSETTS, GOV_MICHIGAN, GOV_MINNESOTA, GOV_NEBRASKA, GOV_NEVADA, GOV_NEWHAMPSHIRE, GOV_NEWMEXICO, GOV_NEWYORK, GOV_OHIO, GOV_OKLAHOMA, GOV_OREGON, GOV_PENNSYLVANIA, GOV_RHODEISLAND, GOV_SOUTHCAROLINA, GOV_SOUTHDAKOTA, GOV_TENNESSEE, GOV_TEXAS, GOV_VERMONT, GOV_WISCONSIN, GOV_WYOMING,
] as unknown as SenateModule[];
const SENATE_AGGS: AggregateDef[] = [
  // featured TX general matchups (the live Talarico races) from the polling index
  rdSenate("tx-sen-cornyn-talarico", "TX", "Texas", "Cornyn", "Talarico", TX_CORNYN_POLLS as unknown as Poll[]),
  rdSenate("tx-sen-paxton-talarico", "TX", "Texas", "Paxton", "Talarico", TX_PAXTON_POLLS as unknown as Poll[]),
  ...SENATE_MODULES.flatMap(senateAggs),
];

const GOVERNOR_AGGS: AggregateDef[] = GOVERNOR_MODULES.flatMap(governorAggs);

const RAW_AGGREGATES: AggregateDef[] = [
  {
    id: "generic-ballot",
    label: "Generic Ballot",
    category: "2026 House",
    title: "National generic ballot",
    subtitle:
      "A daily weighted average of every public House generic-ballot poll — recency decay, sample-size sigmoid, likely-voter screen, and pollster-grade weighting.",
    unit: "%",
    keyA: "Democrats", keyB: "Republicans",
    seriesA: { label: "Democrats", color: BLUE },
    seriesB: { label: "Republicans", color: RED },
    marginLabel: "Margin",
    fmtMargin: (n) => (Math.abs(n) < 0.05 ? "Even" : n > 0 ? `D+${n.toFixed(1)}` : `R+${Math.abs(n).toFixed(1)}`),
    polls: GENERIC, gold: GENERIC_GOLD, goldMult: 2,
  },
  {
    id: "trump-approval",
    label: "Trump Approval",
    category: "Approval",
    title: "Donald Trump · job approval",
    subtitle:
      "A daily weighted average of every public Trump job-approval poll, blended on the same On Point Polling model — recency, sample size, voter screen, and pollster grade.",
    unit: "%",
    keyA: "Approve", keyB: "Disapprove",
    seriesA: { label: "Approve", color: GREEN },
    seriesB: { label: "Disapprove", color: MAGENTA },
    marginLabel: "Net approval",
    fmtMargin: netPM,
    polls: TRUMP, gold: TRUMP_GOLD, goldMult: 2,
  },
  {
    id: "vance-favorability",
    label: "Vance Favorability",
    category: "Approval",
    title: "JD Vance · favorability",
    subtitle:
      "A daily weighted average of every public JD Vance favorability poll, on the On Point Polling model.",
    unit: "%",
    keyA: "Favorable", keyB: "Unfavorable",
    seriesA: { label: "Favorable", color: BLUE },
    seriesB: { label: "Unfavorable", color: RED },
    marginLabel: "Net favorability",
    fmtMargin: netPM,
    polls: VANCE, gold: VANCE_GOLD, goldMult: 2,
  },
  {
    id: "right-wrong-track",
    label: "Right / Wrong Track",
    category: "National mood",
    title: "Right track · wrong track",
    subtitle:
      "A daily weighted average of national direction-of-the-country polling, on the On Point Polling model.",
    unit: "%",
    keyA: "RightTrack", keyB: "WrongTrack",
    seriesA: { label: "Right track", color: GREEN },
    seriesB: { label: "Wrong track", color: AMBER },
    marginLabel: "Net",
    fmtMargin: netPM,
    polls: TRACK, gold: TRACK_GOLD, goldMult: 2,
  },
  // 2028: every general election matchup with two or more national polls
  ...GENERAL_2028_AGGS,
  ...EXTRA,
  ...SENATE_AGGS,
  ...GOVERNOR_AGGS,
];

/* -------------------- removed firms and Republican lean -------------------- */
// Oct 22 2026, set by the publisher. ActiVote is dropped from every average. Oct 30: Rasmussen Reports is back, as a Republican
// internal, and every campaign or party internal, tagged (R) or (D), is corrected by its side's measured lean.
// Trafalgar and InsiderAdvantage are labelled Republican leaning, and their lean is measured, not assumed:
// each of their polls is set against the polls other firms ended within three weeks of it in the same race,
// as Republican minus Democrat margin, the gaps are pooled across every race, shrunk toward zero by
// n / (n + 5), and that many points come off the firm's margin, half from the Republican side and half
// added to the Democratic side. A firm that measures at or below zero is not moved. Approval, favorability
// and right track count the White House side, the Republican side under this administration.

type Side = "A" | "B";
const R_SIDE_OVERRIDE: Record<string, Side> = { "trump-approval": "A", "vance-favorability": "A", "right-wrong-track": "A" };
function rSideOf(d: AggregateDef): Side | null {
  if (R_SIDE_OVERRIDE[d.id]) return R_SIDE_OVERRIDE[d.id];
  const red = (x: Series) => x.color === RED || x.party === "Republican";
  if (red(d.seriesA) && !red(d.seriesB)) return "A";
  if (red(d.seriesB) && !red(d.seriesA)) return "B";
  return null;
}
const LEAN_WINDOW_DAYS = 21, LEAN_SHRINK = 5, LEAN_CLIP = 12;
const DAYMS = 86400000;
function netR(p: Poll, d: AggregateDef, side: Side): number {
  const r = p.results as Record<string, number>;
  const a = Number(r[d.keyA]), b = Number(r[d.keyB]);
  if (!Number.isFinite(a) || !Number.isFinite(b) || r[d.keyA] == null || r[d.keyB] == null) return NaN;
  return side === "A" ? a - b : b - a;
}
function wmed(v: number[], w: number[]) {
  const o = v.map((x, i) => [x, w[i]] as const).sort((x, y) => x[0] - y[0]);
  const tot = o.reduce((s, x) => s + x[1], 0); let acc = 0;
  for (const [x, ww] of o) { acc += ww; if (acc >= tot / 2) return x; }
  return o[o.length - 1][0];
}
export type LeanEstimate = { id: string; label: string; dir: "R" | "D"; lean: number; raw: number; n: number };
function measureLeans(defs: AggregateDef[]): Record<string, LeanEstimate> {
  const res: Record<string, number[]> = {};
  for (const f of R_LEAN_FIRMS) res[f.id] = [];
  for (const d of defs) {
    const side = rSideOf(d); if (!side) continue;
    const pts = d.polls.filter((p) => !isExcludedPollster(p.pollster))
      .map((p) => ({ p, t: new Date(p.endDate + "T00:00:00").getTime(), m: netR(p, d, side), firms: rLeanFirms(p.pollster) }))
      .filter((x) => Number.isFinite(x.m));
    const others = pts.filter((x) => x.firms.length === 0);
    for (const x of pts) {
      if (!x.firms.length) continue;
      const nb = others.filter((o) => Math.abs(o.t - x.t) <= LEAN_WINDOW_DAYS * DAYMS);
      if (nb.length < 2) continue;
      const ref = wmed(nb.map((o) => o.m), nb.map((o) => 1 / (1 + Math.abs(o.t - x.t) / (7 * DAYMS))));
      const gap = Math.max(-LEAN_CLIP, Math.min(LEAN_CLIP, x.m - ref));
      for (const f of x.firms) res[f].push(gap);
    }
  }
  const out: Record<string, LeanEstimate> = {};
  for (const f of R_LEAN_FIRMS) {
    const g = res[f.id], n = g.length;
    const raw = n ? g.reduce((s, x) => s + x, 0) / n : 0;
    // raw is the firm's Republican margin against the other polls; an R lean firm counts when it runs to the right,
    // a D lean firm when it runs to the left, and either is shrunk toward zero by its number of polls
    const toward = f.dir === "R" ? raw : -raw;
    out[f.id] = { id: f.id, label: f.label, dir: f.dir, n, raw: round1(raw), lean: round1(Math.max(0, toward * n / (n + LEAN_SHRINK))) };
  }
  return out;
}
export const R_LEAN_ESTIMATES: Record<string, LeanEstimate> = measureLeans(RAW_AGGREGATES);

export type PollLean = { dir: "R" | "D"; pts: number; firms: string };
// Nov 13 2026: a 2028 average moves partisan polls by the lean measured against the nonpartisan polls of the same
// races in the final month of 2026, the stretch scored against the results, where that lean is known.
function leanFor(d: AggregateDef, f: string, calibrated = d.category === "2028"): LeanEstimate | undefined {
  const e = R_LEAN_ESTIMATES[f], c = LEAN_CAL_2026[f];
  if (!c || !calibrated) return e;
  // Nov 24 2026: the 2028 averages read the calibrated figure, firm level where the firm has one
  return { id: f, label: c.label, dir: c.dir, raw: c.raw ?? e?.raw ?? 0, n: c.n, lean: c.lean };
}
function cleanPolls(d: AggregateDef, calibrated = d.category === "2028"): Poll[] {
  const side = rSideOf(d);
  return d.polls.filter((p) => !isExcludedPollster(p.pollster)).map((p) => {
    const firms = calibrated ? leanFirms2028(p.pollster) : rLeanFirms(p.pollster);
    if (!firms.length || !side) return p;
    // a joint release of an R lean and a D lean firm would cancel; every listed joint release is two R lean firms
    const est = firms.map((f) => leanFor(d, f, calibrated)).filter(Boolean) as LeanEstimate[];
    const dir = est[0]?.dir ?? "R";
    const lean = est.filter((e) => e.dir === dir).reduce((s, e) => s + e.lean, 0) / Math.max(1, est.filter((e) => e.dir === dir).length);
    if (!(lean > 0)) return p;
    const rKey = side === "A" ? d.keyA : d.keyB, dKey = side === "A" ? d.keyB : d.keyA;
    const raw = p.results as Record<string, number>;
    const r = { ...raw };
    if (r[rKey] == null || r[dKey] == null) return p;
    const sg = dir === "R" ? 1 : -1;   // an R lean poll moves toward the Democrat, a D lean poll toward the Republican
    r[rKey] = Math.round((r[rKey] - sg * lean / 2) * 100) / 100; r[dKey] = Math.round((r[dKey] + sg * lean / 2) * 100) / 100;
    const L: PollLean = { dir, pts: lean, firms: est.map((e) => e.label).join(" and ") };
    return { ...p, results: r, published: raw, lean: L, rLean: dir === "R" ? lean : undefined } as Poll;
  });
}

// Nov 13 2026: the national averages weight up the 2026 Gold Standard (ratings2026.ts) in place of their old lists
const GOLD_CATS = new Set(["Approval", "2026 House", "National mood", "2028"]);
export const AGGREGATES: AggregateDef[] = RAW_AGGREGATES.map((d) => ({ ...d, gold: GOLD_CATS.has(d.category) ? GOLD_2026 : d.gold, polls: cleanPolls(d) }));
/** Nov 13 2026: the 2026 Senate and governor averages closed with the election. They stay in AGGREGATES for the
 *  forecast race pages and are kept off the polling desk, which reads DESK_AGGREGATES. */
export const RETIRED_CATEGORIES = new Set(["2026 Senate", "2026 Governor"]);
export const DESK_AGGREGATES: AggregateDef[] = AGGREGATES.filter((d) => !RETIRED_CATEGORIES.has(d.category));
/** Nov 24 2026: the 2026 archive. Every 2026 Senate and governor average and the national generic ballot, approval and right
 *  track averages, run again on the polls that ended by Election Day, November 3, under the 2026 ratings: the 2026 grades,
 *  the 2026 Gold Standard at the top weight, and the November 24 partisan corrections, firm by firm. The forecast race pages
 *  keep the averages as they stood on the night; this is the same record read with what 2026 taught. */
export const ARCHIVE_2026_NATIONAL = ["generic-ballot", "trump-approval", "right-wrong-track"];
export const ARCHIVE_2026: AggregateDef[] = RAW_AGGREGATES
  .filter((d) => RETIRED_CATEGORIES.has(d.category) || ARCHIVE_2026_NATIONAL.includes(d.id))
  .map((d) => {
    const cut = { ...d, polls: d.polls.filter((p) => p.endDate <= "2026-11-03") };
    return { ...cut, gold: GOLD_2026, polls: cleanPolls(cut, true) };
  });
/** The same averages as they stood on the night: the polls through November 3 with the corrections the desk used then. */
export const NIGHT_2026: AggregateDef[] = AGGREGATES
  .filter((d) => RETIRED_CATEGORIES.has(d.category) || ARCHIVE_2026_NATIONAL.includes(d.id))
  .map((d) => ({ ...d, polls: d.polls.filter((p) => p.endDate <= "2026-11-03") }));
/** Republican minus Democratic points from an average's net, A minus B; null when neither side is the Republican one. */
export function rMinusD(d: AggregateDef, net: number): number | null {
  const s = rSideOf(d); if (!s) return null;
  return s === "A" ? net : -net;
}
/** The cleaned poll list of one average: removed firms dropped, Republican lean taken off. */
export function aggPolls(id: string): Poll[] { return AGGREGATES.find((d) => d.id === id)?.polls ?? []; }

/* ----------------------------- builder ----------------------------- */

function normalize(s: string) {
  return s.toLowerCase().replace(/\(r\)/g, "").replace(/[^a-z0-9]+/g, " ").trim();
}
function isGold(pollster: string, gold: string[]) {
  const p = normalize(pollster);
  return gold.some((g) => p.includes(normalize(g)));
}
function effSample(pollster: string, n: number, gold: string[], mult: number) {
  if (!Number.isFinite(n) || n <= 0) return n;
  return isGold(pollster, gold) ? Math.round(n * mult * mult) : n;
}
const ts = (iso: string) => new Date(iso + "T00:00:00").getTime();

export type BuiltAggregate = {
  daily: AggDaily[];
  polls: AggPollPoint[];
  latest: { a: number; b: number; net: number } | null;
  /** set on a summary build (liteBuilt): the poll count and a 60 point sparkline of the whole range */
  n?: number;
  spark?: number[];
  spark90?: number[];
};

/** A small summary of a built average for boards, tiles and maps: the last 90 days of the line, the latest reading,
 *  the poll count and a sparkline. The averages page loads these from /api/polls/lite instead of building every
 *  average in the browser, which took seconds on a phone. */
export function liteBuilt(b: BuiltAggregate): BuiltAggregate {
  const pick = (a: number[], n: number) => (a.length <= n ? a : Array.from({ length: n }, (_, i) => a[Math.round((i * (a.length - 1)) / (n - 1))]));
  const nets = b.daily.map((x) => x.net);
  // the last 43 days carry only the date and the margin, which is all a board or map trend reads
  const daily = b.daily.slice(-43).map((x) => ({ date: x.date, net: x.net })) as unknown as AggDaily[];
  return { daily, polls: [], latest: b.latest, n: b.polls.length, spark: pick(nets, 60), spark90: pick(nets.slice(-90), 36) };
}
/** The poll count of a full or summary build. */
export const builtN = (b: BuiltAggregate) => b.n ?? b.polls.length;

export function buildAggregate(def0: AggregateDef): BuiltAggregate {
  const def = { ...def0, polls: def0.polls.filter((p) => !isExcludedPollster(p.pollster)) };
  const adjusted = def.polls.map((p) => ({
    ...p,
    sampleSize: effSample(p.pollster, p.sampleSize, def.gold, def.goldMult),
  }));
  // Oct 22 2026: the line starts at the first poll that asked this matchup. A poll of another pairing used to set the
  // start, which drew a flat line at even before the first real poll.
  const both = def.polls.filter((p) => {
    const r = p.results as Record<string, number>;
    return Number.isFinite(Number(r[def.keyA])) && Number.isFinite(Number(r[def.keyB])) && r[def.keyA] != null && r[def.keyB] != null;
  });
  const range = getDateRange(both.length ? both : def.polls);
  const base = buildDailyWeightedSeries(adjusted as Poll[], [def.keyA, def.keyB], range.start, range.end);

  const daily: AggDaily[] = base.filter((row) => {
    const r = row as Record<string, number | string>;
    return Number(r[def.keyA] ?? 0) !== 0 || Number(r[def.keyB] ?? 0) !== 0;
  }).map((row) => {
    const a = Number((row as Record<string, number | string>)[def.keyA] ?? 0);
    const b = Number((row as Record<string, number | string>)[def.keyB] ?? 0);
    return { date: row.date, t: ts(row.date), a, b, net: round1(a - b) };
  });

  // each poll's share of the latest day's average, after the robust passes, averaged over both sides
  const shA = pollSharesOn(adjusted as Poll[], def.keyA, range.end), shB = pollSharesOn(adjusted as Poll[], def.keyB, range.end);
  const polls: AggPollPoint[] = def.polls
    .map((p, i) => {
      // tables show the poll as published; the chart places it where the average counts it
      const pub = ((p as Poll & { published?: Record<string, number> }).published ?? p.results) as Record<string, number>;
      const a = Number(pub[def.keyA] ?? NaN);
      const b = Number(pub[def.keyB] ?? NaN);
      const ua = Number((p.results as Record<string, number>)[def.keyA] ?? NaN), ub = Number((p.results as Record<string, number>)[def.keyB] ?? NaN);
      return {
        adjA: ua, adjB: ub, adjMargin: round1(ua - ub),
        lean: (p as Poll & { lean?: PollLean }).lean,
        pollster: p.pollster.replace(/\*\*/g, "").trim(),
        date: p.endDate,
        t: ts(p.endDate),
        a, b,
        margin: round1(a - b),
        sampleSize: p.sampleSize,
        sampleType: p.sampleType,
        grade: getPollsterEntry(p.pollster).grade,
        rLean: (p as Poll & { rLean?: number }).rLean,
        share: ((shA.get(adjusted[i] as Poll) ?? 0) + (shB.get(adjusted[i] as Poll) ?? 0)) / 2,
      };
    })
    .filter((p) => Number.isFinite(p.a) && Number.isFinite(p.b));

  const last = daily[daily.length - 1] ?? null;
  return {
    daily,
    polls,
    latest: last ? { a: round1(last.a), b: round1(last.b), net: last.net } : null,
  };
}

/* =============================================================================
   Multi-candidate aggregates (primaries) — N candidates, no head-to-head margin.
============================================================================= */

export type MultiSeries = { key: string; label: string; color: string };
export type MultiAggregateDef = {
  id: string;
  label: string;
  group: string;
  title: string;
  subtitle: string;
  unit: "%" | "pt";
  series: MultiSeries[];
  polls: Poll[];
  gold: string[];
  goldMult: number;
  /** model weights, when a field needs other than the election profile */
  opts?: ModelOptions;
  /** the first day the chart and table show */
  from?: string;
};
export type MultiDaily = { date: string; t: number; v: number[] }; // v aligned to series
export type MultiPollPoint = { pollster: string; date: string; t: number; v: number[]; sampleSize: number; sampleType: string; grade: string };
export type BuiltMulti = { daily: MultiDaily[]; polls: MultiPollPoint[]; latest: number[] | null };

// categorical palette for primary fields (candidates are same-party, so non-semantic colors)
const CAND_PALETTE = ["#5b8cf0", "#e5484d", "#3ecf8e", "#e0a23b", "#c64ad6", "#42c9d4", "#9b8cff"];

function multiDef(id: string, label: string, title: string, subtitle: string, polls: Poll[]): MultiAggregateDef {
  const cands = getCandidateList(polls);
  const totals = new Map<string, number>();
  for (const p of polls) {
    for (const c of cands) {
      const v = Number((p.results as Record<string, number>)[c]);
      if (Number.isFinite(v)) totals.set(c, (totals.get(c) ?? 0) + v);
    }
  }
  const ordered = cands.slice().sort((a, b) => (totals.get(b) ?? 0) - (totals.get(a) ?? 0));
  const series = ordered.map((c, i) => ({ key: c, label: c, color: CAND_PALETTE[i % CAND_PALETTE.length] }));
  return { id, label, group: "Primaries", title, subtitle, unit: "%", series, polls, gold: [], goldMult: 1 };
}

// The Primaries category was retired from the polling desk. The primary poll
// files stay on disk, but nothing registers them, so no Primaries tab renders.
// Nov 13 2026: the 2028 Republican and Democratic primaries, every candidate.
export const MULTI_AGGREGATES: MultiAggregateDef[] = PRIMARY_2028_MULTI;

export function buildMulti(def0: MultiAggregateDef): BuiltMulti {
  const def = { ...def0, polls: def0.polls.filter((p) => !isExcludedPollster(p.pollster)) };
  const adjusted = def.polls.map((p) => ({ ...p, sampleSize: effSample(p.pollster, p.sampleSize, def.gold, def.goldMult) }));
  const keys = def.series.map((s) => s.key);
  const range = getDateRange(def.polls);
  const base = buildDailyWeightedSeries(adjusted as Poll[], keys, range.start, range.end, def0.opts);
  const daily: MultiDaily[] = base.filter((row) => !def0.from || String(row.date) >= def0.from).map((row) => ({
    date: row.date,
    t: ts(row.date),
    v: keys.map((k) => round1(Number((row as Record<string, number | string>)[k] ?? 0))),
  }));
  const polls: MultiPollPoint[] = def.polls
    .map((p) => ({
      pollster: p.pollster.replace(/\*\*/g, "").trim(),
      date: p.endDate,
      t: ts(p.endDate),
      v: keys.map((k) => { const val = Number((p.results as Record<string, number>)[k]); return Number.isFinite(val) ? val : NaN; }),
      sampleSize: p.sampleSize,
      sampleType: p.sampleType,
      grade: getPollsterEntry(p.pollster).grade,
    }))
    .filter((p) => p.v.some((x) => Number.isFinite(x)) && (!def0.from || p.date >= def0.from));
  const last = daily[daily.length - 1] ?? null;
  return { daily, polls, latest: last ? last.v : null };
}
