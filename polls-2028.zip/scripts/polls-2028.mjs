// One time patch, Nov 13 2026: 2028 averages, 2026 averages off the polling desk, SoCal Strategies removed,
// 2026 pollster ratings and calibrated partisan shifts. Run from the repo root: node scripts/polls-2028.mjs
// Every edit is anchored on text that must be there; anything already applied is skipped, anything missing is
// reported and left alone, so the script is safe to run twice.
import fs from "node:fs";

const log = [];
let bad = 0;
function edit(file, fn) {
  if (!fs.existsSync(file)) { log.push(`skip  ${file} (not in this repo)`); return; }
  const before = fs.readFileSync(file, "utf8");
  const after = fn(before, file);
  if (after !== before) { fs.writeFileSync(file, after); log.push(`ok    ${file}`); } else log.push(`same  ${file}`);
}
/** replace one anchored piece of text; done marks text that shows the edit is already in */
function rep(s, from, to, file, done) {
  if (done && s.includes(done)) return s;
  if (typeof from === "string" ? !s.includes(from) : !from.test(s)) { bad++; log.push(`MISS  ${file}: ${String(from).slice(0, 70).replace(/\n/g, " ")}`); return s; }
  return s.replace(from, to);
}

/* ------------------------- 1. ratings and partisan shifts ------------------------- */
edit("app/_polling/lib/buildDailyModel.ts", (s, f) => {
  if (!s.includes('from "./ratings2026"')) s = `import { SCORECARD_2026 } from "./ratings2026";\n` + s;
  s = rep(s, /export const POLLSTER_SCORECARD: Record<string, \{ grade: string; weight: number \}> = \{[\s\S]*?\n\};\n/,
    "// Nov 13 2026: grades come from 2026 accuracy, set in ratings2026.ts. The old table is retired.\nexport const POLLSTER_SCORECARD: Record<string, { grade: string; weight: number }> = SCORECARD_2026;\n", f, "= SCORECARD_2026;");
  s = rep(s, "export const EXCLUDED_POLLSTERS = /activote|wedgewood/i;",
    "// Nov 13 2026, set by the publisher: SoCal Strategies is removed from every average and listing.\nexport const EXCLUDED_POLLSTERS = /activote|wedgewood|socal\\s*strateg|socalpoll/i;", f, "socal\\s*strateg");
  s = rep(s, '  { id: "insideradvantage", label: "InsiderAdvantage", re: /insider\\s*advantage/i, dir: "R" },\n',
    '  { id: "insideradvantage", label: "InsiderAdvantage", re: /insider\\s*advantage/i, dir: "R" },\n  // Nov 13 2026: Quantus ran 4 points right of the nonpartisan polls of the same races in the final month of 2026\n  { id: "quantus", label: "Quantus Insights", re: /quantus/i, dir: "R" },\n', f, 'id: "quantus"');
  s = s.replace("//   Gold Standard → 6.00×   On Point Polling, Big Data Poll, The Honest Poll, Emerson, Cygnal,\n//                            Quantus Insights, The New York Times, The Wall Street Journal.",
    "//   Gold Standard → 6.00×   Nov 13 2026, from 2026 accuracy: On Point Polling, The Honest Poll, Big Data Poll,\n//                            NYT/Siena, Quinnipiac, AtlasIntel, Emerson. See ratings2026.ts.");
  return s;
});

/* ------------------------- 2. the averages engine ------------------------- */
edit("app/_polling/lib/aggregates.ts", (s, f) => {
  s = rep(s, 'import { RAW_POLLS as P2028, GOLD_STANDARD_NAMES as P2028_GOLD } from "../2028polling/data";',
    'import { GENERAL_2028_AGGS } from "../2028/matchups";\nimport { GOLD_2026, LEAN_CAL_2026 } from "./ratings2026";', f, "GENERAL_2028_AGGS }");
  s = rep(s, /  \{\n    id: "2028-vance-newsom",[\s\S]*?goldMult: 2,\n  \},\n/, "  // 2028: every general election matchup with two or more national polls\n  ...GENERAL_2028_AGGS,\n", f, "...GENERAL_2028_AGGS,");
  s = rep(s, "    const est = firms.map((f) => R_LEAN_ESTIMATES[f]).filter(Boolean);",
    "    const est = firms.map((f) => leanFor(d, f)).filter(Boolean) as LeanEstimate[];", f, "leanFor(d, f)");
  s = rep(s, "export type PollLean = { dir: \"R\" | \"D\"; pts: number; firms: string };",
    `export type PollLean = { dir: "R" | "D"; pts: number; firms: string };
// Nov 13 2026: a 2028 average moves partisan polls by the lean measured against the nonpartisan polls of the same
// races in the final month of 2026, the stretch scored against the results, where that lean is known.
function leanFor(d: AggregateDef, f: string): LeanEstimate | undefined {
  const e = R_LEAN_ESTIMATES[f], c = LEAN_CAL_2026[f];
  if (!e || !c || d.category !== "2028") return e;
  return { ...e, lean: c.lean, n: c.n };
}`, f, "function leanFor(");
  s = rep(s, "export const AGGREGATES: AggregateDef[] = RAW_AGGREGATES.map((d) => ({ ...d, polls: cleanPolls(d) }));",
    `// Nov 13 2026: the national averages weight up the 2026 Gold Standard (ratings2026.ts) in place of their old lists
const GOLD_CATS = new Set(["Approval", "2026 House", "National mood", "2028"]);
export const AGGREGATES: AggregateDef[] = RAW_AGGREGATES.map((d) => ({ ...d, gold: GOLD_CATS.has(d.category) ? GOLD_2026 : d.gold, polls: cleanPolls(d) }));
/** Nov 13 2026: the 2026 Senate and governor averages closed with the election. They stay in AGGREGATES for the
 *  forecast race pages and are kept off the polling desk, which reads DESK_AGGREGATES. */
export const RETIRED_CATEGORIES = new Set(["2026 Senate", "2026 Governor"]);
export const DESK_AGGREGATES: AggregateDef[] = AGGREGATES.filter((d) => !RETIRED_CATEGORIES.has(d.category));`, f, "DESK_AGGREGATES: AggregateDef[]");
  return s;
});

/* ------------------------- 3. desk readers move to DESK_AGGREGATES ------------------------- */
const swap = (s) => s.replace(/\bAGGREGATES\b(?!_)/g, (m, i) => (s.slice(Math.max(0, i - 6), i) === "MULTI_" ? m : "DESK_AGGREGATES")).replace(/DESK_DESK_AGGREGATES/g, "DESK_AGGREGATES");
for (const f of ["app/search/page.tsx", "app/api/polls/[avg]/route.ts", "app/api/polls/lite/route.ts", "app/api/polls/built/[avg]/route.ts", "app/lib/llms.ts", "app/sitemap.ts", "app/_polling/genericballot/GenericBallotV2.tsx"]) {
  edit(f, (s) => swap(s));
}
edit("app/search/page.tsx", (s, f) => rep(s, "  for (const [k, v] of Object.entries(PRIMARIES)) entries.push({ href: `/polls/${k}`, title: v.title, kind: \"Polling averages\", keys: v.title.toLowerCase() });",
  "  for (const p of PRIMARIES_2028) entries.push({ href: hrefOf2028(p.id), title: p.title, sub: \"Every candidate\", kind: \"Polling averages\", keys: `${p.title} 2028 primary`.toLowerCase() });", f, "PRIMARIES_2028)")
  .replace("DESK_AGGREGATES.length + Object.keys(PRIMARIES).length", "DESK_AGGREGATES.length + PRIMARIES_2028.length")
  .replace('import { pollHref, PRIMARIES } from "@/app/polls/registry";', 'import { pollHref } from "@/app/polls/registry";\nimport { PRIMARIES_2028, hrefOf2028 } from "@/app/_polling/2028/matchups";'));
edit("app/sitemap.ts", (s, f) => {
  s = rep(s, '    u("/polls/senate", today, "daily", 0.8),\n    u("/polls/governor", today, "daily", 0.8),\n',
    '    u("/polls/2028", today, "daily", 0.9),\n    u("/polls/2028/republican-primary", today, "daily", 0.8),\n    u("/polls/2028/democratic-primary", today, "daily", 0.8),\n    u("/polls/ratings", today, "monthly", 0.7),\n', f, '"/polls/2028"');
  return s;
});
edit("app/_polling/genericballot/GenericBallotV2.tsx", (s, f) => {
  s = rep(s, '  cat === "2024 President" ? "2024 President"', '  cat === "2028" ? "2028 General"\n  : cat === "2024 President" ? "2024 President"', f, '"2028 General"\n  : cat');
  s = rep(s, '  National: "National", "2026 Senate": "2026 Senate",', '  "2028 General": "2028 general election", National: "National", "2026 Senate": "2026 Senate",', f, '"2028 General": "2028 general election"');
  s = rep(s, 'const GROUP_HREF: Record<string, string> = { "2026 Senate": "/polls/senate", "2026 Governor": "/polls/governor" };', 'const GROUP_HREF: Record<string, string> = { "2028 General": "/polls/2028" };', f, '{ "2028 General": "/polls/2028" }');
  s = s.replace(', "2028-vance-newsom": "2028 presidential",', ",");
  s = rep(s, 'const GROUP_ORDER = ["National",', 'const GROUP_ORDER = ["2028 General", "National",', f, '["2028 General", "National"');
  s = rep(s, '  if (d.category === "2024 President") return { crumb: d.label, eyebrow: "2024 archive",',
    '  if (d.category === "2028") return { crumb: d.label, eyebrow: "2028 general election", h1: `2028 ${d.label}` };\n  if (d.category === "2024 President") return { crumb: d.label, eyebrow: "2024 archive",', f, 'eyebrow: "2028 general election"');
  s = rep(s, 'boardGroup === "archive" ? "Primaries and past races" : "Every race"}', 'boardGroup === "archive" ? "Past races" : boardGroup === "2028" ? "2028 primaries and matchups" : "Every race"}', f, '"2028 primaries and matchups"');
  return s;
});

/* ------------------------- 4. SoCal Strategies out of every file ------------------------- */
const SOCAL_LINE = /^.*(SoCal\s*Strategies|SoCalStrategies|socal strategies).*\n/gim;
const socalFiles = [];
(function walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (e.name === "node_modules" || e.name.startsWith(".")) continue;
    const p = `${dir}/${e.name}`;
    if (e.isDirectory()) walk(p);
    else if (/\.(ts|tsx|js|mjs|json)$/.test(e.name) && !p.endsWith("polls-2028.mjs") && /socal\s*strateg|socalstrateg|socalpoll/i.test(fs.readFileSync(p, "utf8"))) socalFiles.push(p);
  }
})("app");
for (const f of socalFiles) {
  edit(f, (s) => {
    // a Pollster card object in the gold standard and methodology lists
    s = s.replace(/\n  \{\n    name: "SoCalStrategies",[\s\S]*?\n  \},(?=\n)/g, "");
    // a list entry that shares its line with other names
    s = s.replace(/,\s*"SoCal ?Strategies"(?=\s*[,\]\n])/g, "").replace(/(\[\s*|\n\s*)"SoCal ?Strategies",\s*(?=")/g, "$1");
    // one line poll rows, a list entry on its own line, and comments
    s = s.split("\n").filter((l) => !/(SoCal\s*Strategies|SoCalStrategies|socalpoll)/i.test(l) || /^\s*(import|export)\b/.test(l)).join("\n");
    return s;
  });
}
edit("app/tpsi/methodology/page.tsx", (s) => s.replace("const POLLSTER_COUNT = 8;", "const POLLSTER_COUNT = 7;"));

/* ------------------------- 5. old desk pages that no longer exist ------------------------- */
for (const f of ["app/polls/senate/opengraph-image.tsx", "app/polls/governor/opengraph-image.tsx", "app/polls/house/opengraph-image.tsx"]) {
  if (fs.existsSync(f)) { fs.rmSync(f); log.push(`gone  ${f}`); }
}

/* ------------------------- 6. nav and llms point at 2028 ------------------------- */
edit("app/components/navMenu.ts", (s, f) => rep(s, '      { h: "Races", links: [\n        { href: "/polls/2028", label: "2028 primaries" },\n        { href: "/polls/senate", label: "Senate" },\n        { href: "/polls/governor", label: "Governors" },\n      ] },',
  '      { h: "2028", links: [\n        { href: "/polls/2028/republican-primary", label: "Republican primary" },\n        { href: "/polls/2028/democratic-primary", label: "Democratic primary" },\n        { href: "/polls/2028", label: "General election matchups" },\n        { href: "/polls/ratings", label: "Pollster ratings" },\n      ] },', f, '"/polls/2028/republican-primary"'));
edit("app/lib/llms.ts", (s, f) => rep(s, '    `* Senate polling averages: ${U("/polls/senate")}`,\n    `* Governor polling averages: ${U("/polls/governor")}`,',
  '    `* 2028 polling averages, both primaries and every general election matchup: ${U("/polls/2028")}`,\n    `* 2028 Republican primary average, every candidate: ${U("/polls/2028/republican-primary")}`,\n    `* 2028 Democratic primary average, every candidate: ${U("/polls/2028/democratic-primary")}`,\n    `* Pollster ratings after 2026 and the Gold Standard: ${U("/polls/ratings")}`,', f, '"/polls/2028/republican-primary")'));

console.log(log.join("\n"));
console.log(bad ? `\n${bad} edit(s) could not be placed. Send the MISS lines and the file to Claude.` : "\nAll edits placed.");
