"use client";

import React, { useEffect, useRef, useState } from "react";

// The needle — ported 1:1 from the precinct app's ForecastNeedle dial
// (precinct-map/web/components/ForecastNeedle.tsx) so the hub and the ESRI map
// speak one visual language: half dial, tanh margin→angle compression, leader
// on the LEFT, graduated zone wedges, ink outlines, tapered needle with hub,
// side caps, and the "LEADER +M pts · P% to win · BAND" headline. This inline
// version is pure presentation — no polling, no fixed positioning.

const OSWALD = '"Oswald", "Barlow Condensed", system-ui, sans-serif';
const MONO = '"JetBrains Mono", ui-monospace, monospace';
// Resolved from the host page when it defines them, otherwise the dark
// values this component has always used.
const INK = "var(--fc-ink, var(--ink))";
const PAGE = "var(--fc-bg, var(--canvas))";

// odds → angle: the needle position IS the leader's win probability,
// exactly like the site forecast gauge. 50% = dead center, 100% = pinned.
function oddsToAngle(pLeader: number): number {
  return -90 * Math.max(-1, Math.min(1, 2 * pLeader - 1));
}
function arcPath(cx: number, cy: number, r: number, a0: number, a1: number): string {
  const t0 = ((a0 - 90) * Math.PI) / 180;
  const t1 = ((a1 - 90) * Math.PI) / 180;
  const x0 = cx + r * Math.cos(t0);
  const y0 = cy + r * Math.sin(t0);
  const x1 = cx + r * Math.cos(t1);
  const y1 = cy + r * Math.sin(t1);
  const large = Math.abs(a1 - a0) > 180 ? 1 : 0;
  const sweep = a1 > a0 ? 1 : 0;
  return `M ${x0.toFixed(2)} ${y0.toFixed(2)} A ${r} ${r} 0 ${large} ${sweep} ${x1.toFixed(2)} ${y1.toFixed(2)}`;
}
function wedgePath(cx: number, cy: number, r: number, a0: number, a1: number): string {
  const t0 = ((a0 - 90) * Math.PI) / 180;
  const t1 = ((a1 - 90) * Math.PI) / 180;
  const x0 = cx + r * Math.cos(t0);
  const y0 = cy + r * Math.sin(t0);
  const x1 = cx + r * Math.cos(t1);
  const y1 = cy + r * Math.sin(t1);
  const large = Math.abs(a1 - a0) > 180 ? 1 : 0;
  const sweep = a1 > a0 ? 1 : 0;
  return `M ${cx} ${cy} L ${x0.toFixed(2)} ${y0.toFixed(2)} A ${r} ${r} 0 ${large} ${sweep} ${x1.toFixed(2)} ${y1.toFixed(2)} Z`;
}
const lastName = (full?: string) => (full ? full.trim().split(/\s+/).pop() || full : "—");

export default function SwingOMeter({
  c1Name,
  c2Name,
  c1Color,
  c2Color,
  c1Prob,
  c2Prob,
  reportingPct,
  marginPp,
  fixedOrientation,
}: {
  c1Name: string;
  c2Name: string;
  c1Color: string;
  c2Color: string;
  c1Prob: number;
  c2Prob: number;
  reportingPct: number;
  /** Leader-over-runner margin in points; estimated from probability if absent. */
  marginPp?: number;
  /** Keep c1 on the left regardless of who leads (forecast pages pin D left). */
  fixedOrientation?: boolean;
}) {
  // leader on the LEFT, always — unless the caller pins the orientation, in
  // which case c1 stays left and only the header follows the true leader
  const flipped = fixedOrientation ? false : c2Prob > c1Prob;
  const leaderName = lastName(flipped ? c2Name : c1Name);
  const runnerName = lastName(flipped ? c1Name : c2Name);
  const leaderColor = flipped ? c2Color : c1Color;
  const runnerColor = flipped ? c1Color : c2Color;
  const pLeft = flipped ? c2Prob : c1Prob;          // left candidate (drives the needle)
  const c1Leads = c1Prob >= c2Prob;                 // true leader (drives the header)
  const headName = lastName(c1Leads ? c1Name : c2Name);
  const headColor = c1Leads ? c1Color : c2Color;
  const pHead = Math.max(c1Prob, c2Prob, 0.5);
  const M = Math.abs(marginPp != null ? marginPp : Math.atanh(Math.min(0.999, Math.max(0, pHead * 2 - 1))) * 12);

  const band = pHead < 0.65 ? "Toss-up" : pHead < 0.8 ? "Lean" : pHead < 0.95 ? "Likely" : "Safe";
  const live = reportingPct > 0 && reportingPct < 99.5;
  const called = reportingPct >= 99.5;

  // damped live jitter (reduced-motion: none)
  const [jitterPhase, setJitterPhase] = useState(0);
  const reducedRef = useRef(false);
  useEffect(() => {
    reducedRef.current = !!window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    if (!live || reducedRef.current) return;
    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = (now - last) / 1000;
      last = now;
      setJitterPhase((p) => p + dt);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [live]);

  // dial geometry — same numbers as the precinct app
  const SVG_W = 420;
  const SVG_H = 240;
  const cx = SVG_W / 2;
  const cy = 210;
  const rOuter = 175;
  const rInner = 64;
  const baseExtend = 18;
  const tipOverhang = 10;
  const centerTicLen = 14;

  const aLean = oddsToAngle(0.65);   // toss-up ends
  const aLikely = oddsToAngle(0.8);  // lean ends
  const aSafe = oddsToAngle(0.95);   // likely ends
  const leadZones = [
    { from: -90, to: aSafe, alpha: 0.85 },
    { from: aSafe, to: aLikely, alpha: 0.48 },
    { from: aLikely, to: aLean, alpha: 0.3 },
    { from: aLean, to: 0, alpha: 0.14 },
  ];
  const runZones = [
    { from: 0, to: -aLean, alpha: 0.14 },
    { from: -aLean, to: -aLikely, alpha: 0.3 },
    { from: -aLikely, to: -aSafe, alpha: 0.48 },
    { from: -aSafe, to: 90, alpha: 0.85 },
  ];

  const jitterAmp = live ? Math.min(1.4, (100 - reportingPct) * 0.03) : 0;
  const jitter = jitterAmp * (0.7 * Math.sin(jitterPhase * 1.7) + 0.3 * Math.sin(jitterPhase * 0.9 + 1.1));
  const angle = Math.max(-90, Math.min(90, oddsToAngle(Math.min(0.999, Math.max(0.001, pLeft))) + jitter));

  const tipLen = rOuter + tipOverhang;
  const baseHalf = 4.4;
  const shoulderY = -tipLen * 0.18;
  const shoulderHalf = baseHalf * 0.78;
  const needlePoints =
    `0,${-tipLen} ` +
    `${shoulderHalf.toFixed(2)},${shoulderY.toFixed(2)} ` +
    `${baseHalf},0 ` +
    `${-baseHalf},0 ` +
    `${(-shoulderHalf).toFixed(2)},${shoulderY.toFixed(2)}`;

  return (
    <div style={{ width: "100%" }}>
      <style>{`@keyframes smLivePulse{0%,100%{opacity:.42}50%{opacity:1}}`}</style>

      {/* status chip row */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
        <span
          aria-hidden
          style={{
            width: 5, height: 5, borderRadius: 99,
            background: called ? headColor : "#dc2626",
            animation: live && !reducedRef.current ? "smLivePulse 1.8s ease-in-out infinite" : "none",
          }}
        />
        <span style={{ fontFamily: OSWALD, fontWeight: 700, fontSize: 9, letterSpacing: "0.22em", textTransform: "uppercase", color: called ? headColor : "rgba(var(--fc-ink-rgb, 244,244,239),calc(0.55 * var(--fc-mute, 1) + var(--fc-floor, 0)))" }}>
          {called ? "Called" : live ? `Live · ${reportingPct.toFixed(reportingPct >= 10 ? 0 : 1)}%` : "Forecast"}
        </span>
      </div>

      {/* headline: LEADER +M pts · P% to win · BAND */}
      <div style={{ display: "flex", alignItems: "baseline", flexWrap: "wrap", gap: 8, marginBottom: 4 }}>
        <span style={{ fontFamily: OSWALD, fontWeight: 700, fontSize: 24, letterSpacing: "0.01em", textTransform: "uppercase", color: INK, lineHeight: 1 }}>
          {headName}
        </span>
        <span style={{ fontFamily: MONO, fontSize: 25, fontWeight: 700, color: headColor, letterSpacing: "-0.02em", lineHeight: 1, fontVariantNumeric: "tabular-nums" }}>
          +{M.toFixed(1)}
        </span>
        <span style={{ fontFamily: MONO, fontSize: 11, color: "rgba(var(--fc-ink-rgb, 244,244,239),calc(0.4 * var(--fc-mute, 1) + var(--fc-floor, 0)))", marginLeft: -3 }}>pts</span>
        <span style={{ color: "rgba(var(--fc-ink-rgb, 244,244,239),calc(0.5 * var(--fc-mute, 1) + var(--fc-floor, 0)))", fontSize: 13 }}>·</span>
        <span style={{ fontFamily: MONO, fontSize: 15, fontWeight: 600, color: headColor, fontVariantNumeric: "tabular-nums" }}>
          {(pHead * 100).toFixed(0)}%
        </span>
        <span style={{ fontSize: 12, color: "rgba(var(--fc-ink-rgb, 244,244,239),calc(0.55 * var(--fc-mute, 1) + var(--fc-floor, 0)))", fontWeight: 500 }}>to win</span>
        <span
          style={{
            fontFamily: OSWALD, fontSize: 9, fontWeight: 700, letterSpacing: "0.22em", textTransform: "uppercase",
            color: headColor, padding: "4px 8px", marginLeft: 2,
            background: `color-mix(in oklab, ${headColor} 10%, transparent)`,
            border: `1px solid color-mix(in oklab, ${headColor} 62%, transparent)`,
          }}
        >
          {band}
        </span>
      </div>

      {/* the dial */}
      <svg
        width="100%"
        viewBox={`0 ${-tipOverhang - centerTicLen - 2} ${SVG_W} ${SVG_H + tipOverhang + centerTicLen + 4}`}
        style={{ overflow: "visible", display: "block" }}
      >
        <defs>
          <clipPath id="smDialAbove">
            <rect x={cx - rOuter - baseExtend - 4} y={cy - rOuter - tipOverhang - 4} width={2 * (rOuter + baseExtend) + 8} height={rOuter + tipOverhang + 8} />
          </clipPath>
        </defs>
        <g clipPath="url(#smDialAbove)">
          {leadZones.map((z, i) => (
            <path key={`lz${i}`} d={wedgePath(cx, cy, rOuter, z.from, z.to)} fill={leaderColor} fillOpacity={z.alpha} />
          ))}
          {runZones.map((z, i) => (
            <path key={`rz${i}`} d={wedgePath(cx, cy, rOuter, z.from, z.to)} fill={runnerColor} fillOpacity={z.alpha} />
          ))}
        </g>
        <path d={wedgePath(cx, cy, rInner, -90, 90)} style={{ fill: PAGE }} />
        <path d={arcPath(cx, cy, rOuter, -90, 90)} fill="none" style={{ stroke: INK }} strokeWidth="2.4" strokeLinecap="round" />
        <path d={arcPath(cx, cy, rInner, -90, 90)} fill="none" style={{ stroke: INK }} strokeWidth="2.4" strokeLinecap="round" />
        <line x1={cx - rOuter - baseExtend} y1={cy} x2={cx + rOuter + baseExtend} y2={cy} style={{ stroke: INK }} strokeWidth="2.4" strokeLinecap="round" />
        <line x1={cx} y1={cy - rOuter - centerTicLen} x2={cx} y2={cy - rOuter + 1} style={{ stroke: INK }} strokeWidth="2.4" strokeLinecap="round" />
        <g transform={`translate(${cx} ${cy}) rotate(${angle.toFixed(3)})`} style={{ transition: reducedRef.current ? "none" : "transform 520ms cubic-bezier(0.4, 0, 0.2, 1)" }}>
          <polygon points={needlePoints} style={{ fill: INK }} />
        </g>
        <circle cx={cx} cy={cy} r="14" style={{ fill: INK }} />
        <circle cx={cx - 0.8} cy={cy - 0.8} r="3.6" style={{ fill: "var(--fc-bg, var(--canvas))", opacity: 0.35 }} />
        <text x={cx - rOuter - baseExtend} y={cy + 16} textAnchor="start" style={{ fontFamily: OSWALD, fontSize: 11, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", fill: leaderColor }}>
          {leaderName}
        </text>
        <text x={cx + rOuter + baseExtend} y={cy + 16} textAnchor="end" style={{ fontFamily: OSWALD, fontSize: 11, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", fill: runnerColor }}>
          {runnerName}
        </text>
      </svg>
    </div>
  );
}
