"use client";

// Oklahoma county choropleth. Geometry is baked SVG lifted from the TPSI
// Oklahoma runoff forecast engine, so it renders with no fetch and no
// projection math.
//
// Unlike the four-way Florida primary, a runoff has exactly two names, so this
// uses a true divergent ramp: one continuous scale running Mazzei-blue through
// a neutral middle to Drummond-red, keyed on the signed Drummond − Mazzei
// margin. Counties whose interval crosses zero are hatched, which is 74 of 77 —
// the county baselines are a demographic decomposition of a statewide poll, not
// 77 local polls, and we never name a county winner off them.

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { OK_COUNTY_PATHS, OK_VIEWBOX } from "../_data/okCountyGeo";
import { CANDIDATE_ORDER, CANDIDATE_LAST, type CandidateKey } from "../_data/okCountyForecast";
import type { CountyProjection, LiveCounty } from "./countyForecast";
import { fmtReporting } from "./countyForecast";

export type MapView = "forecast" | "results";
export type ForecastMode = "margin" | "turnout";

type RGB = [number, number, number];

/** Light/dark pair per candidate, derived from --k1/--k2 so the fills, the
 *  legend, the topline and the table all stay the same colour. */
const CAND_RGB: Record<CandidateKey, [RGB, RGB]> = {
  drummond: [[209, 137, 130], [110, 36, 29]], // #B23A2E
  mazzei: [[120, 168, 182], [19, 68, 83]],    // #1E6E86
};

export const CAND_CSS: Record<CandidateKey, string> = {
  drummond: "var(--k1)",
  mazzei: "var(--k2)",
};

const MID_DARK: RGB = [58, 58, 66];
const MID_LIGHT: RGB = [232, 232, 226];
const T1_DARK: RGB = [30, 30, 36];
const T1_LIGHT: RGB = [237, 237, 231];
const T2: RGB = [15, 95, 85];

/** Margin at which a county's fill reaches full saturation. The whole state
 *  models inside ±12, so a wider cap would render Oklahoma uniformly grey. */
const MARGIN_MAX = 12;

const mix = (a: RGB, b: RGB, t: number): RGB => [
  Math.round(a[0] + (b[0] - a[0]) * t),
  Math.round(a[1] + (b[1] - a[1]) * t),
  Math.round(a[2] + (b[2] - a[2]) * t),
];
const rgb = (c: RGB) => `rgb(${c[0]},${c[1]},${c[2]})`;
const clamp = (n: number, lo: number, hi: number) => Math.min(Math.max(n, lo), hi);

/** Divergent ramp on the signed Drummond − Mazzei margin. */
function cDiverge(signedMargin: number, mid: RGB): string {
  const key: CandidateKey = signedMargin >= 0 ? "drummond" : "mazzei";
  const [light, dark] = CAND_RGB[key];
  const d = clamp(Math.abs(signedMargin), 0, MARGIN_MAX) / MARGIN_MAX;
  return rgb(d < 0.5 ? mix(mid, light, d * 2) : mix(light, dark, (d - 0.5) * 2));
}

/** Sequential turnout ramp, power-scaled so the rural counties stay legible
 *  next to Oklahoma and Tulsa. */
const cVotes = (v: number, vmax: number, t1: RGB) =>
  rgb(mix(t1, T2, Math.pow(v / vmax, 0.42)));

const fmtInt = (n: number) => Math.round(Number(n) || 0).toLocaleString("en-US");
const titleCase = (s: string) =>
  s.toLowerCase().replace(/(^|[\s-])([a-z])/g, (_, p, c) => p + c.toUpperCase());

const [RAW_X, RAW_Y, RAW_W, RAW_H] = OK_VIEWBOX.split(/\s+/).map(Number);

// Oklahoma is a wide, short state; without padding the panhandle rides the top
// and bottom edges of the frame. Pad the box rather than the geometry.
const PAD_Y = RAW_H * 0.08;
const PAD_X = RAW_W * 0.02;
const VB_X = RAW_X - PAD_X;
const VB_Y = RAW_Y - PAD_Y;
const VB_W = RAW_W + PAD_X * 2;
const VB_H = RAW_H + PAD_Y * 2;
const VIEWBOX = `${VB_X} ${VB_Y} ${VB_W} ${VB_H}`;

const MIN_K = 1;
const MAX_K = 12;

const TIP_W = 250;
const TIP_H = 180;
const TIP_GAP = 12;
type Transform = { k: number; x: number; y: number };
const IDENTITY: Transform = { k: 1, x: 0, y: 0 };

/** Keeps the geometry covering the viewport at every zoom level. */
function clampT(t: Transform): Transform {
  const k = clamp(t.k, MIN_K, MAX_K);
  return {
    k,
    x: clamp(t.x, (VB_X + VB_W) * (1 - k), VB_X * (1 - k)),
    y: clamp(t.y, (VB_Y + VB_H) * (1 - k), VB_Y * (1 - k)),
  };
}

/** Follows the site's <html data-theme> so the ramps flip with everything else. */
function useSiteTheme(): "light" | "dark" {
  const [theme, setTheme] = useState<"light" | "dark">("light");
  useEffect(() => {
    const read = () =>
      setTheme(
        document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light",
      );
    read();
    const mo = new MutationObserver(read);
    mo.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
    return () => mo.disconnect();
  }, []);
  return theme;
}

interface Props {
  view: MapView;
  mode: ForecastMode;
  /** Live-blended county projections keyed by UPPERCASE county name. */
  counties: Record<string, CountyProjection>;
  /** Live county returns keyed by UPPERCASE county name, when CivicAPI has them. */
  liveCounties?: Record<string, LiveCounty>;
}

export default function OklahomaCountyMap({ view, mode, counties, liveCounties }: Props) {
  const [hover, setHover] = useState<
    { c: CountyProjection; x: number; y: number; w: number; h: number } | null
  >(null);
  const [t, setT] = useState<Transform>(IDENTITY);
  const [dragging, setDragging] = useState(false);

  const wrapRef = useRef<HTMLDivElement | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);
  const drag = useRef<{ id: number; x: number; y: number; moved: boolean } | null>(null);

  const theme = useSiteTheme();
  const mid = theme === "dark" ? MID_DARK : MID_LIGHT;
  const t1 = theme === "dark" ? T1_DARK : T1_LIGHT;

  const vmax = useMemo(
    () => Object.values(counties).reduce((m, c) => Math.max(m, c.projectedTurnout), 1),
    [counties],
  );

  // Client pixels → viewBox units, honouring the letterboxing that
  // preserveAspectRatio="xMidYMid meet" introduces.
  const toViewBox = useCallback((clientX: number, clientY: number) => {
    const svg = svgRef.current;
    if (!svg) return null;
    const r = svg.getBoundingClientRect();
    if (!r.width || !r.height) return null;
    const s = Math.min(r.width / VB_W, r.height / VB_H);
    return {
      x: VB_X + (clientX - r.left - (r.width - VB_W * s) / 2) / s,
      y: VB_Y + (clientY - r.top - (r.height - VB_H * s) / 2) / s,
    };
  }, []);

  const zoomAt = useCallback(
    (factor: number, clientX?: number, clientY?: number) => {
      setT((prev) => {
        const k = clamp(prev.k * factor, MIN_K, MAX_K);
        const anchor =
          clientX != null && clientY != null
            ? toViewBox(clientX, clientY)
            : { x: VB_X + VB_W / 2, y: VB_Y + VB_H / 2 };
        if (!anchor) return prev;
        const px = (anchor.x - prev.x) / prev.k;
        const py = (anchor.y - prev.y) / prev.k;
        return clampT({ k, x: anchor.x - px * k, y: anchor.y - py * k });
      });
    },
    [toViewBox],
  );

  // React attaches wheel passively, so the zoom listener is registered by hand.
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      // Trackpad pinch arrives as a ctrlKey wheel; a mouse wheel does not.
      const step = e.ctrlKey ? 0.012 : 0.0022;
      zoomAt(Math.exp(-e.deltaY * step), e.clientX, e.clientY);
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, [zoomAt]);

  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.button !== 0) return;
    // Capturing the pointer here would retarget pointerup and swallow the
    // control's click, so the zoom buttons opt out of panning entirely.
    if ((e.target as Element).closest(".ok-zoom")) return;
    drag.current = { id: e.pointerId, x: e.clientX, y: e.clientY, moved: false };
    e.currentTarget.setPointerCapture(e.pointerId);
    setDragging(true);
  };

  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const d = drag.current;
    if (!d || d.id !== e.pointerId) return;
    const svg = svgRef.current;
    if (!svg) return;
    const r = svg.getBoundingClientRect();
    const s = Math.min(r.width / VB_W, r.height / VB_H) || 1;
    const dx = (e.clientX - d.x) / s;
    const dy = (e.clientY - d.y) / s;
    if (Math.abs(dx) + Math.abs(dy) > 1) d.moved = true;
    d.x = e.clientX;
    d.y = e.clientY;
    setT((prev) => clampT({ ...prev, x: prev.x + dx, y: prev.y + dy }));
    if (d.moved) setHover(null);
  };

  const endDrag = (e: React.PointerEvent<HTMLDivElement>) => {
    if (drag.current?.id === e.pointerId) {
      drag.current = null;
      setDragging(false);
    }
  };

  const live = hover && liveCounties ? liveCounties[hover.c.name.toUpperCase()] : undefined;

  return (
    <div
      ref={wrapRef}
      className={`ok-map-wrap${dragging ? " dragging" : ""}`}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={endDrag}
      onPointerCancel={endDrag}
      onPointerLeave={() => setHover(null)}
    >
      <svg
        ref={svgRef}
        viewBox={VIEWBOX}
        preserveAspectRatio="xMidYMid meet"
        className="ok-map"
        role="img"
        aria-label="Oklahoma counties"
      >
        <defs>
          <pattern
            id="ok-hatch"
            width="6"
            height="6"
            patternUnits="userSpaceOnUse"
            patternTransform="rotate(45)"
          >
            <line className="ok-hatch-line" x1="0" y1="0" x2="0" y2="6" strokeWidth="1.4" />
          </pattern>
        </defs>
        <g transform={`translate(${t.x} ${t.y}) scale(${t.k})`}>
          {Object.entries(OK_COUNTY_PATHS).map(([key, d]) => {
            const c = counties[key];
            if (!c) return null;

            let fill: string;
            if (view === "results") {
              const lc = liveCounties?.[key];
              if (!lc || lc.total <= 0) {
                fill = "var(--map-blank)";
              } else {
                const signed =
                  ((lc.votes.drummond - lc.votes.mazzei) / lc.total) * 100;
                fill = cDiverge(signed, mid);
              }
            } else if (mode === "turnout") {
              fill = cVotes(c.projectedTurnout, vmax, t1);
            } else {
              fill = cDiverge(c.shares.drummond - c.shares.mazzei, mid);
            }

            return (
              <g key={key}>
                <path
                  className="ok-cty"
                  d={d}
                  fill={fill}
                  vectorEffect="non-scaling-stroke"
                  onPointerMove={(e) => {
                    if (drag.current) return;
                    const r = wrapRef.current?.getBoundingClientRect();
                    if (!r) return;
                    setHover({
                      c,
                      x: e.clientX - r.left,
                      y: e.clientY - r.top,
                      w: r.width,
                      h: r.height,
                    });
                  }}
                  onPointerLeave={() => setHover(null)}
                />
                {view === "forecast" && mode === "margin" && c.tooCloseToCall && (
                  <path className="ok-cty-hatch" d={d} fill="url(#ok-hatch)" />
                )}
              </g>
            );
          })}
        </g>
      </svg>

      <div className="ok-zoom" role="group" aria-label="Zoom map">
        <button type="button" aria-label="Zoom in" disabled={t.k >= MAX_K} onClick={() => zoomAt(1.5)}>
          +
        </button>
        <button
          type="button"
          aria-label="Zoom out"
          disabled={t.k <= MIN_K}
          onClick={() => zoomAt(1 / 1.5)}
        >
          −
        </button>
        <button
          type="button"
          className="reset"
          aria-label="Reset zoom"
          disabled={t.k === 1}
          onClick={() => setT(IDENTITY)}
        >
          RESET
        </button>
      </div>

      {hover && (
        <div
          className="ok-tip"
          style={{
            left: hover.x,
            top: hover.y,
            // Percentage translate flips the tip across the cursor without measuring it.
            transform: `translate(${
              hover.x + TIP_GAP + TIP_W > hover.w ? `calc(-100% - ${TIP_GAP}px)` : `${TIP_GAP}px`
            }, ${
              hover.y + TIP_GAP + TIP_H > hover.h ? `calc(-100% - ${TIP_GAP}px)` : `${TIP_GAP}px`
            })`,
          }}
        >
          <strong>{titleCase(hover.c.name)}</strong>
          {view === "results" ? (
            live && live.total > 0 ? (
              <>
                {CANDIDATE_ORDER.map((k) => (
                  <div className="ok-tip-row" key={k}>
                    <span style={{ color: CAND_CSS[k] }}>{CANDIDATE_LAST[k]}</span>
                    <b>
                      {((live.votes[k] / live.total) * 100).toFixed(1)}% · {fmtInt(live.votes[k])}
                    </b>
                  </div>
                ))}
                <div className="ok-tip-sub">
                  {fmtInt(live.total)} counted · {fmtReporting(live.reporting)}% reporting
                </div>
              </>
            ) : (
              <div className="ok-tip-sub">No votes reported</div>
            )
          ) : (
            <>
              {CANDIDATE_ORDER.map((k) => (
                <div className="ok-tip-row" key={k}>
                  <span style={{ color: CAND_CSS[k] }}>{CANDIDATE_LAST[k]}</span>
                  <b>{hover.c.shares[k].toFixed(1)}%</b>
                </div>
              ))}
              <div className="ok-tip-sub">
                {CANDIDATE_LAST[hover.c.leader]} +{hover.c.margin.toFixed(1)} [
                {hover.c.ci90[0].toFixed(0)} to {hover.c.ci90[1].toFixed(0)}]
              </div>
              <div className="ok-tip-sub">
                {fmtInt(hover.c.projectedTurnout)} projected ballots ·{" "}
                {hover.c.reporting > 0
                  ? `${fmtReporting(hover.c.reporting)}% reporting`
                  : "no returns yet"}
              </div>
              {hover.c.tooCloseToCall && <div className="ok-tip-flag">Too close to call</div>}
            </>
          )}
        </div>
      )}
    </div>
  );
}
