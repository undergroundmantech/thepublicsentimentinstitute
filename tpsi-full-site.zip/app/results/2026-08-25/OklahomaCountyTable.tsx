"use client";

// County-by-county board. FORECAST reads the TPSI baseline blended with the
// shrunk statewide swing (countyForecast.ts); RESULTS reads live CivicAPI
// county returns, which sit at zero until Oklahoma reports below the statewide
// level.

import React, { useMemo, useState } from "react";
import { CANDIDATE_ORDER, CANDIDATE_LAST, type CandidateKey } from "../_data/okCountyForecast";
import { CAND_CSS } from "./OklahomaCountyMap";
import type { CountyProjection, LiveCounty } from "./countyForecast";
import { fmtReporting } from "./countyForecast";

const fmtInt = (n: number) => Math.round(Number(n) || 0).toLocaleString("en-US");

type SortKey = "turnout" | "az" | "region" | "margin" | "reporting" | CandidateKey;

interface Props {
  view: "forecast" | "results";
  counties: CountyProjection[];
  liveCounties?: Record<string, LiveCounty>;
}

type Row = {
  c: CountyProjection;
  turnout: number;
  shares: Record<CandidateKey, number>;
  votes: Record<CandidateKey, number>;
  leader: CandidateKey;
  margin: number;
};

const emptyTally = (): Record<CandidateKey, number> => ({ drummond: 0, mazzei: 0 });

export default function OklahomaCountyTable({ view, counties, liveCounties }: Props) {
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<SortKey>("turnout");

  const rows = useMemo<Row[]>(() => {
    const query = q.trim().toLowerCase();
    const list = query
      ? counties.filter(
          (c) =>
            c.name.toLowerCase().includes(query) || c.region.toLowerCase().includes(query),
        )
      : counties;

    return list
      .map((c): Row => {
        if (view !== "results") {
          return {
            c,
            turnout: c.projectedTurnout,
            shares: c.shares,
            votes: c.votes,
            leader: c.leader,
            margin: c.margin,
          };
        }
        const lc = liveCounties?.[c.name.toUpperCase()];
        const total = lc?.total ?? 0;
        const shares = total
          ? (Object.fromEntries(
              CANDIDATE_ORDER.map((k) => [k, ((lc!.votes[k] ?? 0) / total) * 100]),
            ) as Record<CandidateKey, number>)
          : emptyTally();
        const ordered = CANDIDATE_ORDER.map((k) => [k, shares[k]] as [CandidateKey, number]).sort(
          (a, b) => b[1] - a[1],
        );
        return {
          c,
          turnout: total,
          shares,
          votes: (lc?.votes ?? emptyTally()) as Record<CandidateKey, number>,
          leader: ordered[0][0],
          margin: total ? ordered[0][1] - ordered[1][1] : 0,
        };
      })
      .sort((a, b) => {
        if (sort === "az") return a.c.name.localeCompare(b.c.name);
        if (sort === "region")
          return a.c.region.localeCompare(b.c.region) || b.turnout - a.turnout;
        if (sort === "margin") return b.margin - a.margin;
        // Least complete first, so whatever is still outstanding leads.
        if (sort === "reporting") return a.c.reporting - b.c.reporting || b.turnout - a.turnout;
        if (sort === "turnout") return b.turnout - a.turnout || a.c.name.localeCompare(b.c.name);
        return b.shares[sort] - a.shares[sort];
      });
  }, [q, sort, view, counties, liveCounties]);

  const cell = (r: Row, k: CandidateKey) => (
    <td className="num" key={k}>
      <span className="rd-cand-cell">
        <b style={{ color: CAND_CSS[k] }}>{r.shares[k].toFixed(1)}%</b>
        <span className="rd-cand-votes">{fmtInt(r.votes[k])}</span>
      </span>
    </td>
  );

  return (
    <div className="rd-county">
      <div className="rd-county-tools">
        <div className="rd-county-search">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" aria-hidden>
            <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="2" />
            <path d="M21 21l-4.3-4.3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
          <input
            type="text"
            placeholder="search counties…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
        <div className="rd-county-sorts" role="group" aria-label="Sort counties">
          {(
            [
              ["turnout", view === "results" ? "votes" : "turnout"],
              ["az", "a–z"],
              ["region", "region"],
              ["reporting", "reporting"],
              ["margin", "margin"],
              ...CANDIDATE_ORDER.map((k) => [k, CANDIDATE_LAST[k].toLowerCase()]),
            ] as [SortKey, string][]
          ).map(([key, label]) => (
            <button
              key={key}
              type="button"
              className={sort === key ? "on" : ""}
              onClick={() => setSort(key)}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="rd-county-tablewrap">
        <table className="rd-county-table ok-county-table">
          <colgroup>
            <col style={{ width: "19%" }} />
            <col style={{ width: "17%" }} />
            <col style={{ width: "10%" }} />
            <col style={{ width: "12%" }} />
            <col style={{ width: "17%" }} />
            <col style={{ width: "17%" }} />
            <col style={{ width: "8%" }} />
          </colgroup>
          <thead>
            <tr>
              <th>county</th>
              <th>region</th>
              <th className="num">reporting</th>
              <th className="num">{view === "results" ? "votes" : "turnout"}</th>
              {CANDIDATE_ORDER.map((k) => (
                <th className="num" key={k}>
                  {CANDIDATE_LAST[k].toLowerCase()}
                </th>
              ))}
              <th className="num">margin</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={5 + CANDIDATE_ORDER.length} className="rd-county-loading">
                  no counties match “{q}”.
                </td>
              </tr>
            ) : (
              rows.map((r) => (
                <tr key={r.c.key}>
                  <td>
                    {r.c.name}
                    {view === "forecast" && r.c.tooCloseToCall ? (
                      <i className="rd-cand-tcc" title="Too close to call" aria-hidden />
                    ) : null}
                  </td>
                  <td className="ok-region-cell">{r.c.region}</td>
                  <td className="num">{fmtReporting(r.c.reporting)}%</td>
                  <td className="num">{fmtInt(r.turnout)}</td>
                  {CANDIDATE_ORDER.map((k) => cell(r, k))}
                  <td className="num">
                    {r.turnout > 0 ? (
                      <span style={{ color: CAND_CSS[r.leader] }}>+{r.margin.toFixed(1)}</span>
                    ) : (
                      "—"
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
