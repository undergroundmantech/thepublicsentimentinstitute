# Sarah Huckabee Sanders Watchdog File

Subject: Sarah Huckabee Sanders, Republican, AR, running for Governor in 2026
Current office: Governor of Arkansas
Compiled: 2026-10-23 for the On Point Politics watchdog database, onpointpolitics.us
Status: queued for hand research, priority 1. This file holds the roster facts, the office levers, and FEC pipeline data when the pipeline has run. It is not yet a finished Tier 2 profile.

## Race

Race status: nominee. Rating: Cook: Solid Republican. Current holder of the seat: Sarah Huckabee Sanders.
Opponents: Fredrick Love, Democrat.
Roster note: sitting governor

## Committee assignments

None in the roster file. Governors and challengers have none.

## Money

Not yet pulled. Run pipeline/fec_pull.py for federal subjects. Governors and other state candidates need hand research in the state campaign finance system.

## Levers this office controls

Template rows from the office and committee assignments. Each needs the specific decision, the date, and the subject position before it counts as a finding.

| Decision | Where it sits | Which blocs care |
|---|---|---|
| Public utility commission appointments and rate case posture | Governor | Utilities and energy; Utilities and data centers |
| Gaming regulator appointments and tribal compact negotiation | Governor | Gambling |
| State budget, line item veto and bill signing or veto | Governor | Every bloc |
| Agency head appointments and major state contracts, including Medicaid managed care | Governor | Health care and pharma; Detention vendors; Developers and construction |
| University and school board appointments, voucher and school choice program funding | Governor | School choice and family |
| Insurance commissioner or regulator appointment and tort law bills | Governor | Insurance and tort |
| Emergency declarations and no bid emergency procurement | Governor | Detention vendors; Developers and construction |
| Judicial appointments where the governor appoints | Governor | Insurance and tort; Ideological groups |
| Data center incentives, permitting and power siting | Governor | Utilities and data centers; AI industry; Tech |
| Clemency, pardons and suspension powers | Governor | Enforcement and disclosure |

## Where to start

- Ballotpedia: https://ballotpedia.org/Sarah_Huckabee_Sanders
- Roster source: https://ballotpedia.org/Arkansas_gubernatorial_election,_2026

## What we could not verify

Everything beyond the roster row. This subject has not been hand researched yet.
