"use client";

import React, { useEffect, useMemo, useState } from "react";
import Link from "@/app/components/Link";
import { SERVICES } from "@/app/on-point-polling/home/services";
import { AUDIENCES } from "@/app/on-point-polling/home/audiences";

const CONTACT_EMAIL = "onpointpoliticscontact@gmail.com";

type FormState = {
  name: string;
  email: string;
  org: string;
  topic: string;
  kind: string;
  geography: string;
  audience: string;
  timeline: string;
  message: string;
};

type Status =
  | { type: "idle" }
  | { type: "sending" }
  | { type: "sent" }
  | { type: "error"; message: string };

const EMPTY_FORM: FormState = {
  name: "", email: "", org: "", topic: "", kind: "",
  geography: "", audience: "", timeline: "", message: "",
};

const TOPICS = [...SERVICES.map((x) => x.name), "A program of several studies", "Media or interview request", "Something else"];
const KINDS = [...AUDIENCES.map((x) => x.name), "Other"];

const TAKES = [
  { t: "Polling", n: "Benchmark, tracking, issue and ballot measure polls for any race from national to a city ward." },
  { t: "Strategy research", n: "Viability studies, message and ad tests, modeled voter universes and post election autopsies." },
  { t: "Modeling and dashboards", n: "County simulations, likely voter models, MRP and election night desks." },
  { t: "Fieldwork and data", n: "Voter file samples, text programs and white label fieldwork for consultants and pollsters." },
]

export default function ContactPage() {
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [status, setStatus] = useState<Status>({ type: "idle" });
  // a service or a kind of client picked on the polling pages arrives in the link
  useEffect(() => {
    const q = new URLSearchParams(window.location.search);
    const svc = SERVICES.find((x) => x.slug === q.get("service"));
    const aud = AUDIENCES.find((x) => x.slug === q.get("for"));
    if (svc || aud) setForm((f) => ({ ...f, topic: svc?.name ?? f.topic, kind: aud?.name ?? f.kind }));
  }, []);

  const onChange =
    (key: keyof FormState) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      setForm((s) => ({ ...s, [key]: e.target.value }));

  const canSubmit = useMemo(
    () => form.name.trim().length > 0 && form.email.trim().includes("@") && form.message.trim().length > 10,
    [form]
  );

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;
    setStatus({ type: "sending" });

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, to: CONTACT_EMAIL }),
      });
      if (!res.ok) throw new Error("server error");
      setStatus({ type: "sent" });
    } catch {
      const subject = encodeURIComponent("[On Point Polling Proposal Request] " + (form.topic || "General Inquiry") + (form.kind ? ` for ${form.kind}` : ""));
      const body = encodeURIComponent(
        [
          `Name: ${form.name}`,
          `Email: ${form.email}`,
          `Organization: ${form.org || "N/A"}`,
          `Client type: ${form.kind || "N/A"}`,
          ``,
          `Topic / Issue: ${form.topic || "N/A"}`,
          `Geography: ${form.geography || "N/A"}`,
          `Audience: ${form.audience || "N/A"}`,
          `Timeline: ${form.timeline || "N/A"}`,
          ``,
          `Message:`,
          form.message,
        ].join("\n")
      );
      window.location.href = `mailto:${CONTACT_EMAIL}?subject=${subject}&body=${body}`;
      setStatus({ type: "sent" });
    }
  };

  return (
    <div className="opp ct">
      <style>{CSS}</style>
      <nav className="crumbs" aria-label="Breadcrumb"><Link href="/">Home</Link><span className="sep">/</span><span>Contact</span></nav>
      <header className="ph">
        <div className="eye g">On Point Polling</div>
        <h1>Request a <em>proposal</em></h1>
        <p className="lede">Tell us the decision, the geography and the deadline. A researcher replies with a written proposal and quote, usually the same business day. Client work is confidential, and we work with both parties.</p>
        <div className="pmeta">
          <span>Reply <b>Same business day</b></span>
          <span>Fieldwork <b>48 to 72 hours</b></span>
          <span>Deliverables <b>Toplines, crosstabs, memo</b></span>
        </div>
      </header>

      <div className="layout">
        <section className="card" id="brief" aria-labelledby="ct-form-h">
          <div className="card-h"><h3 id="ct-form-h">Your project</h3><span className="eye" style={{ marginLeft: "auto" }}>Two minutes</span></div>
          <form className="card-b ct-form" onSubmit={onSubmit} aria-label="Project intake form">
            <p className="ct-intro">Name, email and a few sentences are enough. The rest helps us scope the work faster.</p>
            <div className="ct-grid">
              <label className="ct-field">
                <span>Name<i>*</i></span>
                <input value={form.name} onChange={onChange("name")} autoComplete="name" placeholder="Who are we talking to?" />
              </label>
              <label className="ct-field">
                <span>Email<i>*</i></span>
                <input value={form.email} onChange={onChange("email")} type="email" autoComplete="email" placeholder="you@organization.com" />
              </label>
              <label className="ct-field">
                <span>Organization</span>
                <input value={form.org} onChange={onChange("org")} placeholder="Campaign, committee, PAC, outlet or company" />
              </label>
              <label className="ct-field">
                <span>You are a</span>
                <select value={form.kind} onChange={onChange("kind")}>
                  <option value="">Pick the closest fit</option>
                  {KINDS.map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
              </label>
              <label className="ct-field">
                <span>Service</span>
                <select value={form.topic} onChange={onChange("topic")}>
                  <option value="">Pick the closest fit</option>
                  {TOPICS.map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
              </label>
              <label className="ct-field">
                <span>Geography</span>
                <input value={form.geography} onChange={onChange("geography")} placeholder="National, a state, a district, a city" />
              </label>
              <label className="ct-field">
                <span>Timeline</span>
                <input value={form.timeline} onChange={onChange("timeline")} placeholder="When do you need it in the field?" />
              </label>
              <label className="ct-field ct-wide">
                <span>Audience</span>
                <input value={form.audience} onChange={onChange("audience")} placeholder="Likely voters? Registered? A custom universe?" />
              </label>
              <label className="ct-field ct-wide">
                <span>The brief<i>*</i></span>
                <textarea value={form.message} onChange={onChange("message")} rows={5} placeholder="What do you need to learn, and why now?" />
              </label>
            </div>
            <div className="ct-actions">
              <button type="submit" className="btn g ct-send" disabled={!canSubmit || status.type === "sending"}>
                {status.type === "sending" ? "Sending..." : "Request a proposal"}
              </button>
              <span className="ct-status" role="status">
                {status.type === "sent" && <span className="ok">Thank you. If your email app opened with the brief, press send. We reply the same business day.</span>}
                {status.type === "error" && status.message}
                {status.type === "idle" && !canSubmit && "Name, email and a brief are required"}
              </span>
            </div>
          </form>
        </section>

        <aside className="side">
          <div className="card">
            <div className="card-h"><h3>Write to us</h3></div>
            <div className="card-b">
              <a className="ct-mail mono" href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a>
              <p style={{ fontSize: 13.5, marginTop: 10 }}>Prefer email? Everything the form asks fits in one message.</p>
            </div>
          </div>
          <div className="card">
            <div className="card-h"><h3>What the desk takes on</h3></div>
            <div>
              {TAKES.map((x, i) => (
                <div className="ct-take" key={x.t}>
                  <span className="mono">{String(i + 1).padStart(2, "0")}</span>
                  <div><b>{x.t}</b><p>{x.n}</p></div>
                </div>
              ))}
            </div>
          </div>
          <div className="callout"><div className="eye">Fieldwork</div>Polls are fielded by On Point Polling for On Point Politics. See the <Link href="/on-point-polling/services" style={{ textDecoration: "underline" }}>services</Link> and <Link href="/on-point-polling/methodology" style={{ textDecoration: "underline" }}>methodology</Link>.</div>
        </aside>
      </div>
    </div>
  );
}

const CSS = `
.ct .ct-intro { font-size: 14px; margin: 0 0 16px; }
.ct .ct-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
.ct .ct-wide { grid-column: 1 / -1; }
.ct .ct-field { display: grid; gap: 6px; }
.ct .ct-field > span { font: 700 10.5px var(--font-m); letter-spacing: .12em; text-transform: uppercase; color: var(--mute); }
.ct .ct-field > span i { font-style: normal; color: var(--ink); margin-left: 3px; }
.ct .ct-field input, .ct .ct-field select, .ct .ct-field textarea {
  width: 100%; padding: 11px 14px; border-radius: 10px; border: 1px solid var(--line2); background: var(--glass2);
  color: var(--ink); font: 500 14px var(--font-b); outline: none; transition: border-color .15s, box-shadow .15s; -webkit-appearance: none; appearance: none;
}
.ct .ct-field textarea { resize: vertical; min-height: 120px; line-height: 1.5; }
.ct .ct-field select { background-image: linear-gradient(45deg, transparent 50%, var(--mute) 50%), linear-gradient(135deg, var(--mute) 50%, transparent 50%); background-position: calc(100% - 18px) 50%, calc(100% - 13px) 50%; background-size: 5px 5px; background-repeat: no-repeat; padding-right: 34px; }
.ct .ct-field select option { background: var(--bg2); color: var(--ink); }
.ct .ct-field input::placeholder, .ct .ct-field textarea::placeholder { color: var(--mute2); }
.ct .ct-field input:focus-visible, .ct .ct-field select:focus-visible, .ct .ct-field textarea:focus-visible { border-color: var(--hi); box-shadow: 0 0 0 3px rgba(var(--line-rgb),.18); outline: none; }
.ct .ct-actions { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; margin-top: 18px; }
.ct .ct-send { padding: 12px 20px; font-size: 14px; }
.ct .ct-send:disabled { opacity: .45; cursor: not-allowed; transform: none; }
.ct .ct-send:focus-visible { outline: 2px solid var(--hi); outline-offset: 3px; }
.ct .ct-status { font-size: 13px; color: var(--mute); }
.ct .ct-status .ok { color: var(--ink); }
.ct .ct-mail { font-size: 13px; font-weight: 700; color: var(--ink); text-decoration: underline; text-underline-offset: 3px; word-break: break-all; }
.ct .ct-take { display: grid; grid-template-columns: 28px 1fr; gap: 8px; padding: 12px 18px; border-top: 1px solid var(--line); }
.ct .ct-take:first-child { border-top: 0; }
.ct .ct-take .mono { font-size: 12px; font-weight: 700; color: var(--mute); padding-top: 1px; }
.ct .ct-take b { font-size: 14px; }
.ct .ct-take p { font-size: 13px; color: var(--mute); margin: 2px 0 0; }
@media (max-width: 600px) { .ct .ct-grid { grid-template-columns: 1fr; } }
`;
