// On Point Politics redirect map: every tpsielections.com URL 301s to its onpointpolitics.us route.
// The retired experiments, /v2 and /polling/old/*, are answered 410 Gone by middleware.ts.

type Redirect = { source: string; destination: string; permanent: boolean; has?: { type: "host"; value: string }[] };
// Domain redirects live in Vercel, Settings, Domains, not here: a host rule here fought the www redirect there and looped.
const p = (source: string, destination: string, permanent = true): Redirect => ({ source, destination, permanent });

export const redirects: Redirect[] = [
  // Nov 8 2026: after the midterms the early vote tracker, Brazil 2026 and the election night pages are retired; their
  // addresses go to the pages that replaced them. The code stays in the repo and can be deleted later.
  p("/maps/early-vote", "/accuracy"),
  p("/maps/early-vote/:path*", "/accuracy"),
  p("/brasil", "/"),
  p("/brasil/:path*", "/"),
  p("/results", "/results/2026"),
  // Nov 2026 (Election Night 2.0): /results/monitor is live again: the Situation Monitor, with LIVE and REPLAY modes.
  p("/results/tonight", "/results/2026"),
  p("/results/tonight/:path*", "/results/2026"),
  p("/results/live", "/results/2026"),
  p("/results/live/:path*", "/results/2026"),
  p("/tpsi/situation-room", "/results/2026"),
  // Nov 6 2026: short addresses for the 2026 pollster ranking and the accuracy report
  p("/most-accurate-pollster-2026", "/most-accurate-pollster"),
  p("/most-accurate-poll", "/most-accurate-pollster"),
  p("/pollster-rankings", "/most-accurate-pollster"),
  p("/pollster-ratings", "/most-accurate-pollster"),
  p("/accuracy-report", "/accuracy"),
  p("/2026-accuracy", "/accuracy"),
  // short addresses people type or search for the early vote tracker
  p("/early-vote", "/accuracy"),
  p("/early-voting", "/accuracy"),
  p("/early-vote-tracker", "/accuracy"),
  p("/early-vote/:state", "/accuracy"),
  // Oct 24 2026: Indiana's comptroller race was listed twice, as auditor and as comptroller; one page now
  p("/forecast/statewide/in/comptroller", "/forecast/statewide/in/auditor"),
  p("/results/2026/comp-IN", "/results/2026/aud-IN"),
  // Oct 23 2026: retired and unfinished pages fold into the pages that replaced them
  p("/on-point-polling/situation-room", "/on-point-polling"),
  p("/results/forecast", "/forecast", false),
  p("/results/timeline-qa", "/results/2026", false),
  // Oct 22 2026: the swingometer and What If are their own pages
  p("/forecast/swingometer", "/swingometer"),
  p("/forecast/what-if", "/what-if"),
  p("/whatif", "/what-if"),
  // polls
  p("/polling/donaldtrumpapproval", "/polls/approval"),
  p("/polling/jdvanceapproval", "/polls/approval/vance"),
  // the unified averages page kept its ?race= deep links, which the new page still reads
  p("/polling/genericballot", "/polls/generic-ballot"),
  p("/polling/rightorwrongtrack", "/polls/right-track"),
  p("/polling/senatepolling", "/polls/senate"),
  p("/polling/governorpolling", "/polls/governor"),
  p("/polling/2028polling", "/polls/2028"),
  p("/polling/2025pollingview", "/polls"),
  p("/polling/floridarepublicanprimary", "/polls/fl/governor-gop-primary"),
  p("/polling/texasdemocratprimary", "/polls/tx/senate-dem-primary"),
  p("/polling/texasrepublicanprimary", "/polls/tx/senate-gop-primary"),
  p("/polling/mainedemocratprimary", "/polls/me/senate-dem-primary"),
  // the old New Hampshire page is 2024 presidential polling, so it joins the 2024 archive
  p("/polling/newhampshire", "/polls/archive/2024/nh"),
  p("/polling/2024president", "/polls/archive/2024"),
  p("/polling/:st(az|fl|ga|mi|mn|nc|nj|nm|nv|pa|tx|va|wi)2024president", "/polls/archive/2024/:st"),
  p("/polling", "/polls"),

  // forecast and maps
  p("/forecastratings", "/forecast"),
  p("/electoralmap", "/maps/electoral"),
  p("/partymap", "/maps/party-registration"),
  p("/earlyvote", "/accuracy"),
  p("/earlyvote/:path*", "/accuracy"),
  // voter registration totals are their own map, kept beside party registration
  p("/voterregistration", "/maps/voter-registration"),

  // results
  p("/results/onpoint", "/results/2026"),
  p("/results/onpoint/:path*", "/results/:path*"),

  // tpsi
  p("/tpsipoll", "/on-point-polling/polls"),
  p("/latestpoll", "/on-point-polling/polls"),
  p("/goldstandard", "/on-point-polling/methodology"),
  p("/situationroom", "/results/2026"),
  p("/SMSOptIn", "/on-point-polling/sms"),
  // the polling section moved from /tpsi to /on-point-polling on Oct 19 2026; every old link, including the SMS opt in
  // page and the poll pages linked from Substack, lands on its new address
  p("/tpsi", "/on-point-polling"),
  p("/tpsi/:path*", "/on-point-polling/:path*"),
  p("/TermsAndConditions", "/terms"),
];
