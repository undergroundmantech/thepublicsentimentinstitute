// app/polling/governorpolling/nebraska.ts
// Nebraska — 2026 Governor: Lynne Walz (D) vs. Jim Pillen (R)
// Generated from the On Point Polling forecast poll feed (run of 2026-09-22), merged with
// the polls this file already carried. Polls of matchups that are not on the
// ballot were dropped. Newest poll: 2026-10-18.

export type SampleType = "LV" | "RV" | "A";

export type Poll = {
  raceId: string;
  pollster: string;
  startDate: string; // YYYY-MM-DD
  endDate: string;   // YYYY-MM-DD
  sampleSize: number;
  sampleType: SampleType;
  moe?: number;
  results: Record<string, number>;
  notes?: string;
};

export const STATE = {
  abbr: "NE",
  name: "Nebraska",
};

export const DEFAULT_RACE_ID = "NE-GOV-2026";

export const RACES = [
  {
    raceId: "NE-GOV-2026",
    office: "Governor",
    year: 2026,
    candidates: ["Lynne Walz (D)", "Jim Pillen (R)"],
  },
] as const;

export const STATE_POLLS: Record<string, Poll[]> = {
  NE: [
    {"raceId": "NE-GOV-2026", "pollster": "Public Policy Polling (D)", "startDate": "2026-04-06", "endDate": "2026-04-07", "sampleSize": 670, "sampleType": "RV", "results": {"Lynne Walz (D)": 33.0, "Jim Pillen (R)": 38.0, "Other": 12.0, "Undecided": 17.0}},
    {"raceId": "NE-GOV-2026", "pollster": "Lake Research Partners (D)", "startDate": "2026-04-25", "endDate": "2026-04-29", "sampleSize": 900, "sampleType": "LV", "results": {"Lynne Walz (D)": 45.0, "Jim Pillen (R)": 47.0, "Undecided": 5.0}},
    {"raceId": "NE-GOV-2026", "pollster": "Public Policy Polling (D)", "startDate": "2026-09-01", "endDate": "2026-09-02", "sampleSize": 559, "sampleType": "RV", "results": {"Lynne Walz (D)": 31.0, "Jim Pillen (R)": 32.0, "Other": 21.0, "Undecided": 17.0}},
    {"raceId": "NE-GOV-2026", "pollster": "SurveyUSA", "startDate": "2026-09-08", "endDate": "2026-09-13", "sampleSize": 503, "sampleType": "LV", "results": {"Lynne Walz (D)": 35.0, "Jim Pillen (R)": 43.0, "Other": 13.0, "Undecided": 9.0}},
    {"raceId": "NE-GOV-2026", "pollster": "Lake Research Partners (D)", "startDate": "2026-09-08", "endDate": "2026-09-14", "sampleSize": 600, "sampleType": "RV", "results": {"Lynne Walz (D)": 40.0, "Jim Pillen (R)": 40.0, "Brett Lindstrom (AF)": 9.0, "Rick Beard (LMN)": 4.0, "Undecided": 7.0}, "notes": "Walz campaign internal. Sample size not published, entered as 600. 2024 recalled vote Trump 57, Harris 40."},
    {"raceId": "NE-GOV-2026", "pollster": "co/efficient (R)", "startDate": "2026-09-28", "endDate": "2026-09-30", "sampleSize": 1113, "sampleType": "LV", "results": {"Lynne Walz (D)": 38.0, "Jim Pillen (R)": 43.0, "Other": 8.0, "Undecided": 11.0}, "notes": "Sample R57, D27."},
    {"raceId": "NE-GOV-2026", "pollster": "YouGov", "startDate": "2026-09-24", "endDate": "2026-10-03", "sampleSize": 1809, "sampleType": "LV", "results": {"Jim Pillen (R)": 44.0, "Lynne Walz (D)": 43.0, "Other": 2.0, "Undecided": 11.0}},
    {"raceId": "NE-GOV-2026", "pollster": "National Public Affairs", "startDate": "2026-10-02", "endDate": "2026-10-05", "sampleSize": 800, "sampleType": "LV", "results": {"Lynne Walz (D)": 40.0, "Jim Pillen (R)": 44.0, "Other": 12.0, "Undecided": 6.0}},
    {"raceId": "NE-GOV-2026", "pollster": "Public Policy Polling (D)", "startDate": "2026-10-13", "endDate": "2026-10-14", "sampleSize": 571, "sampleType": "RV", "results": {"Lynne Walz (D)": 43.0, "Jim Pillen (R)": 44.0, "Other": 8.0, "Undecided": 5.0}},
    {"raceId": "NE-GOV-2026", "pollster": "National Public Affairs", "startDate": "2026-10-15", "endDate": "2026-10-18", "sampleSize": 598, "sampleType": "LV", "results": {"Lynne Walz (D)": 41.0, "Jim Pillen (R)": 47.0, "Other": 8.0, "Undecided": 4.0}},
    {"raceId": "NE-GOV-2026", "pollster": "Global Strategy Group for Walz (D)", "startDate": "2026-10-13", "endDate": "2026-10-18", "sampleSize": 800, "sampleType": "LV", "results": {"Lynne Walz (D)": 43.8, "Jim Pillen (R)": 44.9, "Other": 5.6, "Undecided": 5.7}}
  ],
};
