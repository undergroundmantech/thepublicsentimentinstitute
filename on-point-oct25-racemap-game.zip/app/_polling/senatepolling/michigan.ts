// app/polling/senatepolling/michigan.ts
// Michigan — 2026 U.S. Senate: Abdul El-Sayed (D) vs. Mike Rogers (R)
// Generated from the On Point Polling forecast poll feed (run of 2026-09-22), merged with
// the polls this file already carried. Polls of matchups that are not on the
// ballot were dropped. Newest poll: 2026-10-22.

export type SampleType = "LV" | "RV" | "A";

export type Poll = {
  raceId: string;
  pollster: string;
  startDate: string; // YYYY-MM-DD
  endDate: string;   // YYYY-MM-DD
  sampleSize: number;
  sampleType: SampleType;
  moe?: number;
  results: Record<string, number>;
  notes?: string;
};

export const STATE = {
  abbr: "MI",
  name: "Michigan",
};

export const DEFAULT_RACE_ID = "MI-SEN-2026";

export const RACES = [
  {
    raceId: "MI-SEN-2026",
    office: "U.S. Senate",
    year: 2026,
    candidates: ["Abdul El-Sayed (D)", "Mike Rogers (R)"],
  },
] as const;

export const STATE_POLLS: Record<string, Poll[]> = {
  MI: [
    {"raceId": "MI-SEN-2026", "pollster": "Glengariff Group", "startDate": "2025-05-08", "endDate": "2025-05-08", "sampleSize": 600, "sampleType": "RV", "results": {"Abdul El-Sayed (D)": 41, "Mike Rogers (R)": 47}},
    {"raceId": "MI-SEN-2026", "pollster": "Rosetta Stone Communications (R)", "startDate": "2025-10-25", "endDate": "2025-10-25", "sampleSize": 637, "sampleType": "RV", "results": {"Abdul El-Sayed (D)": 31, "Mike Rogers (R)": 45}},
    {"raceId": "MI-SEN-2026", "pollster": "Mitchell Research & Communications", "startDate": "2025-11-21", "endDate": "2025-11-21", "sampleSize": 616, "sampleType": "RV", "results": {"Abdul El-Sayed (D)": 38, "Mike Rogers (R)": 41}},
    {"raceId": "MI-SEN-2026", "pollster": "Glengariff Group", "startDate": "2026-01-06", "endDate": "2026-01-06", "sampleSize": 600, "sampleType": "RV", "results": {"Abdul El-Sayed (D)": 47, "Mike Rogers (R)": 43}},
    {"raceId": "MI-SEN-2026", "pollster": "Emerson College", "startDate": "2026-01-25", "endDate": "2026-01-25", "sampleSize": 1000, "sampleType": "RV", "results": {"Abdul El-Sayed (D)": 43, "Mike Rogers (R)": 43}},
    {"raceId": "MI-SEN-2026", "pollster": "Beacon Research (D)/ Shaw & Co. Research (R)", "startDate": "2026-08-06", "endDate": "2026-08-10", "sampleSize": 1006, "sampleType": "RV", "results": {"Abdul El-Sayed (D)": 47.0, "Mike Rogers (R)": 51.0, "Undecided": 2.0}},
    {"raceId": "MI-SEN-2026", "pollster": "GBAO (D)", "startDate": "2026-08-06", "endDate": "2026-08-10", "sampleSize": 800, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 50.0, "Mike Rogers (R)": 44.0, "Undecided": 6.0}},
    {"raceId": "MI-SEN-2026", "pollster": "TIPP Insights (R)", "startDate": "2026-08-06", "endDate": "2026-08-10", "sampleSize": 1215, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 45.0, "Mike Rogers (R)": 42.0, "Other": 7.0, "Undecided": 6.0}},
    {"raceId": "MI-SEN-2026", "pollster": "Fabrizio Ward (R)/ Impact Research (D)", "startDate": "2026-08-09", "endDate": "2026-08-11", "sampleSize": 877, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 48.0, "Mike Rogers (R)": 47.0, "Undecided": 5.0}},
    {"raceId": "MI-SEN-2026", "pollster": "Susquehanna Polling & Research (R)", "startDate": "2026-08-11", "endDate": "2026-08-17", "sampleSize": 800, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 46.0, "Mike Rogers (R)": 39.0, "Other": 6.0, "Undecided": 9.0}},
    {"raceId": "MI-SEN-2026", "pollster": "Michigan State University/YouGov", "startDate": "2026-08-10", "endDate": "2026-08-20", "sampleSize": 779, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 50.0, "Mike Rogers (R)": 45.0, "Undecided": 5.0}},
    {"raceId": "MI-SEN-2026", "pollster": "Abacus Data", "startDate": "2026-08-26", "endDate": "2026-08-28", "sampleSize": 332, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 49.0, "Mike Rogers (R)": 45.0, "Other": 6.0}},
    {"raceId": "MI-SEN-2026", "pollster": "EPIC-MRA", "startDate": "2026-08-22", "endDate": "2026-08-28", "sampleSize": 600, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 48.5, "Mike Rogers (R)": 44.0, "Undecided": 7.5}},
    {"raceId": "MI-SEN-2026", "pollster": "Glengariff Group", "startDate": "2026-08-31", "endDate": "2026-09-03", "sampleSize": 600, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 44.0, "Mike Rogers (R)": 46.0, "Undecided": 9.0}},
    {"raceId": "MI-SEN-2026", "pollster": "SSRS", "startDate": "2026-08-31", "endDate": "2026-09-06", "sampleSize": 843, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 47.0, "Mike Rogers (R)": 44.0, "Other": 8.0}},
    {"raceId": "MI-SEN-2026", "pollster": "Trafalgar Group (R)", "startDate": "2026-09-07", "endDate": "2026-09-09", "sampleSize": 1079, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 46.0, "Mike Rogers (R)": 45.0, "Other": 2.0, "Undecided": 7.0}},
    {"raceId": "MI-SEN-2026", "pollster": "Emerson College", "startDate": "2026-09-12", "endDate": "2026-09-14", "sampleSize": 1000, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 48.0, "Mike Rogers (R)": 46.0, "Other": 2.0, "Undecided": 4.0}},
    {"raceId": "MI-SEN-2026", "pollster": "The Washington Post/SSPG", "startDate": "2026-09-10", "endDate": "2026-09-14", "sampleSize": 803, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 48.0, "Mike Rogers (R)": 45.0, "Other": 5.0, "Undecided": 2.0}},
    {"raceId": "MI-SEN-2026", "pollster": "InsiderAdvantage", "startDate": "2026-09-16", "endDate": "2026-09-17", "sampleSize": 1200, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 46.6, "Mike Rogers (R)": 44.7, "Other": 3.3, "Undecided": 5.4}},
    {"raceId": "MI-SEN-2026", "pollster": "Torchlight Strategies (R)", "startDate": "2026-09-15", "endDate": "2026-09-19", "sampleSize": 643, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 43.0, "Mike Rogers (R)": 44.0, "Other": 4.0, "Undecided": 9.0}},
    {"raceId": "MI-SEN-2026", "pollster": "Suffolk University", "startDate": "2026-09-16", "endDate": "2026-09-20", "sampleSize": 500, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 47.0, "Mike Rogers (R)": 40.0, "Other": 3.0, "Undecided": 8.0}},
    {"raceId": "MI-SEN-2026", "pollster": "Cygnal (R)/Beacon Research (D)", "startDate": "2026-09-18", "endDate": "2026-09-21", "sampleSize": 600, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 45.0, "Mike Rogers (R)": 40.0, "Undecided": 15.0}, "notes": "For Michigan Enjoyer."},
    {"raceId": "MI-SEN-2026", "pollster": "New York Times/Siena University", "startDate": "2026-09-15", "endDate": "2026-09-22", "sampleSize": 613, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 49.0, "Mike Rogers (R)": 44.0, "Undecided": 7.0}},
    {"raceId": "MI-SEN-2026", "pollster": "GBAO (D)", "startDate": "2026-09-19", "endDate": "2026-09-22", "sampleSize": 800, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 48.0, "Mike Rogers (R)": 44.0, "Undecided": 8.0}},
    {"raceId": "MI-SEN-2026", "pollster": "co/efficient (R)", "startDate": "2026-09-21", "endDate": "2026-09-23", "sampleSize": 843, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 45.0, "Mike Rogers (R)": 45.0, "Other": 2.0, "Undecided": 8.0}},
    {"raceId": "MI-SEN-2026", "pollster": "Big Data Poll", "startDate": "2026-09-22", "endDate": "2026-09-24", "sampleSize": 678, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 46.7, "Mike Rogers (R)": 42.1, "Undecided": 11.2}, "notes": "Likely voters with leaners."},
    {"raceId": "MI-SEN-2026", "pollster": "NPR/Marist", "startDate": "2026-09-24", "endDate": "2026-09-27", "sampleSize": 1200, "sampleType": "RV", "results": {"Abdul El-Sayed (D)": 51.0, "Mike Rogers (R)": 44.0, "Undecided": 5.0}, "notes": "Sample size not yet posted by Marist, entered as 1,200."},
    {"raceId": "MI-SEN-2026", "pollster": "Fox News/Beacon Research and Shaw & Company", "startDate": "2026-09-24", "endDate": "2026-09-28", "sampleSize": 1028, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 50.0, "Mike Rogers (R)": 49.0, "Undecided": 1.0}, "notes": "Likely voters. Registered voters, 1,203: El-Sayed 51, Rogers 48. Other and undecided 1 combined."},
    {"raceId": "MI-SEN-2026", "pollster": "Trafalgar Group (R)", "startDate": "2026-09-28", "endDate": "2026-09-30", "sampleSize": 1085, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 46.9, "Mike Rogers (R)": 45.1, "Other": 2.9, "Undecided": 5.0}},
    {"raceId": "MI-SEN-2026", "pollster": "Mitchell Research for CBS Detroit", "startDate": "2026-10-01", "endDate": "2026-10-01", "sampleSize": 682, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 45.6, "Mike Rogers (R)": 41.4, "Other": 7.0, "Undecided": 6.0}},
    {"raceId": "MI-SEN-2026", "pollster": "Z to A Research for Rust Belt Rising (D)", "startDate": "2026-09-28", "endDate": "2026-10-01", "sampleSize": 483, "sampleType": "RV", "results": {"Abdul El-Sayed (D)": 49.0, "Mike Rogers (R)": 42.0, "Other": 3.0, "Undecided": 6.0}, "notes": "Z to A Research for Rust Belt Rising, part of a 1,430 voter Michigan, Pennsylvania and Wisconsin sample; voter type not given."},
    {"raceId": "MI-SEN-2026", "pollster": "YouGov", "startDate": "2026-09-22", "endDate": "2026-10-04", "sampleSize": 3949, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 49.0, "Mike Rogers (R)": 48.0, "Other": 1.0, "Undecided": 2.0}},
    {"raceId": "MI-SEN-2026", "pollster": "Guidant Polling for Public First Action", "startDate": "2026-10-05", "endDate": "2026-10-05", "sampleSize": 600, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 48.5, "Mike Rogers (R)": 44.0, "Other": 1.0, "Undecided": 6.5}, "notes": "Released Oct 7. Two ballots, 48 to 43 and 49 to 45, averaged as the model does; field dates, sample size and voter type not published, so they are placeholders."},
    {"raceId": "MI-SEN-2026", "pollster": "Quantus Insights", "startDate": "2026-10-05", "endDate": "2026-10-06", "sampleSize": 762, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 48.0, "Mike Rogers (R)": 47.0, "Undecided": 5.0}, "notes": "Released Oct 7; field dates not published, so the dates shown are placeholders."},
    {"raceId": "MI-SEN-2026", "pollster": "InsiderAdvantage", "startDate": "2026-10-09", "endDate": "2026-10-10", "sampleSize": 1200, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 48.0, "Mike Rogers (R)": 46.0, "Undecided": 6.0}},
    {"raceId": "MI-SEN-2026", "pollster": "Alliance for a Better Future (R)", "startDate": "2026-10-06", "endDate": "2026-10-08", "sampleSize": 600, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 44.0, "Mike Rogers (R)": 46.0, "Undecided": 10.0}, "notes": "Released by a group running ads for Rogers; polling firm not named."},
    {"raceId": "MI-SEN-2026", "pollster": "EPIC-MRA for MIRS", "startDate": "2026-07-24", "endDate": "2026-07-31", "sampleSize": 600, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 43.0, "Mike Rogers (R)": 46.0, "Undecided": 11.0}},
    {"raceId": "MI-SEN-2026", "pollster": "Marist University", "startDate": "2026-09-24", "endDate": "2026-09-27", "sampleSize": 1235, "sampleType": "RV", "results": {"Abdul El-Sayed (D)": 51.0, "Mike Rogers (R)": 44.0, "Other": 1.0, "Undecided": 3.0}},
    {"raceId": "MI-SEN-2026", "pollster": "Tyson Group for Alliance for a Better Future (R)", "startDate": "2026-09-24", "endDate": "2026-09-27", "sampleSize": 600, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 44.0, "Mike Rogers (R)": 43.0, "Undecided": 13.0}},
    {"raceId": "MI-SEN-2026", "pollster": "Rasmussen Reports", "startDate": "2026-10-12", "endDate": "2026-10-14", "sampleSize": 798, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 46.0, "Mike Rogers (R)": 44.0, "Other": 5.0, "Undecided": 5.0}},
    {"raceId": "MI-SEN-2026", "pollster": "Marist University", "startDate": "2026-10-15", "endDate": "2026-10-18", "sampleSize": 1025, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 50.0, "Mike Rogers (R)": 48.0, "Other": 1.0, "Undecided": 2.0}},
    {"raceId": "MI-SEN-2026", "pollster": "On Point Polling", "startDate": "2026-10-18", "endDate": "2026-10-18", "sampleSize": 518, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 48.7, "Mike Rogers (R)": 42.8, "Other": 1.8, "Undecided": 6.7}},
    {"raceId": "MI-SEN-2026", "pollster": "InsiderAdvantage (R)", "startDate": "2026-10-21", "endDate": "2026-10-22", "sampleSize": 1200, "sampleType": "LV", "results": {"Abdul El-Sayed (D)": 47.0, "Mike Rogers (R)": 46.0, "Undecided": 7.0}}
  ],
};
