"use client";
// The campaign trail: every confirmed stop by the national figures campaigning in the 2026 midterms, who is putting
// attention on which state, and who has endorsed whom. Press play to watch the figures hop from stop to stop; pick a
// person to draw their whole route; click a state for everything that happened there.
import React, { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import PersonToken, { PARTY_COLOR } from "../PersonToken";
import { Pointy } from "@/app/components/home/Mascot";
import type { Trail, Person } from "../data";

type Geo = { frame: [number, number]; states: Record<string, string>; labels?: Record<string, [number, number, number]> };
type Mode = "trail" | "attention" | "endorse";
const START = Date.parse("2026-08-01T12:00:00Z"), END = Date.parse("2026-11-03T12:00:00Z"), DAY = 864e5;
const STN: Record<string, string> = { AL: "Alabama", AK: "Alaska", AZ: "Arizona", AR: "Arkansas", CA: "California", CO: "Colorado", CT: "Connecticut", DE: "Delaware", FL: "Florida", GA: "Georgia", HI: "Hawaii", ID: "Idaho", IL: "Illinois", IN: "Indiana", IA: "Iowa", KS: "Kansas", KY: "Kentucky", LA: "Louisiana", ME: "Maine", MD: "Maryland", MA: "Massachusetts", MI: "Michigan", MN: "Minnesota", MS: "Mississippi", MO: "Missouri", MT: "Montana", NE: "Nebraska", NV: "Nevada", NH: "New Hampshire", NJ: "New Jersey", NM: "New Mexico", NY: "New York", NC: "North Carolina", ND: "North Dakota", OH: "Ohio", OK: "Oklahoma", OR: "Oregon", PA: "Pennsylvania", RI: "Rhode Island", SC: "South Carolina", SD: "South Dakota", TN: "Tennessee", TX: "Texas", UT: "Utah", VT: "Vermont", VA: "Virginia", WA: "Washington", WV: "West Virginia", WI: "Wisconsin", WY: "Wyoming" };
const fd = (iso: string) => { const t = Date.parse(iso + "T12:00:00Z"); return Number.isFinite(t) ? new Date(t).toLocaleDateString("en-US", { month: "short", day: "numeric", timeZone: "UTC" }) : iso; };
const tOf = (iso: string) => { const t = Date.parse(iso.slice(0, 10) + "T12:00:00Z"); return Number.isFinite(t) ? t : NaN; };
// Oct 22 2026: on the national endorsements map each state shows its three most important endorsers and a count of
// the rest; a click on any state opens its county map with every endorser and every campaign stop there.
const TIER: [RegExp, number][] = [[/^president$/i, 100], [/former president/i, 92], [/^vice president$/i, 88], [/former vice president/i, 80], [/majority leader|minority leader|speaker|whip/i, 70],
  [/governor/i, 66], [/senator/i, 62], [/cabinet/i, 60], [/representative|rep\./i, 50], [/surrogate/i, 48], [/celebrity|musician/i, 44], [/podcaster|host|commentator|streamer|influencer/i, 40], [/activist|business/i, 36], [/group/i, 20]];
const tierOf = (role?: string) => TIER.find(([re]) => re.test(role ?? ""))?.[1] ?? 30;
function bbox(d: string) { let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9; const re = /(-?\d+\.?\d*)[ ,](-?\d+\.?\d*)/g; let m; while ((m = re.exec(d))) { const x = +m[1], y = +m[2]; if (x < x0) x0 = x; if (y < y0) y0 = y; if (x > x1) x1 = x; if (y > y1) y1 = y; } return [x0, y0, x1, y1]; }

export default function TrailMap({ data }: { data: Trail }) {
  const [geo, setGeo] = useState<Geo | null>(null);
  const [mode, setMode] = useState<Mode>("trail");
  const [party, setParty] = useState<"all" | "R" | "D">("all");
  const [who, setWho] = useState<string | null>(null);
  const [st, setSt] = useState<string | null>(null);
  const [t, setT] = useState<number>(() => Math.min(END, Date.parse("2026-10-22T12:00:00Z")));
  const [playing, setPlaying] = useState(false);
  const [tip, setTip] = useState<{ x: number; y: number; st: string } | null>(null);
  const [zoom, setZoom] = useState<string | null>(null);
  const wrap = useRef<HTMLDivElement>(null);
  useEffect(() => { fetch("/forecast/geo.json").then((r) => r.json()).then(setGeo).catch(() => {}); }, []);
  useEffect(() => {
    if (!playing) return;
    const id = setInterval(() => setT((x) => { if (x >= END) { setPlaying(false); return END; } return x + DAY; }), 140);
    return () => clearInterval(id);
  }, [playing]);

  const P = useMemo(() => Object.fromEntries(data.people.map((p) => [p.name, p])) as Record<string, Person>, [data.people]);
  const pt = useMemo(() => {
    const out: Record<string, [number, number]> = {};
    if (!geo) return out;
    for (const [s, d] of Object.entries(geo.states)) { const lb = geo.labels?.[s]; if (lb) out[s] = [lb[0], lb[1]]; else { const b = bbox(d); out[s] = [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2]; } }
    return out;
  }, [geo]);
  const okParty = (p: string) => party === "all" || p === party;
  const visits = useMemo(() => data.visits.filter((v) => okParty(v.party) && (!who || v.who === who)), [data.visits, party, who]);
  const shown = visits.filter((v) => tOf(v.date) <= t);
  const att = data.attention.filter((a) => (party === "all" || a.lean === party) && (!who || a.who === who));
  const end = data.endorse.filter((e) => (party === "all" || e.party === party) && (!who || e.by === who));

  // where each person is on day t: their latest stop on or before t
  const here = useMemo(() => {
    const by: Record<string, { st: string; date: string; age: number; kind: string }> = {};
    for (const v of shown) { const a = (t - tOf(v.date)) / DAY; if (!by[v.who] || tOf(v.date) >= tOf(by[v.who].date)) by[v.who] = { st: v.st, date: v.date, age: a, kind: v.kind }; }
    return by;
  }, [shown, t]);
  const heat = useMemo(() => {
    const h: Record<string, number> = {};
    if (mode === "trail") for (const v of shown) h[v.st] = (h[v.st] ?? 0) + 1;
    else if (mode === "attention") for (const a of att) h[a.st] = (h[a.st] ?? 0) + 1;
    else for (const e of end) h[e.st] = (h[e.st] ?? 0) + 1;
    return h;
  }, [mode, shown, att, end]);
  const maxHeat = Math.max(1, ...Object.values(heat));
  const fillOf = (s: string) => { const n = heat[s] ?? 0; if (!n) return "rgba(255,255,255,.035)"; const a = 0.16 + 0.6 * Math.sqrt(n / maxHeat); return `rgba(231,179,65,${a.toFixed(3)})`; };

  // tokens to draw
  type Tok = { key: string; name: string; st: string; x: number; y: number; dim: boolean; date?: string; label?: string; size: number; more?: number };
  // Oct 22 2026: every person fits. Each state lays its people out in rings that shrink as the crowd grows; past
  // eleven people the state shows a counter that opens the full list in the state panel.
  const toks: Tok[] = useMemo(() => {
    const out: Tok[] = [];
    if (!geo) return out;
    const per: Record<string, { name: string; extra: Partial<Tok> }[]> = {};
    const add = (name: string, s: string, extra: Partial<Tok>) => { if (!pt[s]) return; (per[s] ??= []).push({ name, extra }); };
    if (mode === "trail") {
      Object.entries(here).sort((a, b) => (P[b[0]]?.visits ?? 0) - (P[a[0]]?.visits ?? 0)).forEach(([name, h]) => add(name, h.st, { dim: h.age > 10, date: h.date }));
    } else if (mode === "attention") {
      const seen = new Set<string>(); att.forEach((a) => { const k = a.who + a.st; if (seen.has(k)) return; seen.add(k); add(a.who, a.st, {}); });
    } else {
      const seen = new Set<string>(); end.forEach((e) => { const k = e.by + e.st; if (seen.has(k)) return; seen.add(k); add(e.by, e.st, { label: e.cand }); });
      const imp = (n: string) => tierOf(P[n]?.role) * 10 + (P[n]?.endorse ?? 0);
      for (const s of Object.keys(per)) per[s].sort((a, b) => imp(b.name) - imp(a.name));
    }
    const SMALL = new Set(["RI", "DE", "CT", "NJ", "MD", "MA", "NH", "VT", "DC"]);
    for (const [s, list] of Object.entries(per)) {
      const p = pt[s];
      const cap = mode === "endorse" ? (SMALL.has(s) ? 1 : 3) : SMALL.has(s) ? 3 : 11;
      const shown = list.slice(0, cap);
      const n = shown.length;
      const size = n <= 1 ? 38 : n <= 4 ? 32 : n <= 7 ? 26 : 22;
      shown.forEach((x, i) => {
        // first person in the middle, the rest on one ring of up to 6 and a second ring beyond it
        let dx = 0, dy = 0;
        if (i > 0) { const ring = i <= 6 ? 1 : 2; const k = ring === 1 ? i - 1 : i - 7; const m = ring === 1 ? Math.min(6, n - 1) : n - 7; const a = (k / Math.max(1, m)) * Math.PI * 2 - Math.PI / 2; const r = (ring === 1 ? 1.05 : 1.95) * size; dx = Math.cos(a) * r; dy = Math.sin(a) * r * 0.78; }
        out.push({ key: `${x.name}-${s}-${i}`, name: x.name, st: s, x: p[0] + dx, y: p[1] + dy - 6, dim: false, size, ...x.extra });
      });
      if (list.length > cap) out.push({ key: `more-${s}`, name: "", st: s, x: p[0] + size * (mode === "endorse" ? 1.45 : 1.7), y: p[1] + size * (mode === "endorse" ? 0.2 : 1.2), dim: false, size, more: list.length - cap });
    }
    return out;
  }, [geo, mode, here, att, end, pt, P]);

  // the focused person's route so far
  const route = useMemo(() => {
    if (!who || mode !== "trail") return "";
    const pts = shown.filter((v) => v.who === who).sort((a, b) => tOf(a.date) - tOf(b.date)).map((v) => pt[v.st]).filter(Boolean) as [number, number][];
    if (pts.length < 2) return "";
    return pts.map((p, i) => { if (!i) return `M${p[0]},${p[1]}`; const q = pts[i - 1]; const mx = (p[0] + q[0]) / 2, my = (p[1] + q[1]) / 2 - Math.hypot(p[0] - q[0], p[1] - q[1]) * 0.25; return `Q${mx},${my} ${p[0]},${p[1]}`; }).join(" ");
  }, [who, mode, shown, pt]);

  const W = geo?.frame[0] ?? 975, H = geo?.frame[1] ?? 610;
  const stVisits = st ? data.visits.filter((v) => v.st === st && okParty(v.party)) : [];
  const stAtt = st ? data.attention.filter((a) => a.st === st) : [];
  const stEnd = st ? data.endorse.filter((e) => e.st === st) : [];
  const upcoming = data.visits.filter((v) => tOf(v.date) > Date.parse("2026-10-22T00:00:00Z") && okParty(v.party)).sort((a, b) => tOf(a.date) - tOf(b.date));
  const recent = [...shown].sort((a, b) => tOf(b.date) - tOf(a.date)).slice(0, 8);
  const pct = ((t - START) / (END - START)) * 100;
  const peopleShown = data.people.filter((p) => okParty(p.party) && (mode === "trail" ? p.visits : mode === "attention" ? p.attention : p.endorse));

  return (
    <div className="tr">
      <div className="tr-bar">
        <div className="wd-chips" role="group" aria-label="What to show">
          {([["trail", "On the trail"], ["attention", "Attention"], ["endorse", "Endorsements"]] as [Mode, string][]).map(([k, l]) => <button key={k} className={mode === k ? "on" : ""} aria-pressed={mode === k} onClick={() => { setMode(k); setWho(null); }}>{l}</button>)}
        </div>
        <div className="wd-chips" role="group" aria-label="Party">
          {([["all", "Everyone"], ["R", "Republicans"], ["D", "Democrats"]] as const).map(([k, l]) => <button key={k} className={party === k ? "on" : ""} aria-pressed={party === k} onClick={() => setParty(k)}>{l}</button>)}
        </div>
        {who ? <button className="wd-btn" onClick={() => setWho(null)}>Showing {who} · show everyone</button> : null}
      </div>

      <div className="tr-stage">
        <div className="tr-map card" ref={wrap} onMouseLeave={() => setTip(null)}>
          {geo && zoom ? <StateView st={zoom} statePath={geo.states[zoom]} data={data} P={P} party={party} onBack={() => setZoom(null)} onWho={(n) => setWho(who === n ? null : n)} who={who} />
          : geo ? (
            <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Map of the 2026 campaign trail">
              <defs>
                <filter id="trglow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="4" /></filter>
              </defs>
              {Object.entries(geo.states).map(([s, d]) => (
                <path key={s} d={d} className={`tr-st${st === s ? " on" : ""}`} style={{ fill: fillOf(s) }} onClick={() => { setSt(s); setZoom(s); }}
                  onMouseMove={(e) => { const b = wrap.current!.getBoundingClientRect(); setTip({ x: e.clientX - b.left, y: e.clientY - b.top, st: s }); }} />
              ))}
              {route ? <><path d={route} className="tr-route glow" filter="url(#trglow)" /><path d={route} className="tr-route" /></> : null}
              {mode === "trail" ? shown.filter((v) => (t - tOf(v.date)) / DAY < 2.5).map((v, i) => { const p = pt[v.st]; return p ? <circle key={`${v.who}${v.date}${i}`} cx={p[0]} cy={p[1]} r="8" className="tr-ring" style={{ stroke: PARTY_COLOR[v.party] ?? "#e7b341" }} /> : null; }) : null}
              {toks.map((k) => {
                if (k.more) return (
                  <g key={k.key} className="tr-more" onClick={() => { setSt(k.st); setZoom(k.st); }} role="button" aria-label={`${k.more} more in ${k.st}`}>
                    <circle cx={k.x} cy={k.y} r={13} /><text x={k.x} y={k.y + 4} textAnchor="middle">+{k.more}</text>
                  </g>
                );
                const p = P[k.name];
                return (
                  <g key={k.key} className={`tr-tok${k.dim ? " dim" : ""}${who === k.name ? " on" : ""}`} style={{ transform: `translate(${k.x - k.size * 0.37}px, ${k.y - k.size * 0.9}px)` }} onClick={() => setWho(who === k.name ? null : k.name)}>
                    <PersonToken ini={p?.ini ?? k.name.slice(0, 2)} party={p?.party ?? "O"} role={p?.role} size={k.size} active={who === k.name} title={k.name} />
                  </g>
                );
              })}
            </svg>
          ) : <div className="tr-load sx-skel" />}
          {tip && !zoom ? (
            <div className="wd-tip" style={{ left: tip.x + 14, top: tip.y + 12, transform: tip.x > (wrap.current?.clientWidth ?? 0) - 330 ? "translateX(calc(-100% - 28px))" : undefined }}>
              <h4>{STN[tip.st] ?? tip.st}</h4>
              <div>{data.visits.filter((v) => v.st === tip.st && okParty(v.party)).length} trail stops · {data.attention.filter((a) => a.st === tip.st).length} attention · {data.endorse.filter((e) => e.st === tip.st).length} endorsements</div>
              <div style={{ opacity: .8, marginTop: 4 }}>Click for the county map and the full list</div>
            </div>
          ) : null}
          <div className="tr-time">
            <button className="wd-btn" onClick={() => { if (t >= END) setT(START); setPlaying((p) => !p); }} aria-label={playing ? "Pause" : "Play the campaign from August"}>{playing ? "Pause" : "Play"}</button>
            <div className="tr-slider">
              <input id="tr-t" type="range" min={START} max={END} step={DAY} value={t} onChange={(e) => { setPlaying(false); setT(+e.target.value); }} aria-label="Date" />
              <div className="tr-fill" style={{ width: `${pct}%` }} />
            </div>
            <b className="mono">{new Date(t).toLocaleDateString("en-US", { month: "short", day: "numeric", timeZone: "UTC" })}</b>
          </div>
          <Pointy className="tr-pty" pose="think" prop="magnifier" size={92} look={-1} flip detective say={<>{shown.length} stops so far. Click a figure to trace a route.</>} />
        </div>

        <aside className="tr-side">
          {st ? (
            <div className="card">
              <div className="card-h"><h3>{STN[st] ?? st}</h3><button className="wd-btn" style={{ marginLeft: "auto" }} onClick={() => { setSt(null); setZoom(null); }}>Close</button></div>
              <div className="tr-list">
                {stVisits.length ? <div className="eye gold">On the trail</div> : null}
                {stVisits.map((v, i) => <Item key={`v${i}`} p={P[v.who]} title={`${v.who} · ${fd(v.date)}${v.city ? `, ${v.city}` : ""}`} text={`${v.kind === "announced" ? "Announced: " : ""}${v.note}${v.for.length ? ` For ${v.for.join(", ")}.` : ""}`} src={v.src} />)}
                {stAtt.length ? <div className="eye gold">Attention</div> : null}
                {stAtt.map((a, i) => <Item key={`a${i}`} p={P[a.who]} title={`${a.who} · ${a.race}`} text={a.what} src={a.src} />)}
                {stEnd.length ? <div className="eye gold">Endorsements</div> : null}
                {stEnd.map((e, i) => <Item key={`e${i}`} p={P[e.by]} title={`${e.by} endorsed ${e.cand}`} text={`${e.race}${e.date ? `, ${e.date}` : ""}`} src={e.src} />)}
                {!stVisits.length && !stAtt.length && !stEnd.length ? <div className="wd-empty">Nothing confirmed in {STN[st] ?? st} yet.</div> : null}
              </div>
            </div>
          ) : (
            <div className="card">
              <div className="card-h"><h3>{mode === "trail" ? "Latest stops" : mode === "attention" ? "Who is paying attention" : "Endorsements"}</h3></div>
              <div className="tr-list">
                {mode === "trail" ? recent.map((v, i) => <Item key={i} p={P[v.who]} title={`${v.who} · ${STN[v.st] ?? v.st}, ${fd(v.date)}`} text={v.note} src={v.src} onClick={() => setSt(v.st)} />)
                  : mode === "attention" ? att.map((a, i) => <Item key={i} p={P[a.who]} title={`${a.who} · ${a.race}`} text={a.what} src={a.src} onClick={() => setSt(a.st)} />)
                  : end.map((e, i) => <Item key={i} p={P[e.by]} title={`${e.by} endorsed ${e.cand}`} text={`${e.race}${e.date ? `, ${e.date}` : ""}`} src={e.src} onClick={() => setSt(e.st)} />)}
              </div>
            </div>
          )}
          {mode === "trail" && upcoming.length ? (
            <div className="card">
              <div className="card-h"><h3>Coming up before Election Day</h3></div>
              <div className="tr-list">{upcoming.slice(0, 10).map((v, i) => <Item key={i} p={P[v.who]} title={`${fd(v.date)} · ${v.who}`} text={`${v.city ? `${v.city}, ` : ""}${STN[v.st] ?? v.st}${v.for.length ? `, for ${v.for.join(", ")}` : ""}`} src={v.src} onClick={() => setSt(v.st)} />)}</div>
            </div>
          ) : null}
        </aside>
      </div>

      <div className="card tr-people">
        <div className="card-h"><h3>The people</h3><span className="eye" style={{ marginLeft: "auto" }}>Click anyone to follow them</span></div>
        <div className="tr-rail">
          {peopleShown.map((p) => (
            <button key={p.name} className={`tr-person${who === p.name ? " on" : ""}`} onClick={() => { setWho(who === p.name ? null : p.name); if (mode === "trail") setT(END); }}>
              <PersonToken ini={p.ini} party={p.party} role={p.role} size={44} active={who === p.name} />
              <span><b>{p.name}</b><small>{mode === "trail" ? `${p.visits} ${p.visits === 1 ? "stop" : "stops"}` : mode === "attention" ? `${p.attention} items` : `${p.endorse} endorsements`} · {p.states.length} states</small></span>
            </button>
          ))}
        </div>
        <p className="wd-note" style={{ padding: "0 16px 14px" }}>Only visits and statements confirmed by a news report or the campaign&apos;s own announcement are shown. Figures are On Point cartoon characters in each person&apos;s party color with their initials, not likenesses. <Link href="/watchdog/connections" style={{ textDecoration: "underline" }}>See how they connect to the money</Link>.</p>
      </div>
    </div>
  );
}

function Item({ p, title, text, src, onClick }: { p?: Person; title: string; text: string; src?: string; onClick?: () => void }) {
  return (
    <div className={`tr-item${onClick ? " click" : ""}`} onClick={onClick} role={onClick ? "button" : undefined} tabIndex={onClick ? 0 : undefined} onKeyDown={onClick ? (e) => { if (e.key === "Enter") onClick(); } : undefined}>
      {p ? <PersonToken ini={p.ini} party={p.party} role={p.role} size={34} /> : <span style={{ width: 27 }} />}
      <span><b>{title}</b><small>{text}</small>{src ? <a href={src} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()}>Source</a> : null}</span>
    </div>
  );
}

/* ---------------------------------------------------------------- one state, county by county */
type CountyGeo = [string, string, string][];
type CountyMeta = Record<string, { n: string; st: string; area: number; r24?: number }>;
let COUNTY_CACHE: Promise<[CountyGeo, CountyMeta]> | null = null;
function StateView({ st, statePath, data, P, party, onBack, onWho, who }: { st: string; statePath: string; data: Trail; P: Record<string, Person>; party: "all" | "R" | "D"; onBack: () => void; onWho: (n: string) => void; who: string | null }) {
  const [cg, setCg] = useState<[CountyGeo, CountyMeta] | null>(null);
  const [hv, setHv] = useState<{ x: number; y: number; t: string; s: string } | null>(null);
  const box = useRef<HTMLDivElement>(null);
  useEffect(() => {
    COUNTY_CACHE ??= Promise.all([fetch("/watchdog/us_counties.json").then((r) => r.json()), fetch("/watchdog/counties.json").then((r) => r.json())]) as Promise<[CountyGeo, CountyMeta]>;
    COUNTY_CACHE.then(setCg).catch(() => {});
  }, []);
  const [x0, y0, x1, y1] = bbox(statePath);
  const pad = Math.max(x1 - x0, y1 - y0) * 0.06, vb = [x0 - pad, y0 - pad, x1 - x0 + pad * 2, y1 - y0 + pad * 2];
  const counties = useMemo(() => (cg ? cg[0].filter((c) => c[1] === st) : []), [cg, st]);
  const ok = (p: string) => party === "all" || p === party;
  // everyone in the state: each endorser once, with every candidate they backed, and each figure on the trail once
  const ppl = useMemo(() => {
    const m = new Map<string, { name: string; endorse: string[]; stops: { date: string; city: string; kind: string; for: string[]; src: string }[]; src?: string }>();
    for (const e of data.endorse) if (e.st === st && ok(e.party)) { const x = m.get(e.by) ?? { name: e.by, endorse: [], stops: [] }; if (!x.endorse.includes(e.cand)) x.endorse.push(e.cand); x.src ??= e.src; m.set(e.by, x); }
    for (const v of data.visits) if (v.st === st && ok(v.party)) { const x = m.get(v.who) ?? { name: v.who, endorse: [], stops: [] }; x.stops.push({ date: v.date, city: v.city, kind: v.kind, for: v.for, src: v.src }); m.set(v.who, x); }
    return [...m.values()].sort((a, b) => (b.stops.length ? 1e6 : 0) + tierOf(P[b.name]?.role) * 10 + (P[b.name]?.endorse ?? 0) - ((a.stops.length ? 1e6 : 0) + tierOf(P[a.name]?.role) * 10 + (P[a.name]?.endorse ?? 0)));
  }, [data, st, party, P]);
  // a slot for each person on the county map: county centres, biggest counties first, never two people on top of each other
  const placed = useMemo(() => {
    const S = Math.min(vb[2], vb[3]);
    const n = Math.max(1, ppl.length), size = Math.max(S / 26, Math.min(S / 9, S / Math.sqrt(n) / 1.6));
    const cents = counties.map((c) => { const b = bbox(c[2]); return { x: (b[0] + b[2]) / 2, y: (b[1] + b[3]) / 2, a: (b[2] - b[0]) * (b[3] - b[1]), n: cg?.[1][c[0]]?.n ?? "" }; }).sort((a, b) => b.a - a.a);
    const cityHit = (city: string) => cents.find((c) => c.n && city && city.toLowerCase().startsWith(c.n.toLowerCase()));
    const used: { x: number; y: number }[] = [], out: { p: (typeof ppl)[number]; x: number; y: number; size: number }[] = [];
    const free = (x: number, y: number) => used.every((u) => Math.hypot(u.x - x, u.y - y) > size * 0.95);
    let gi = 0;
    for (const p of ppl) {
      const hit = p.stops.length ? cityHit(p.stops[0].city) : undefined;
      let spot = hit && free(hit.x, hit.y) ? hit : cents.find((c) => free(c.x, c.y));
      if (!spot) { // past the last free county: a grid over the state's box
        for (; gi < 4000 && !spot; gi++) { const cols = Math.max(3, Math.floor(vb[2] / (size * 1.05))), gx = vb[0] + size * 0.6 + (gi % cols) * size * 1.05, gy = vb[1] + size * 0.8 + Math.floor(gi / cols) * size * 1.1; if (free(gx, gy)) spot = { x: gx, y: gy, a: 0, n: "" }; }
      }
      if (!spot) continue;
      used.push(spot); out.push({ p, x: spot.x, y: spot.y, size });
    }
    return out;
  }, [ppl, counties, cg, vb]);
  const shade = (f: string) => { const r = cg?.[1][f]?.r24; if (r == null) return "rgba(255,255,255,.05)"; const lean = Math.max(-1, Math.min(1, r / 60)); return lean >= 0 ? `rgba(255,59,92,${(0.06 + lean * 0.5).toFixed(3)})` : `rgba(61,123,255,${(0.06 - lean * 0.5).toFixed(3)})`; };
  return (
    <div className="tr-sv" ref={box} onMouseLeave={() => setHv(null)}>
      <div className="tr-svh"><button className="wd-btn" onClick={onBack}>Back to the national map</button><b>{STN[st] ?? st}</b><span>{ppl.filter((p) => p.endorse.length).length} endorsers · {ppl.reduce((a, p) => a + p.stops.length, 0)} campaign stops · counties shaded by the 2024 presidential vote</span></div>
      <svg viewBox={vb.join(" ")} preserveAspectRatio="xMidYMid meet" role="img" aria-label={`${STN[st] ?? st}: county map with every endorser and campaign stop`}>
        <path d={statePath} className="tr-sv-st" />
        {counties.map((c) => <path key={c[0]} d={c[2]} className="tr-sv-co" style={{ fill: shade(c[0]) }} />)}
        {placed.map(({ p, x, y, size }) => {
          const pp = P[p.name], fl = p.stops.length > 0;
          return (
            <g key={p.name} className={`tr-tok${who === p.name ? " on" : ""}`} style={{ transform: `translate(${x - size * 0.37}px, ${y - size * 0.9}px)` }} onClick={() => onWho(p.name)}
              onMouseEnter={(e) => { const b = box.current!.getBoundingClientRect(); setHv({ x: e.clientX - b.left, y: e.clientY - b.top, t: p.name, s: [p.endorse.length ? `Endorsed ${p.endorse.join(", ")}` : "", fl ? `${p.stops.length} ${p.stops.length === 1 ? "stop" : "stops"}: ${p.stops.map((v) => `${v.city || STN[st]}, ${fd(v.date)}`).join("; ")}` : ""].filter(Boolean).join(". ") }); }}>
              <PersonToken ini={pp?.ini ?? p.name.slice(0, 2)} party={pp?.party ?? "O"} role={pp?.role} size={size} active={who === p.name} title={p.name} />
              {fl ? <circle cx={size * 0.66} cy={size * 0.12} r={size * 0.12} className="tr-sv-flag" fill="#ffd98a" stroke="#1b1230" strokeWidth={size * 0.02} /> : null}
            </g>
          );
        })}
      </svg>
      {hv ? <div className="wd-tip" style={{ left: hv.x + 14, top: hv.y + 12, transform: hv.x > (box.current?.clientWidth ?? 0) - 330 ? "translateX(calc(-100% - 28px))" : undefined }}><h4>{hv.t}</h4><div>{hv.s}</div></div> : null}
      <div className="tr-svk"><span><i className="flag" />Campaigned here</span><span>Everyone else endorsed in this state</span><span>Click a figure to follow them</span></div>
    </div>
  );
}
