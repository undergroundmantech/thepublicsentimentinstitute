# Rhett Marques Watchdog File

Subject: Rhett Marques, Republican, AL, running for U.S. House district 2 in 2026
Current office: State Representative
Compiled: 2026-10-23 for the On Point Politics watchdog database, onpointpolitics.us
Status: queued for hand research, priority 3. This file holds the roster facts, the office levers, and FEC pipeline data when the pipeline has run. It is not yet a finished Tier 2 profile.

## Race

Race status: nominee. Rating: Cook: Lean Republican. Current holder of the seat: Shomari Figures.
Opponents: Shomari Figures, Democrat.
Roster note: won Aug 11 special primary under new map

## Committee assignments

None in the roster file. Governors and challengers have none.

## Money

Not yet pulled. Run pipeline/fec_pull.py for federal subjects. Governors and other state candidates need hand research in the state campaign finance system.

## Levers this office controls

Template rows from the office and committee assignments. Each needs the specific decision, the date, and the subject position before it counts as a finding.

| Decision | Where it sits | Which blocs care |
|---|---|---|
| Floor votes on reconciliation, appropriations and the NDAA | U.S. House | Billionaire megadonor; Defense contractors; Health care and pharma |
| Earmark requests for the district | U.S. House | Developers and construction; Health care and pharma |

## Where to start

- Ballotpedia: https://ballotpedia.org/Rhett_Marques
- Roster source: https://www.wbhm.org/local-news/2026-08-11/2026-alabama-special-congressional-primary-results

## What we could not verify

Everything beyond the roster row. This subject has not been hand researched yet.
